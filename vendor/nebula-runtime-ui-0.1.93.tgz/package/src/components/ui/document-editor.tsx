import { forwardRef, type HTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react'
import { cn } from '#nebula/lib/utils'

export function DocumentEditor({ className, ...props }: HTMLAttributes<HTMLElement>) {
  return <section className={cn('w-full min-w-0', className)} {...props} />
}

interface DocumentIdentityProps extends HTMLAttributes<HTMLDivElement> {
  name: string
  description: string
  namePlaceholder?: string
  descriptionPlaceholder?: string
  showDescription?: boolean
  nameDisabled?: boolean
  onNameChange: (value: string) => void
  onDescriptionChange: (value: string) => void
}

export function DocumentIdentity({
  className,
  name,
  description,
  namePlaceholder = 'Title',
  descriptionPlaceholder = 'Description...',
  showDescription = true,
  nameDisabled = false,
  onNameChange,
  onDescriptionChange,
  ...props
}: DocumentIdentityProps) {
  return (
    <div className={cn('mb-8', className)} {...props}>
      <input
        aria-label="Name"
        value={name}
        disabled={nameDisabled}
        onChange={event => onNameChange(event.target.value)}
        placeholder={namePlaceholder}
        className="block w-full border-0 bg-transparent p-0 text-[clamp(1.85rem,4vw,2.65rem)] font-semibold leading-tight tracking-[-0.035em] text-[var(--color-text-primary)] outline-none placeholder:text-[var(--color-text-disabled)] disabled:cursor-not-allowed disabled:opacity-55"
      />
      {showDescription && <textarea
        aria-label="Description"
        value={description}
        onChange={event => onDescriptionChange(event.target.value)}
        placeholder={descriptionPlaceholder}
        rows={1}
        className="mt-4 block min-h-[3.5rem] w-full resize-none overflow-hidden border-0 bg-transparent p-0 text-base leading-7 text-[var(--color-text-secondary)] outline-none [field-sizing:content] placeholder:text-[var(--color-text-disabled)]"
      />}
    </div>
  )
}

interface DocumentSectionProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
  title: ReactNode
  description?: ReactNode
}

export function DocumentSection({ className, title, description, children, ...props }: DocumentSectionProps) {
  return (
    <div className={cn('mt-7', className)} {...props}>
      <div className="mb-2.5">
        <h2 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[var(--color-text-muted)]">{title}</h2>
        {description && <p className="mt-1 text-[12px] leading-5 text-[var(--color-text-subtle)]">{description}</p>}
      </div>
      {children}
    </div>
  )
}

export const DocumentBody = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function DocumentBody(
  { className, ...props },
  ref,
) {
  return (
    <textarea
      ref={ref}
      className={cn(
        'block h-[clamp(13rem,32vh,22rem)] min-h-[13rem] max-h-[22rem] w-full resize-none overflow-y-auto border-0 bg-transparent px-0 py-1 text-[13px] leading-6 text-[var(--color-text-primary)] outline-none [scrollbar-color:rgba(255,255,255,0.14)_transparent] [scrollbar-width:thin] placeholder:text-[var(--color-text-disabled)]',
        className,
      )}
      {...props}
    />
  )
})

export function DocumentAdvanced({ className, children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('mt-9 border-t border-white/[0.07] pt-6', className)} {...props}>
      <h2 className="mb-4 text-[11px] font-semibold uppercase tracking-[0.16em] text-[var(--color-text-muted)]">Advanced settings</h2>
      {children}
    </div>
  )
}

export const DocumentInlineInput = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function DocumentInlineInput(
  { className, ...props },
  ref,
) {
  return (
    <input
      ref={ref}
      className={cn('w-full border-0 border-b border-white/[0.08] bg-transparent px-0 py-2 text-[13px] text-[var(--color-text-primary)] outline-none placeholder:text-[var(--color-text-disabled)] focus:border-white/20', className)}
      {...props}
    />
  )
})
