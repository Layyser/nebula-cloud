import { useEffect, useRef, useState } from 'react'
import { LayoutGroup, motion, useReducedMotion } from 'framer-motion'
import { Search, Folder, MessageSquare, ChevronLeft, ChevronRight, LoaderCircle, X } from 'lucide-react'
import { ContentContainer, PageHeader } from '#nebula/components/ui/layout'
import { Button } from '#nebula/components/ui/button'
import { searchChats, type ChatSearchPage } from '#nebula/lib/api'

export function SearchView({ onSelectChat, revision = '' }: { onSelectChat: (name: string) => void; revision?: string }) {
  const [query, setQuery] = useState('')
  const [busy, setBusy] = useState(false)
  const [data, setData] = useState<ChatSearchPage | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [retry, setRetry] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(5)
  const listRef = useRef<HTMLDivElement>(null)
  const reducedMotion = useReducedMotion()

  useEffect(() => {
    const element = listRef.current
    if (!element) return
    const resize = () => setPageSize(Math.min(100, Math.max(1, Math.floor(element.clientHeight / 72))))
    resize()
    const observer = new ResizeObserver(resize)
    observer.observe(element)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    const refresh = () => setRetry(current => current + 1)
    window.addEventListener('focus', refresh)
    return () => window.removeEventListener('focus', refresh)
  }, [])

  useEffect(() => {
    const controller = new AbortController()
    setBusy(true)
    setError(null)
    const timer = window.setTimeout(() => {
      void searchChats(query.trim(), pageSize, (page - 1) * pageSize, controller.signal)
        .then(result => {
          if (controller.signal.aborted) return
          setData(result)
          setPage(current => Math.min(current, Math.max(1, Math.ceil(result.total / pageSize))))
        })
        .catch(reason => {
          if (!controller.signal.aborted) {
            setError(reason instanceof Error ? reason.message : 'Search is unavailable.')
            setData(null)
          }
        })
        .finally(() => { if (!controller.signal.aborted) setBusy(false) })
    }, query.trim() ? 200 : 0)
    return () => { window.clearTimeout(timer); controller.abort() }
  }, [query, pageSize, page, retry, revision])

  const results = data?.chats ?? []
  const pages = Math.max(1, Math.ceil((data?.total ?? 0) / pageSize))
  const currentPage = Math.min(page, pages)
  const firstPage = Math.max(1, Math.min(currentPage - 2, pages - 4))
  const pageNumbers = Array.from({ length: Math.min(5, pages) }, (_, index) => firstPage + index)
  const visible = results

  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden bg-[var(--color-surface-page)] text-[var(--color-text-primary)]">
      <ContentContainer gutter="workspace" spacing="none" width="workspace" className="flex min-h-0 flex-1 flex-col pt-8 pb-4 sm:pb-8">
        <PageHeader title="Search" description="Find a conversation. Pick up where you left off." withBackdrop={false} />
        <div className="relative z-20 h-12 shrink-0">
          <div className="ui-border-surface absolute inset-x-0 top-0 overflow-hidden rounded-xl bg-[var(--color-surface-panel)] shadow-[var(--shadow-surface-subtle)] focus-within:[--ui-border-color:var(--color-border-focus)]">
          <div className="flex h-12 items-center gap-3 pl-4 pr-2">
            <Search size={17} className="shrink-0 text-[var(--color-text-muted)]" />
            <input
              type="search" aria-label="Search conversations" maxLength={128}
              value={query} placeholder="Search chats or projects…"
              onChange={event => { setQuery(event.target.value); setPage(1) }}
              className="min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-[var(--color-text-disabled)] sm:text-sm"
            />
            {busy && <LoaderCircle aria-hidden="true" size={15} className="shrink-0 animate-spin motion-reduce:animate-none text-[var(--color-text-muted)]" />}
            {query && <Button variant="ghost" size="compact" className="h-8 w-8 rounded-md p-0" aria-label="Clear search" onClick={() => { setQuery(''); setPage(1) }}><X size={14} /></Button>}
          </div>
          </div>
        </div>
        <div className="flex shrink-0 items-center justify-between gap-2 py-4 text-xs text-[var(--color-text-muted)]">
          <span role="status">{busy ? 'Searching…' : query.trim() ? 'Matching conversations' : 'Recent conversations'}</span>
          <span>{data ? `${data.total} ${query.trim() ? 'matching ' : ''}${data.total === 1 ? 'chat' : 'chats'}` : ''}</span>
        </div>
        <div ref={listRef} className="min-h-0 flex-1 overflow-hidden" aria-busy={busy}>
          <motion.div key={`${query.trim()}-${currentPage}`} initial={reducedMotion ? false : { opacity: 0, y: 5 }} animate={{ opacity: busy ? 0.5 : 1, y: 0 }} transition={{ duration: reducedMotion ? 0 : 0.2 }}>
            {visible.map(chat => <article key={chat.name} role="button" tabIndex={busy ? -1 : 0} aria-disabled={busy} onClick={() => { if (!busy) onSelectChat(chat.name) }} onKeyDown={event => { if (!busy && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); onSelectChat(chat.name) } }} className="group relative flex h-[72px] w-full min-w-0 cursor-pointer items-center gap-3 rounded-xl px-4 text-left transition-none after:pointer-events-none after:absolute after:inset-x-0 after:bottom-0 after:h-px after:bg-[var(--color-border-subtle)] last:after:hidden hover:bg-[var(--color-surface-hover)] hover:after:opacity-0 [&:has(+article:hover)]:after:opacity-0 sm:gap-4 sm:px-5">
              <MessageSquare size={18} className="shrink-0 text-[var(--color-text-disabled)]" />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{chat.display_name || chat.name}</div>
                <div className="mt-1 truncate text-xs text-[var(--color-text-muted)]">{chat.snippet || 'No messages yet.'}</div>
              </div>
              <div className="w-[30%] min-w-0 max-w-48 shrink-0 text-right text-xs text-[var(--color-text-muted)]">
                <time dateTime={new Date(chat.updated_at_ms).toISOString()} title={new Date(chat.updated_at_ms).toLocaleString()} className="block leading-5">{new Date(chat.updated_at_ms).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</time>
                <span className="mt-1 flex items-center justify-end gap-1.5"><Folder size={12} className="shrink-0" /><span className="truncate">{chat.project}</span></span>
              </div>
            </article>)}
            {!busy && error && <div role="alert" className="py-10 text-center text-sm text-[var(--color-text-muted)]"><p>{error}</p><Button variant="ghost" className="mt-3" onClick={() => setRetry(current => current + 1)}>Retry</Button></div>}
            {!busy && !error && !results.length && <div className="py-10 text-center text-sm text-[var(--color-text-muted)]"><Search size={24} className="mx-auto mb-3" /><p>{query.trim() ? 'No conversations found.' : 'No chats yet.'}</p><p className="mt-2 text-xs">{query.trim() ? 'Try another title, project, or phrase.' : 'Start a conversation to see it here.'}</p></div>}
          </motion.div>
        </div>
        <LayoutGroup id="search-pagination">
        <nav aria-label="Search result pages" className="flex h-12 shrink-0 items-center justify-center gap-1 pt-2 sm:gap-2">
          <div className="size-8">{currentPage > 1 && <Button variant="ghost" size="compact" className="h-8 w-8 rounded-md p-0" aria-label="Previous page" onClick={() => setPage(currentPage - 1)}><ChevronLeft size={16} /></Button>}</div>
          {pageNumbers.map(number => <button key={number} type="button" aria-label={`Page ${number}`} aria-current={number === currentPage ? 'page' : undefined} onClick={() => setPage(number)} className={`relative grid size-8 cursor-pointer place-items-center text-xs tabular-nums outline-none transition-colors focus-visible:outline focus-visible:outline-1 focus-visible:outline-[var(--color-border-focus)] ${number === currentPage ? 'text-[var(--color-text-primary)]' : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)]'}`}>
            {number}
            {number === currentPage && <motion.span
              aria-hidden="true"
              layoutId="selected-page-underline"
              className="pointer-events-none absolute inset-x-0 bottom-0 h-0.5 bg-[var(--color-text-primary)]"
              transition={{ duration: reducedMotion ? 0 : 0.26, ease: [0.22, 1, 0.36, 1] }}
            />}
          </button>)}
          <div className="size-8">{currentPage < pages && <Button variant="ghost" size="compact" className="h-8 w-8 rounded-md p-0" aria-label="Next page" onClick={() => setPage(currentPage + 1)}><ChevronRight size={16} /></Button>}</div>
        </nav>
        </LayoutGroup>
      </ContentContainer>
    </section>
  )
}
