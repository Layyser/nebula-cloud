import type { ToolDisplay, WorkspaceChange } from './api'

export interface DiffLine {
  kind: 'context' | 'add' | 'remove' | 'meta'
  text: string
  oldLine?: number
  newLine?: number
}

function labelFor(name: string): string {
  if (name === 'load_mcp') return 'LoadMCP'
  return name.split(/[_\-\s]+/).filter(Boolean)
    .map(part => part.charAt(0).toUpperCase() + part.slice(1)).join('') || 'Tool'
}

function normalizedToolName(name: string): string {
  return name.trim().replace(/([a-z0-9])([A-Z])/g, '$1_$2').replace(/[-\s]+/g, '_').toLowerCase()
}

function stringArg(args: Record<string, unknown>, key: string): string {
  const value = args[key]
  if (value === undefined || value === null) return ''
  const rendered = typeof value === 'string' ? value : JSON.stringify(value)
  return rendered.split(/[\r\n]/, 1)[0].slice(0, 96)
}

function commandArg(args: Record<string, unknown>): string {
  const value = args.cmd ?? args.command
  if (value === undefined || value === null) return ''
  const rendered = typeof value === 'string' ? value : JSON.stringify(value)
  return rendered
    .replace(/\r?\n/g, '; ')
    .replace(/[ \t]+/g, ' ')
    .replace(/;\s*;/g, ';')
    .trim()
}

function listTarget(args: Record<string, unknown>): string {
  const path = stringArg(args, 'path') || '.'
  const glob = stringArg(args, 'glob')
  if (!glob || glob === '*') return path
  if (path === '.') return glob
  return `${path.replace(/[\\/]$/, '')}/${glob}`
}

export function fallbackToolDisplay(
  name: string,
  args: Record<string, unknown>,
): ToolDisplay {
  const normalized = normalizedToolName(name)
  let primary = ''
  if (normalized === 'list_files') primary = listTarget(args)
  else if (normalized === 'workspace_changes') {
    primary = stringArg(args, 'action')
    const id = stringArg(args, 'change_id')
    if (id) primary += `:${id}`
  }
  else if (normalized === 'bash' || normalized === 'shell') primary = commandArg(args)
  else if (['read_file', 'edit_file', 'write_file'].includes(normalized)) primary = stringArg(args, 'path')
  else if (normalized === 'load_skill' || normalized === 'load_mcp') primary = stringArg(args, 'name')
  else {
    for (const key of ['path', 'query', 'url', 'name', 'cmd', 'pattern']) {
      primary = stringArg(args, key)
      if (primary) break
    }
  }

  let kind: ToolDisplay['kind'] = 'json'
  if (normalized === 'bash' || normalized === 'shell') kind = 'command'
  else if (normalized === 'edit_file' || normalized === 'write_file') kind = 'edit'
  else if (normalized === 'list_files') kind = 'list'
  else if (['read_file', 'load_skill', 'load_mcp'].includes(normalized)) kind = 'silent'
  return { label: labelFor(name), primary, kind }
}

export type ToolActivityState = 'running' | 'complete' | 'failed'

export function toolActivityDescription(
  name: string,
  args: Record<string, unknown>,
  state: ToolActivityState,
): string {
  const normalized = normalizedToolName(name)
  const running = state === 'running'
  const failed = state === 'failed'
  const prefix = (active: string, complete: string, failure: string) =>
    failed ? failure : running ? active : complete
  const withTarget = (verb: string, target: string) => target ? `${verb}: ${target}` : verb

  if (normalized === 'bash' || normalized === 'shell') {
    return withTarget(prefix('Running command', 'Ran command', 'Command failed'), commandArg(args))
  }
  if (normalized === 'create_subagent') {
    return withTarget(prefix('Creating subagent', 'Created subagent', 'Could not create subagent'), stringArg(args, 'name') || stringArg(args, 'task'))
  }
  if (normalized === 'control_subagent') {
    return withTarget(prefix('Controlling subagent', 'Controlled subagent', 'Could not control subagent'), stringArg(args, 'name') || stringArg(args, 'id'))
  }
  if (normalized === 'update_subagent') {
    return withTarget(prefix('Updating subagent', 'Updated subagent', 'Could not update subagent'), stringArg(args, 'name') || stringArg(args, 'id'))
  }
  if (normalized === 'list_subagents') {
    return prefix('Listing subagents', 'Listed subagents', 'Could not list subagents')
  }
  if (normalized === 'list_files') {
    return withTarget(prefix('Listing files', 'Listed files', 'Could not list files'), listTarget(args))
  }
  if (normalized === 'read_file') {
    return withTarget(prefix('Reading file', 'Read file', 'Could not read file'), stringArg(args, 'path'))
  }
  if (normalized === 'edit_file' || normalized === 'write_file') {
    return withTarget(prefix('Editing file', 'Edited file', 'Could not edit file'), stringArg(args, 'path'))
  }
  if (normalized === 'search_files') {
    return withTarget(prefix('Searching files', 'Searched files', 'Could not search files'), stringArg(args, 'pattern') || stringArg(args, 'query'))
  }
  if (normalized === 'workspace_changes') {
    return prefix('Reviewing workspace changes', 'Reviewed workspace changes', 'Could not review workspace changes')
  }
  if (normalized === 'load_skill') {
    return withTarget(prefix('Loading skill', 'Loaded skill', 'Could not load skill'), stringArg(args, 'name'))
  }
  if (normalized === 'load_mcp') {
    return withTarget(prefix('Connecting MCP', 'Connected MCP', 'Could not connect MCP'), stringArg(args, 'name'))
  }
  if (normalized === 'web_fetch') {
    return withTarget(prefix('Fetching page', 'Fetched page', 'Could not fetch page'), stringArg(args, 'url'))
  }
  if (normalized === 'web_search') {
    return withTarget(prefix('Searching the web', 'Searched the web', 'Web search failed'), stringArg(args, 'query'))
  }
  if (normalized.startsWith('mcp:')) {
    return withTarget(prefix('Calling MCP tool', 'Called MCP tool', 'MCP tool failed'), name.slice(4))
  }

  const display = fallbackToolDisplay(name, args)
  const tool = display.label.replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase()
  return withTarget(prefix(`Running ${tool}`, `Finished ${tool}`, `${display.label} failed`), display.primary)
}

export function changeFromResult(result?: Record<string, unknown>): WorkspaceChange | null {
  const value = result?.change
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null
  const change = value as WorkspaceChange
  return typeof change.id === 'string' ? change : null
}

export function parseUnifiedDiff(patch: string): DiffLine[] {
  const output: DiffLine[] = []
  let oldLine = 0
  let newLine = 0
  let inHunk = false

  for (const line of patch.split('\n')) {
    const header = /^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/.exec(line)
    if (header) {
      oldLine = Number(header[1])
      newLine = Number(header[2])
      inHunk = true
      if (output.length > 0) output.push({ kind: 'meta', text: '…' })
      continue
    }
    if (!inHunk || line.startsWith('\\ No newline at end of file')) continue
    if (line.startsWith('+')) {
      output.push({ kind: 'add', text: line.slice(1), newLine: newLine++ })
    } else if (line.startsWith('-')) {
      output.push({ kind: 'remove', text: line.slice(1), oldLine: oldLine++ })
    } else if (line.startsWith(' ')) {
      output.push({ kind: 'context', text: line.slice(1), oldLine: oldLine++, newLine: newLine++ })
    }
  }
  return output
}

// Compatibility for edits saved before the backend change ledger existed.
export function legacyEditDiff(args: Record<string, unknown>): DiffLine[] {
  const oldLines = typeof args.old_text === 'string' ? args.old_text.split(/\r?\n/) : []
  const newLines = typeof args.new_text === 'string' ? args.new_text.split(/\r?\n/) : []
  if (oldLines.at(-1) === '') oldLines.pop()
  if (newLines.at(-1) === '') newLines.pop()
  const table = Array.from({ length: oldLines.length + 1 }, () =>
    Array<number>(newLines.length + 1).fill(0))
  for (let i = oldLines.length - 1; i >= 0; i--)
    for (let j = newLines.length - 1; j >= 0; j--)
      table[i][j] = oldLines[i] === newLines[j]
        ? table[i + 1][j + 1] + 1
        : Math.max(table[i + 1][j], table[i][j + 1])

  const output: DiffLine[] = []
  let i = 0, j = 0, oldLine = 1, newLine = 1
  while (i < oldLines.length || j < newLines.length) {
    if (i < oldLines.length && j < newLines.length && oldLines[i] === newLines[j]) {
      output.push({ kind: 'context', text: oldLines[i], oldLine: oldLine++, newLine: newLine++ })
      i++; j++
    } else if (j < newLines.length && (i === oldLines.length || table[i][j + 1] > table[i + 1][j])) {
      output.push({ kind: 'add', text: newLines[j++], newLine: newLine++ })
    } else {
      output.push({ kind: 'remove', text: oldLines[i++], oldLine: oldLine++ })
    }
  }
  return output
}
