/** Shared entrance timing, also used by deterministic product recordings. */
export const TOOL_ENTRANCE = { duration: 0.32, blur: 3 } as const

export function toolEntranceFrame(elapsed: number) {
  const progress = Math.max(0, Math.min(1, elapsed / TOOL_ENTRANCE.duration))
  const eased = 1 - (1 - progress) ** 3
  return { opacity: eased, blur: TOOL_ENTRANCE.blur * (1 - eased) }
}
