import { createElement, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Bot, ChevronDown, ChevronRight, FileDiff, FilePenLine, FileSearch, FileText, Globe2, List, Loader2, Redo2, Search, Terminal, Undo2, Wrench, type LucideIcon } from 'lucide-react'
import { AnimatePresence, motion } from 'framer-motion'
import { cn } from '#nebula/lib/utils'
import { Switch } from '#nebula/components/ui/switch'
import { capabilityMetadata } from '../ui/capability-metadata'
import { type ToolCallBlock as ToolCallBlockType } from '#nebula/hooks/useChat'
import { fetchWorkspaceChange, mutateWorkspaceChange, type WorkspaceChange } from '#nebula/lib/api'
import {
  changeFromResult,
  fallbackToolDisplay,
  legacyEditDiff,
  parseUnifiedDiff,
  toolActivityDescription,
  type DiffLine,
} from '#nebula/lib/toolPresentation'

function toolResultFailed(result: unknown): boolean {
  if (!result || typeof result !== 'object') return false
  const value = result as Record<string, unknown>
  if (typeof value.error === 'string' && value.error.trim().length > 0) return true
  if (typeof value.exit_code === 'number' && value.exit_code !== 0) return true
  if (typeof value.exitCode === 'number' && value.exitCode !== 0) return true
  return typeof value.status === 'string' && ['error', 'failed', 'failure'].includes(value.status.toLowerCase())
}

export function ToolCallCard({ toolCall }: { toolCall: ToolCallBlockType }) {
  const [open, setOpen] = useState(false)
  const [view, setView] = useState<'tool' | 'raw'>('tool')
  const [viewTransitioning, setViewTransitioning] = useState(false)
  const [viewBlurring, setViewBlurring] = useState(false)
  const outputScrollerRef = useRef<HTMLDivElement>(null)
  const viewStartHeightRef = useRef<number | null>(null)
  const viewAnimationFrameRef = useRef<number | null>(null)
  const viewTransitionTimerRef = useRef<number | null>(null)
  const viewBlurTimerRef = useRef<number | null>(null)
  const initialChange = changeFromResult(toolCall.result)
  const [change, setChange] = useState<WorkspaceChange | null>(null)
  const [changeError, setChangeError] = useState('')
  const [changing, setChanging] = useState(false)
  const pending = toolCall.result === undefined
  const display = toolCall.display ?? fallbackToolDisplay(toolCall.name, toolCall.args)
  const changeId = initialChange?.id
  const effectiveChange = change?.id === changeId ? change : initialChange
  const failed = toolResultFailed(toolCall.result)
  const activityState = pending ? 'running' : failed ? 'failed' : 'complete'
  const activity = toolActivityDescription(toolCall.name, toolCall.args, activityState)

  useEffect(() => {
    if (!changeId) return
    let active = true
    fetchWorkspaceChange(changeId)
      .then(current => { if (active) setChange(current) })
      .catch(() => { /* the immutable result still renders if the backend is offline */ })
    return () => { active = false }
  }, [changeId])

  useEffect(() => () => {
    if (viewAnimationFrameRef.current !== null)
      window.cancelAnimationFrame(viewAnimationFrameRef.current)
    if (viewTransitionTimerRef.current !== null)
      window.clearTimeout(viewTransitionTimerRef.current)
    if (viewBlurTimerRef.current !== null)
      window.clearTimeout(viewBlurTimerRef.current)
  }, [])

  useLayoutEffect(() => {
    const scroller = outputScrollerRef.current
    const startHeight = viewStartHeightRef.current
    if (!scroller || startHeight === null) return
    viewStartHeightRef.current = null

    if (viewAnimationFrameRef.current !== null)
      window.cancelAnimationFrame(viewAnimationFrameRef.current)

    // Measure the destination with its real scrollbar state, then animate from
    // the exact rendered height of the previous view. This makes a scrollbar
    // appearing or disappearing part of the height transition instead of a
    // separate layout change at either end.
    scroller.style.transition = 'none'
    scroller.style.overflow = 'auto'
    scroller.style.height = 'auto'
    const targetHeight = scroller.getBoundingClientRect().height
    scroller.style.height = `${startHeight}px`
    void scroller.offsetHeight
    scroller.style.overflow = 'hidden'

    viewAnimationFrameRef.current = window.requestAnimationFrame(() => {
      scroller.style.transition = 'height 300ms cubic-bezier(0.22, 1, 0.36, 1)'
      scroller.style.height = `${targetHeight}px`
      viewAnimationFrameRef.current = null
    })
  }, [view])

  const switchView = (raw: boolean) => {
    const nextView = raw ? 'raw' : 'tool'
    if (nextView === view) return
    if (viewTransitionTimerRef.current !== null)
      window.clearTimeout(viewTransitionTimerRef.current)
    if (viewBlurTimerRef.current !== null)
      window.clearTimeout(viewBlurTimerRef.current)
    viewStartHeightRef.current = outputScrollerRef.current?.getBoundingClientRect().height ?? null
    setViewTransitioning(true)
    setViewBlurring(true)
    setView(nextView)
    viewBlurTimerRef.current = window.setTimeout(() => {
      setViewBlurring(false)
      viewBlurTimerRef.current = null
    }, 90)
    viewTransitionTimerRef.current = window.setTimeout(() => {
      const scroller = outputScrollerRef.current
      if (scroller) {
        scroller.style.transition = ''
        scroller.style.height = 'auto'
        scroller.style.overflow = ''
      }
      setViewTransitioning(false)
      viewTransitionTimerRef.current = null
    }, 340)
  }

  const mutate = async () => {
    if (!effectiveChange || changing) return
    const action = effectiveChange.status === 'reverted' ? 'unrevert' : 'revert'
    setChanging(true)
    setChangeError('')
    try {
      setChange(await mutateWorkspaceChange(effectiveChange.id, action))
    } catch (error) {
      setChangeError(error instanceof Error ? error.message : String(error))
    } finally {
      setChanging(false)
    }
  }

  const rawPayload: Record<string, unknown> = {
    id: toolCall.id,
    item_id: toolCall.itemId,
    name: toolCall.name,
    args: toolCall.args,
  }
  if (toolCall.result !== undefined) rawPayload.result = toolCall.result

  const toolView = (
    <div className="min-w-0">
      {pending
        ? <div className="px-3 pt-2 pb-3 font-mono text-[var(--color-text-disabled)]">
            {toolCall.name === 'bash' || toolCall.name === 'Bash'
              ? 'Waiting for permission or output…'
              : 'Waiting for output…'}
          </div>
        : <ToolOutput toolCall={toolCall} displayKind={display.kind} change={effectiveChange} />}
      {effectiveChange && (
        <div className="flex items-center gap-2 border-t border-[var(--color-border-subtle)] p-2">
          <button
            onClick={mutate}
            disabled={changing}
            className="inline-flex h-7 items-center justify-center gap-1.5 rounded-lg bg-[var(--color-surface-recessed)] pl-1.5 pr-2.5 text-[11px] font-medium leading-none text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)] disabled:opacity-40"
          >
            {changing
              ? <Loader2 size={10} className="animate-spin" />
              : effectiveChange.status === 'reverted' ? <Redo2 size={10} /> : <Undo2 size={10} />}
            {effectiveChange.status === 'reverted' ? 'Unrevert' : 'Revert'}
          </button>
          <span className={cn(
            'text-[10px] font-semibold uppercase tracking-widest select-none',
            effectiveChange.status === 'reverted' ? 'text-[var(--color-status-warning)]' : 'text-[var(--color-status-success)]',
          )}>{effectiveChange.status}</span>
          {changeError && <span className="text-[10px] text-[var(--color-status-danger)]">{changeError}</span>}
        </div>
      )}
    </div>
  )
  const rawView = (
    <pre className="w-max min-w-full bg-transparent px-3 pt-2 pb-3 font-mono text-[11px] leading-5 text-[var(--color-text-muted)] whitespace-pre">
      {JSON.stringify(rawPayload, null, 2)}
    </pre>
  )

  return (
    <div className="my-1 w-full min-w-0 max-w-full text-[12px] leading-5">
      <button
        type="button"
        onClick={() => setOpen(current => !current)}
        aria-expanded={open}
        className="group/tool flex w-full min-w-0 max-w-full items-center gap-2 rounded-lg px-1.5 py-1 text-left outline-none focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1"
      >
        <ToolActivityIcon name={toolCall.name} failed={failed} />
        <span className={cn(
          'min-w-0 flex-1 truncate text-[12px]',
          pending
            ? 'tool-activity-running'
            : failed
              ? 'text-[var(--color-status-danger)]'
              : 'text-[var(--color-text-muted)] transition-colors group-hover/tool:text-[var(--color-text-primary)]',
        )}>
          {activity}
        </span>
        {open
          ? <ChevronDown size={13} className="shrink-0 text-[var(--color-text-subtle)]" />
          : <ChevronRight size={13} className="shrink-0 text-[var(--color-text-subtle)]" />}
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="tool-content"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ height: { duration: 0.24, ease: [0.22, 1, 0.36, 1] }, opacity: { duration: 0.16 } }}
            className="min-w-0 max-w-full overflow-hidden"
          >
            <div className="mt-1 min-w-0 max-w-full overflow-hidden rounded-xl bg-[var(--color-surface-panel)]">
              <div className="flex items-center justify-between gap-3 px-3 py-1">
                <span className="min-w-0 truncate font-mono text-[11px] leading-6 text-[var(--color-text-subtle)]">
                  {display.label}
                </span>
                <label className="flex shrink-0 cursor-pointer items-center gap-1.5 text-[11px] leading-6 text-[var(--color-text-subtle)]">
                  <Switch
                    checked={view === 'raw'}
                    onCheckedChange={switchView}
                    aria-label="Show raw tool call"
                  />
                  <span>Raw</span>
                </label>
              </div>
              <div
                ref={outputScrollerRef}
                data-transitioning={viewTransitioning || undefined}
                className="tool-output-scroller w-full max-h-[24rem] min-w-0 max-w-full overflow-auto"
              >
                <AnimatePresence initial={false} mode="popLayout">
                  <motion.div
                    key={view}
                    initial={{ opacity: 0, y: 3 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -3 }}
                    transition={{ duration: 0.16, ease: 'easeOut' }}
                    className={cn(
                      'w-full min-w-0 max-w-full transition-[filter] duration-100 ease-out',
                      viewBlurring && 'blur-[2px]',
                    )}
                  >
                    {view === 'raw' ? rawView : toolView}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function toolIconFor(name: string): LucideIcon {
  const normalized = name.trim().replace(/([a-z0-9])([A-Z])/g, '$1_$2').replace(/[-\s]+/g, '_').toLowerCase()
  if (['create_subagent', 'control_subagent', 'update_subagent'].includes(normalized)) return Bot
  if (normalized === 'list_subagents' || normalized === 'list_files') return List
  if (normalized === 'bash' || normalized === 'shell') return Terminal
  if (normalized === 'edit_file' || normalized === 'write_file') return FilePenLine
  if (normalized === 'read_file') return FileText
  if (normalized === 'search_files') return FileSearch
  if (normalized === 'workspace_changes') return FileDiff
  if (normalized === 'load_skill') return capabilityMetadata.skills.icon
  if (normalized === 'load_mcp' || normalized.startsWith('mcp:')) return capabilityMetadata.mcps.icon
  if (normalized.includes('command')) return capabilityMetadata.commands.icon
  if (normalized.includes('hook')) return capabilityMetadata.hooks.icon
  if (normalized.includes('rule') || normalized.includes('instruction')) return capabilityMetadata.rules.icon
  if (normalized === 'web_search') return Search
  if (normalized === 'web_fetch') return Globe2
  return Wrench
}

function ToolActivityIcon({ name, failed }: { name: string; failed: boolean }) {
  const Icon = toolIconFor(name)
  return createElement(Icon, {
    size: 13,
    'aria-hidden': true,
    className: cn(
      'shrink-0 transition-colors',
      failed ? 'text-[var(--color-status-danger)]' : 'text-[var(--color-text-subtle)]',
    ),
  })
}

function ToolOutput({
  toolCall,
  displayKind,
  change,
}: {
  toolCall: ToolCallBlockType
  displayKind: string
  change: WorkspaceChange | null
}) {
  const result = toolCall.result
  if (!result) return <EmptyToolOutput />
  if (typeof result.error === 'string') {
    return <div className="bg-[var(--color-status-danger-surface)] px-3 pt-2 pb-3 font-mono text-[var(--color-status-danger)] whitespace-pre-wrap">error: {result.error}</div>
  }
  if ((toolCall.name === 'read_file' || toolCall.name === 'ReadFile') && typeof result.content === 'string') {
    return <ReadFileOutput result={result} />
  }
  if ((toolCall.name === 'load_skill' || toolCall.name === 'LoadSkill') && typeof result.content === 'string') {
    return <SkillOutput content={result.content} />
  }
  if (displayKind === 'silent') return <EmptyToolOutput />

  if (displayKind === 'edit') {
    const lines = change?.patch ? parseUnifiedDiff(change.patch) : legacyEditDiff(toolCall.args)
    return <DiffOutput lines={lines} />
  }

  if (displayKind === 'list' && Array.isArray(result.entries)) {
    return (
      <div className="min-w-max bg-transparent px-3 pt-2 pb-3 font-mono text-[var(--color-text-muted)]">
        {result.entries.map((entry, index) => {
          const path = entry && typeof entry === 'object' && 'path' in entry
            ? String((entry as { path: unknown }).path)
            : JSON.stringify(entry)
          return <div key={index} className="truncate">{path}</div>
        })}
        {result.truncated === true && <div>…</div>}
      </div>
    )
  }

  const output = formatResult(result)
  if (!output) return <EmptyToolOutput />
  return (
    <pre className="min-w-max bg-transparent px-3 pt-2 pb-3 font-mono text-[var(--color-text-muted)] whitespace-pre">
      {output}
    </pre>
  )
}

function SkillOutput({ content }: { content: string }) {
  return (
    <pre className="min-w-max bg-transparent px-3 pt-2 pb-3 font-mono text-[11px] leading-5 text-[var(--color-text-muted)] whitespace-pre">
      {content}
    </pre>
  )
}

function ReadFileOutput({ result }: { result: Record<string, unknown> }) {
  const start = typeof result.line_start === 'number' ? result.line_start : 1
  const lines = String(result.content).split(/\r?\n/)
  if (lines.length > 1 && lines.at(-1) === '') lines.pop()
  const numberWidth = Math.max(1, String(start + Math.max(0, lines.length - 1)).length)
  return (
    <div className="min-w-max bg-transparent pt-2 pb-3 font-mono text-[11px] leading-5">
      {lines.map((line, index) => (
        <div key={index} className="flex min-w-0 items-start">
          <span
            className="flex-shrink-0 border-r border-[var(--color-border-subtle)] px-2 text-right text-[var(--color-text-subtle)] select-none"
            style={{ width: `calc(${numberWidth}ch + 1rem)` }}
          >
            {start + index}
          </span>
          <span className="px-3 text-[var(--color-text-muted)] whitespace-pre">
            {line || ' '}
          </span>
        </div>
      ))}
      {result.truncated === true && (
        <div className="flex">
          <span style={{ width: `calc(${numberWidth}ch + 1rem)` }} className="flex-shrink-0 border-r border-[var(--color-border-subtle)]" />
          <span className="px-3 text-[var(--color-status-warning)]">… truncated</span>
        </div>
      )}
      </div>
  )
}

function EmptyToolOutput() {
  return <div className="px-3 pt-2 pb-3 text-[11px] italic text-[var(--color-text-disabled)]">No output</div>
}

function DiffOutput({ lines }: { lines: DiffLine[] }) {
  if (lines.length === 0) return <EmptyToolOutput />
  const added = lines.filter(line => line.kind === 'add').length
  const removed = lines.filter(line => line.kind === 'remove').length
  return (
    <div className="bg-transparent font-mono text-[11px] leading-5">
      <div className="flex items-center gap-2 border-b border-[var(--color-border-subtle)] px-3 py-1.5 text-[11px]">
        <span className="text-[var(--color-text-subtle)]">Git diff</span>
        <span className="ml-auto text-[var(--color-status-success)]">+{added}</span>
        <span className="text-[var(--color-status-danger)]">−{removed}</span>
      </div>
      <div className="max-h-[28rem] overflow-auto">
        {lines.map((line, index) => {
          if (line.kind === 'meta') {
            return <div key={index} className="border-y border-[var(--color-border-subtle)] bg-[var(--color-status-info-surface)] px-3 py-0.5 text-[var(--color-status-info)]">{line.text}</div>
          }
          const oldNumber = line.kind === 'add' ? '' : line.oldLine
          const newNumber = line.kind === 'remove' ? '' : line.newLine
          const marker = line.kind === 'remove' ? '−' : line.kind === 'add' ? '+' : ' '
          return (
            <div key={index} className={cn(
              'flex min-w-max',
              line.kind === 'remove' && 'bg-[var(--color-status-danger-surface)]',
              line.kind === 'add' && 'bg-[var(--color-status-success-surface)]',
            )}>
              <span className="w-10 flex-shrink-0 border-r border-[var(--color-border-subtle)] pr-2 text-right text-[var(--color-text-disabled)] select-none">{oldNumber}</span>
              <span className="w-10 flex-shrink-0 border-r border-[var(--color-border-subtle)] pr-2 text-right text-[var(--color-text-disabled)] select-none">{newNumber}</span>
              <span className={cn(
                'w-7 flex-shrink-0 text-center select-none',
                line.kind === 'remove' && 'text-[var(--color-status-danger)]',
                line.kind === 'add' && 'text-[var(--color-status-success)]',
                line.kind === 'context' && 'text-[var(--color-text-disabled)]',
              )}>{marker}</span>
              <span className={cn(
                'pr-4 whitespace-pre',
                line.kind === 'remove' && 'text-[var(--color-status-danger)]',
                line.kind === 'add' && 'text-[var(--color-status-success)]',
                line.kind === 'context' && 'text-[var(--color-text-muted)]',
              )}>{line.text}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function formatResult(result: Record<string, unknown>): string {
  if ('output' in result && typeof result.output === 'string') {
    const code = 'exit_code' in result ? Number(result.exit_code) : 0
    return (code !== 0 ? `exit ${code}\n` : '') + result.output
  }
  if ('error' in result && typeof result.error === 'string') return result.error
  return JSON.stringify(result, null, 2)
}
