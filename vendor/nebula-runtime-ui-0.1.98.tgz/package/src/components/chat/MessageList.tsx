import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { type ChatMessage } from '#nebula/hooks/useChat'
import { MessageBubble } from './MessageBubble'
import { cn } from '#nebula/lib/utils'

interface Props {
  messages: ChatMessage[]
}

export function MessageList({ messages }: Props) {
  const listRef = useRef<HTMLDivElement>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const frameRef = useRef<number | null>(null)
  const lastFrameRef = useRef<number | null>(null)
  const mountedRef = useRef(false)
  const pinnedToBottomRef = useRef(true)
  const userDetachedRef = useRef(false)
  const lastScrollTopRef = useRef(0)
  const revealFrameRef = useRef<number | null>(null)
  const [revealOrder, setRevealOrder] = useState<Record<string, number> | null>(null)
  const reduceMotion = useReducedMotion()
  const latestAssistantId = [...messages].reverse().find(message => message.role === 'assistant')?.id
  const messageIds = messages.map(message => message.id).join('\u0000')

  const viewport = useCallback(() =>
    bottomRef.current?.closest<HTMLElement>('[data-scroll-viewport]') ?? null,
  [])

  const stopFollowing = useCallback(() => {
    userDetachedRef.current = true
    pinnedToBottomRef.current = false
    if (frameRef.current !== null) {
      window.cancelAnimationFrame(frameRef.current)
      frameRef.current = null
    }
    lastFrameRef.current = null
  }, [])

  const followBottom = useCallback((immediate = false) => {
    const element = viewport()
    if (!element) return

    if (immediate) {
      element.scrollTop = element.scrollHeight - element.clientHeight
      return
    }
    if (frameRef.current !== null) return

    const step = (time: number) => {
      const current = viewport()
      if (!current) {
        frameRef.current = null
        lastFrameRef.current = null
        return
      }

      const destination = Math.max(0, current.scrollHeight - current.clientHeight)
      const distance = destination - current.scrollTop
      const elapsed = lastFrameRef.current === null ? 16 : Math.min(50, time - lastFrameRef.current)
      lastFrameRef.current = time

      if (Math.abs(distance) <= 0.5) {
        current.scrollTop = destination
        frameRef.current = null
        lastFrameRef.current = null
        return
      }

      // Time-based easing keeps the same softness at different frame rates.
      current.scrollTop += distance * (1 - Math.exp(-elapsed / 72))
      frameRef.current = window.requestAnimationFrame(step)
    }

    frameRef.current = window.requestAnimationFrame(step)
  }, [viewport])

  useLayoutEffect(() => {
    if (!mountedRef.current) followBottom(true)
    else if (pinnedToBottomRef.current) followBottom()
    mountedRef.current = true
  }, [messages, followBottom])

  useEffect(() => {
    const element = viewport()
    if (!element) return
    lastScrollTopRef.current = element.scrollTop

    const updatePinnedState = () => {
      const distanceFromBottom = element.scrollHeight - element.clientHeight - element.scrollTop
      const movedUp = element.scrollTop < lastScrollTopRef.current - 0.5
      lastScrollTopRef.current = element.scrollTop

      if (movedUp) stopFollowing()
      if (userDetachedRef.current) {
        if (distanceFromBottom <= 2) {
          userDetachedRef.current = false
          pinnedToBottomRef.current = true
        } else {
          pinnedToBottomRef.current = false
        }
        return
      }
      pinnedToBottomRef.current = distanceFromBottom <= 48
    }
    const takeScrollControl = () => stopFollowing()
    const takeUpwardWheelControl = (event: WheelEvent) => {
      if (event.deltaY < 0) stopFollowing()
    }
    const takeKeyboardControl = (event: KeyboardEvent) => {
      if (
        event.key === 'ArrowUp'
        || event.key === 'PageUp'
        || event.key === 'Home'
        || event.key === ' '
      ) {
        stopFollowing()
      }
    }

    updatePinnedState()
    element.addEventListener('scroll', updatePinnedState, { passive: true })
    element.addEventListener('wheel', takeUpwardWheelControl, { passive: true })
    element.addEventListener('touchstart', takeScrollControl, { passive: true })
    element.addEventListener('pointerdown', takeScrollControl, { passive: true })
    element.addEventListener('keydown', takeKeyboardControl)
    return () => {
      element.removeEventListener('scroll', updatePinnedState)
      element.removeEventListener('wheel', takeUpwardWheelControl)
      element.removeEventListener('touchstart', takeScrollControl)
      element.removeEventListener('pointerdown', takeScrollControl)
      element.removeEventListener('keydown', takeKeyboardControl)
    }
  }, [stopFollowing, viewport])

  useLayoutEffect(() => {
    if (reduceMotion) {
      revealFrameRef.current = window.requestAnimationFrame(() => {
        setRevealOrder({})
        revealFrameRef.current = null
      })
      return () => {
        if (revealFrameRef.current !== null)
          window.cancelAnimationFrame(revealFrameRef.current)
      }
    }

    revealFrameRef.current = window.requestAnimationFrame(() => {
      const list = listRef.current
      const scrollViewport = viewport()
      if (!list || !scrollViewport) return

      const viewportRect = scrollViewport.getBoundingClientRect()
      const visible = Array.from(list.querySelectorAll<HTMLElement>('[data-message-id]'))
        .filter(element => {
          const rect = element.getBoundingClientRect()
          return rect.bottom >= viewportRect.top && rect.top <= viewportRect.bottom + 24
        })
        .sort((left, right) => left.getBoundingClientRect().top - right.getBoundingClientRect().top)

      const order: Record<string, number> = {}
      visible.forEach((element, index) => {
        const id = element.dataset.messageId
        if (id) order[id] = index
      })
      setRevealOrder(order)
      revealFrameRef.current = null
    })

    return () => {
      if (revealFrameRef.current !== null)
        window.cancelAnimationFrame(revealFrameRef.current)
    }
  }, [messageIds, reduceMotion, viewport])

  useEffect(() => {
    const list = listRef.current
    if (!list || typeof ResizeObserver === 'undefined') return
    const observer = new ResizeObserver(() => {
      if (pinnedToBottomRef.current) followBottom()
    })
    observer.observe(list)
    return () => observer.disconnect()
  }, [followBottom])

  useEffect(() => () => {
    if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current)
    if (revealFrameRef.current !== null) window.cancelAnimationFrame(revealFrameRef.current)
  }, [])

  return (
    <div ref={listRef} className="mx-auto flex w-full min-w-0 max-w-[var(--content-width-reading)] flex-col gap-8 overflow-x-hidden px-4 py-8 sm:px-6">
      <AnimatePresence>
        {messages.map((msg, index) => {
          const previous = messages[index - 1]
          const startsTurn = msg.role === 'assistant' && previous?.role === 'user'
          let turnCompletedAtMs: number | undefined
          let turnWorking = false
          if (startsTurn) {
            const candidates: number[] = []
            for (let cursor = index; cursor < messages.length; cursor++) {
              const candidate = messages[cursor]
              if (cursor > index && candidate.role === 'user') break
              if (candidate.streaming) turnWorking = true
              if (candidate.completedAtMs) candidates.push(candidate.completedAtMs)
              else if (candidate.createdAtMs) candidates.push(candidate.createdAtMs)
            }
            if (candidates.length > 0)
              turnCompletedAtMs = Math.max(...candidates)
          }
          const followsToolOnlyAssistant =
            msg.role === 'assistant' &&
            msg.blocks.some(block => block.type === 'text') &&
            previous?.role === 'assistant' &&
            previous.blocks.some(block => block.type === 'tool_call') &&
            !previous.blocks.some(block => block.type === 'text')
          const visibleOrder = revealOrder?.[msg.id]
          const revealReady = revealOrder !== null

          return (
            <motion.div
              key={msg.id}
              data-message-id={msg.id}
              initial={reduceMotion ? false : { opacity: 0, y: 3, filter: 'blur(2px)' }}
              animate={revealReady
                ? { opacity: 1, y: 0, filter: 'blur(0px)' }
                : { opacity: 0, y: 3, filter: 'blur(2px)' }}
              transition={{
                duration: reduceMotion ? 0 : visibleOrder === undefined ? 0.18 : 0.52,
                delay: reduceMotion || visibleOrder === undefined ? 0 : Math.min(visibleOrder, 7) * 0.075,
                ease: [0.22, 1, 0.36, 1],
              }}
              className={cn('min-w-0 max-w-full', followsToolOnlyAssistant && '-mt-6')}
            >
              {startsTurn && (previous.createdAtMs ?? msg.createdAtMs) && (
                <TurnDurationHeader
                  startedAtMs={(previous.createdAtMs ?? msg.createdAtMs)!}
                  completedAtMs={turnCompletedAtMs}
                  working={turnWorking}
                />
              )}
              <MessageBubble
                message={msg}
                isLatestAssistant={msg.id === latestAssistantId}
              />
            </motion.div>
          )
        })}
      </AnimatePresence>
      <div ref={bottomRef} />
    </div>
  )
}

function TurnDurationHeader({
  startedAtMs,
  completedAtMs,
  working,
}: {
  startedAtMs: number
  completedAtMs?: number
  working: boolean
}) {
  const [now, setNow] = useState(() => Date.now())

  useEffect(() => {
    if (!working) return
    const timer = window.setInterval(() => setNow(Date.now()), 1000)
    return () => window.clearInterval(timer)
  }, [working])

  const end = working ? now : (completedAtMs ?? startedAtMs)
  const totalSeconds = Math.max(0, Math.floor((end - startedAtMs) / 1000))
  const minutes = Math.floor(totalSeconds / 60)
  const seconds = totalSeconds % 60

  return (
    <div className="mb-3 w-full select-none border-b border-[var(--color-border-subtle)] text-[11px] leading-5 text-white/35">
      <span className="whitespace-nowrap">
        {working ? 'Working' : 'Worked'} for {minutes}m {seconds}s
      </span>
    </div>
  )
}
