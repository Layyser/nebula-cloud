import { useEffect, useRef, useState } from 'react'
import { LayoutGroup, motion, useReducedMotion } from 'framer-motion'
import { Search, Folder, MessageSquare, ChevronLeft, ChevronRight, LoaderCircle, X } from 'lucide-react'
import { ContentContainer, PageHeader } from '#nebula/components/ui/layout'
import { Button } from '#nebula/components/ui/button'

// Deliberately isolated fixtures: this preview never queries or opens real sessions.
const examples = [
  ['Nubols Cloud', 'Polish the landing page', 'The hero now reveals each section in sequence.'],
  ['Minecraft', 'Bring the server online', 'The server is ready for players to connect.'],
  ['Workspace', 'Plan the week', 'Here are the three priorities we agreed on.'],
  ['Nubols Cloud', 'Fix mobile navigation', 'The sidebar now fits the available screen height.'],
  ['Design system', 'Refine the terminal tabs', 'Opening and closing tabs now feels smoother.'],
  ['Minecraft', 'Back up the world', 'The latest world snapshot is ready.'],
  ['Research', 'Compare hosting options', 'I put together a comparison of the available options.'],
  ['Nubols Cloud', 'Review account settings', 'Appearance preferences are remembered between visits.'],
  ['Design system', 'Explore search interactions', 'A quiet loading state keeps the results readable.'],
  ['Workspace', 'Organize project notes', 'The notes are grouped by project and next steps.'],
  ['Research', 'Summarize customer feedback', 'The most common requests focus on navigation.'],
  ['Minecraft', 'Tune server performance', 'We can reduce the view distance to keep memory stable.'],
  ['Nubols Cloud', 'Prepare release notes', 'The release includes fixes for small screens.'],
  ['Design system', 'Review light mode', 'The contrast is consistent across cards and menus.'],
  ['Workspace', 'Create a project checklist', 'Everything is organized for the next iteration.'],
  ['Research', 'Outline the documentation', 'The guide starts with setup and a first example.'],
  ['Nubols Cloud', 'Check the deployment', 'The application is healthy after the update.'],
  ['Minecraft', 'Set up player access', 'The allowlist is ready to review.'],
]
const chats = examples.map(([project, name, message], index) => ({
  id: index, project, name, message,
  date: new Date(Date.now() - index * 19 * 3600000),
}))
const suggestions = ['Nubols Cloud', 'Minecraft', 'Design system', 'Workspace', 'Research', 'Release notes', 'Mobile navigation']

export function SearchView() {
  const [query, setQuery] = useState('')
  const [settledQuery, setSettledQuery] = useState('')
  const [busy, setBusy] = useState(false)
  const [focused, setFocused] = useState(false)
  const [option, setOption] = useState(-1)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(5)
  const listRef = useRef<HTMLDivElement>(null)
  const reducedMotion = useReducedMotion()
  const completions = query.trim() ? suggestions.filter(value => value.toLowerCase().includes(query.toLowerCase()) && value.toLowerCase() !== query.toLowerCase()).slice(0, 4) : []
  const showSuggestions = focused && completions.length > 0

  useEffect(() => {
    const element = listRef.current
    if (!element) return
    const resize = () => setPageSize(Math.max(1, Math.floor(element.clientHeight / 72)))
    resize()
    const observer = new ResizeObserver(resize)
    observer.observe(element)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    setBusy(true)
    const timer = window.setTimeout(() => {
      setSettledQuery(query.trim())
      setPage(1)
      setBusy(false)
    }, 420)
    return () => window.clearTimeout(timer)
  }, [query])

  // Simulate incremental search using only the local sample text.
  const results = settledQuery ? chats.filter(chat => `${chat.project} ${chat.name} ${chat.message}`.toLowerCase().includes(settledQuery.toLowerCase())) : chats
  const pages = Math.max(1, Math.ceil(results.length / pageSize))
  const currentPage = Math.min(page, pages)
  const firstPage = Math.max(1, Math.min(currentPage - 2, pages - 4))
  const pageNumbers = Array.from({ length: Math.min(5, pages) }, (_, index) => firstPage + index)
  const visible = results.slice((currentPage - 1) * pageSize, currentPage * pageSize)
  const choose = (value: string) => { setQuery(value); setFocused(false); setOption(-1) }

  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden bg-[var(--color-surface-page)] text-[var(--color-text-primary)]">
      <ContentContainer gutter="workspace" spacing="none" width="workspace" className="flex min-h-0 flex-1 flex-col pt-8 pb-4 sm:pb-8">
        <PageHeader title="Search" description="Find a conversation. Pick up where you left off." withBackdrop={false} />
        <div className="relative z-20 h-12 shrink-0" onBlur={event => { if (!event.currentTarget.contains(event.relatedTarget)) setFocused(false) }}>
          <div className="ui-border-surface absolute inset-x-0 top-0 overflow-hidden rounded-xl bg-[var(--color-surface-panel)] shadow-[var(--shadow-surface-subtle)] focus-within:[--ui-border-color:var(--color-border-focus)]">
          <div className="flex h-12 items-center gap-3 pl-4 pr-2">
            <Search size={17} className="shrink-0 text-[var(--color-text-muted)]" />
            <input
              role="combobox" aria-label="Search conversations" aria-expanded={showSuggestions} aria-controls="search-suggestions" aria-autocomplete="list"
              aria-activedescendant={showSuggestions && option >= 0 ? `search-option-${option}` : undefined}
              value={query} placeholder="Search chats or projects…"
              onFocus={() => setFocused(true)}
              onChange={event => { setQuery(event.target.value); setFocused(true); setOption(-1) }}
              onKeyDown={event => {
                if (event.key === 'Escape') { setFocused(false); setOption(-1) }
                if (showSuggestions && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
                  event.preventDefault()
                  setOption(current => (current + (event.key === 'ArrowDown' ? 1 : -1) + completions.length) % completions.length)
                }
                if (event.key === 'Enter') { event.preventDefault(); choose(option >= 0 && showSuggestions ? completions[option] : query) }
              }}
              className="min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-[var(--color-text-disabled)] sm:text-sm"
            />
            {busy && <LoaderCircle aria-hidden="true" size={15} className="shrink-0 animate-spin motion-reduce:animate-none text-[var(--color-text-muted)]" />}
            {query && <Button variant="ghost" size="compact" className="h-8 w-8 rounded-md p-0" aria-label="Clear search" onClick={() => { setQuery(''); setOption(-1) }}><X size={14} /></Button>}
          </div>
          {showSuggestions && <div id="search-suggestions" role="listbox" aria-label="Suggestions" className="px-1 pb-1">
            {completions.map((value, index) => <button key={value} id={`search-option-${index}`} role="option" aria-selected={option === index} tabIndex={-1} onMouseDown={event => event.preventDefault()} onClick={() => choose(value)} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-[var(--color-surface-hover)] ${option === index ? 'bg-[var(--color-surface-selected)]' : ''}`}><Search size={14} className="text-[var(--color-text-muted)]" />{value}</button>)}
          </div>}
          </div>
        </div>
        <div className="flex shrink-0 items-center justify-between gap-2 py-4 text-xs text-[var(--color-text-muted)]">
          <span role="status">{busy ? 'Searching…' : settledQuery ? `${results.length} conversations` : 'Recent conversations'}</span>
          <span>Sample chats</span>
        </div>
        <div ref={listRef} className="min-h-0 flex-1 overflow-hidden" aria-busy={busy}>
          <motion.div key={`${settledQuery}-${currentPage}`} initial={reducedMotion ? false : { opacity: 0, y: 5 }} animate={{ opacity: busy ? 0.5 : 1, y: 0 }} transition={{ duration: reducedMotion ? 0 : 0.2 }}>
            {visible.map(chat => <article key={chat.id} className="group relative flex h-[72px] w-full min-w-0 cursor-pointer items-center gap-3 rounded-xl px-4 text-left transition-none after:pointer-events-none after:absolute after:inset-x-0 after:bottom-0 after:h-px after:bg-[var(--color-border-subtle)] last:after:hidden hover:bg-[var(--color-surface-hover)] hover:after:opacity-0 [&:has(+article:hover)]:after:opacity-0 sm:gap-4 sm:px-5">
              <MessageSquare size={18} className="shrink-0 text-[var(--color-text-disabled)]" />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{chat.name}</div>
                <div className="mt-1 truncate text-xs text-[var(--color-text-muted)]">{chat.message}</div>
              </div>
              <div className="w-[30%] min-w-0 max-w-48 shrink-0 text-right text-xs text-[var(--color-text-muted)]">
                <time dateTime={chat.date.toISOString()} title={chat.date.toLocaleString()} className="block leading-5">{chat.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</time>
                <span className="mt-1 flex items-center justify-end gap-1.5"><Folder size={12} className="shrink-0" /><span className="truncate">{chat.project}</span></span>
              </div>
            </article>)}
            {!results.length && <div className="py-10 text-center text-sm text-[var(--color-text-muted)]"><Search size={24} className="mx-auto mb-3" /><p>No sample conversations found.</p><p className="mt-2 text-xs">Try Minecraft, mobile, or release.</p></div>}
          </motion.div>
        </div>
        <LayoutGroup id="search-pagination">
        <nav aria-label="Search result pages" className="flex h-12 shrink-0 items-center justify-center gap-1 pt-2 sm:gap-2">
          <div className="size-8">{currentPage > 1 && <Button variant="ghost" size="compact" className="h-8 w-8 rounded-md p-0" aria-label="Previous page" onClick={() => setPage(currentPage - 1)}><ChevronLeft size={16} /></Button>}</div>
          {pageNumbers.map(number => <button key={number} type="button" aria-label={`Page ${number}`} aria-current={number === currentPage ? 'page' : undefined} onClick={() => setPage(number)} className={`relative grid size-8 cursor-pointer place-items-center text-xs tabular-nums outline-none transition-colors focus-visible:outline focus-visible:outline-1 focus-visible:outline-[var(--color-border-focus)] ${number === currentPage ? 'text-[var(--color-text-primary)]' : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)]'}`}>
            {number}
            {number === currentPage && <motion.span
              aria-hidden="true"
              layoutId="selected-page-underline"
              className="pointer-events-none absolute inset-x-0 bottom-0 h-0.5 bg-[var(--color-text-primary)]"
              transition={{ duration: reducedMotion ? 0 : 0.26, ease: [0.22, 1, 0.36, 1] }}
            />}
          </button>)}
          <div className="size-8">{currentPage < pages && <Button variant="ghost" size="compact" className="h-8 w-8 rounded-md p-0" aria-label="Next page" onClick={() => setPage(currentPage + 1)}><ChevronRight size={16} /></Button>}</div>
        </nav>
        </LayoutGroup>
      </ContentContainer>
    </section>
  )
}
