import { useState, type ReactNode } from 'react'
import { Check, ChevronDown } from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { cn } from '#nebula/lib/utils'
import { menuItemVariants } from './floating-variants'

export interface ContextSelectOption<T extends string> {
  value: T
  label: string
  icon?: ReactNode
}

export function ContextSelect<T extends string>({
  value, options, onChange, ariaLabel, contentWidth = 'w-44', side = 'top', appearance = 'field',
}: {
  value: T
  options: Array<ContextSelectOption<T>>
  onChange: (value: T) => void
  ariaLabel: string
  contentWidth?: string
  side?: 'top' | 'bottom' | 'left' | 'right'
  appearance?: 'field' | 'row'
}) {
  const [open, setOpen] = useState(false)
  const selected = options.find(option => option.value === value) ?? options[0]

  return <Popover open={open} onOpenChange={setOpen}>
    <PopoverTrigger asChild>
      <button type="button" aria-label={ariaLabel} aria-haspopup="listbox" aria-expanded={open} className={cn('flex h-[var(--control-height-field)] w-full items-center justify-between gap-2 rounded-[var(--radius-control)] bg-[var(--color-surface-field)] px-3 text-[12px] text-[var(--color-text-secondary)] outline-none transition-colors duration-[var(--motion-duration-fast)] hover:bg-[var(--color-surface-field-focus)] hover:text-[var(--color-text-primary)] focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1', appearance === 'field' ? 'ui-border-control' : 'sm:w-52')}>
        <span className="flex min-w-0 items-center gap-2">
          {selected.icon && <span aria-hidden="true" className="shrink-0 text-[var(--color-text-muted)]">{selected.icon}</span>}
          <span className="truncate">{selected.label}</span>
        </span>
        <ChevronDown size={13} className={cn('text-[var(--color-text-disabled)] transition-transform duration-[var(--motion-duration-fast)]', open && 'rotate-180')} />
      </button>
    </PopoverTrigger>
    <PopoverContent side={side} align="end" className={cn(contentWidth, 'p-1')}>
      <div role="listbox" aria-label={ariaLabel}>
        {options.map(option => <button key={option.value} type="button" role="option" aria-selected={option.value === value} onClick={() => { onChange(option.value); setOpen(false) }} className={cn(menuItemVariants({ selected: option.value === value }), 'justify-between')}>
          <span className="flex min-w-0 items-center gap-2">
            {option.icon && <span aria-hidden="true" className="shrink-0 text-[var(--color-text-muted)]">{option.icon}</span>}
            <span className="truncate">{option.label}</span>
          </span>
          <Check size={13} className={cn('text-[var(--color-text-primary)]', option.value === value ? 'opacity-100' : 'opacity-0')} />
        </button>)}
      </div>
    </PopoverContent>
  </Popover>
}
