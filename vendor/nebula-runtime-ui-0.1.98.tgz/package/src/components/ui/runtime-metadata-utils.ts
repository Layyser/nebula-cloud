import type { ModelInfo } from '#nebula/lib/api'

export function shortModelName(model: string): string {
  if (!model) return 'Default model'
  const slash = model.lastIndexOf('/')
  return slash >= 0 ? model.slice(slash + 1) : model
}

export function effortLabel(effort: string): string {
  if (!effort) return 'Default'
  return effort === 'xhigh' ? 'XHigh' : effort[0].toUpperCase() + effort.slice(1)
}

export function modelForSlug(models: ModelInfo[], slug: string): ModelInfo | undefined {
  return models.find(model => model.slug === slug)
}
