import { Shield, ShieldAlert, ShieldCheck } from 'lucide-react'
import { ModelCompanyIcon, ModelSourceIcon } from './model-icon'
import { cn } from '#nebula/lib/utils'
import type { SecurityMode } from '#nebula/lib/api'
import { effortLabel, shortModelName } from './runtime-metadata-utils'

export function ModelIdentity({
  model,
  provider,
  effort,
  className,
}: {
  model: string
  provider?: string
  effort?: string
  className?: string
}) {
  return (
    <span className={cn('inline-flex min-w-0 items-center gap-1.5', className)}>
      <ModelCompanyIcon model={model} provider={provider} />
      <span className="min-w-0 truncate">{shortModelName(model)}</span>
      {effort && (
        <>
          <span className="shrink-0 text-[var(--color-text-faint)]">·</span>
          <span className="shrink-0">{effortLabel(effort)}</span>
        </>
      )}
    </span>
  )
}

export function ModelOption({ active, model, provider, title, onClick }: {
  active: boolean
  model: string
  provider?: string
  title: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors duration-100',
        active ? 'bg-white/[0.08]' : 'hover:bg-white/[0.05]',
      )}
    >
      <ModelCompanyIcon model={model} provider={provider} />
      <span className={cn('min-w-0 truncate text-[12px] font-medium', active ? 'text-white/90' : 'text-white/65')}>
        {title}
      </span>
      <span className="ml-auto flex shrink-0 items-center gap-1.5">
        <ModelSourceIcon model={model} provider={provider} />
      </span>
    </button>
  )
}

export function SecurityModeIcon({ mode, size = 15, className }: {
  mode: SecurityMode
  size?: number
  className?: string
}) {
  if (mode === 'sandbox') {
    return <ShieldCheck size={size} className={cn('shrink-0 text-[var(--color-status-success)]', className)} />
  }
  if (mode === 'full') {
    return <ShieldAlert size={size} className={cn('shrink-0 text-amber-400/75', className)} />
  }
  return <Shield size={size} className={cn('shrink-0 text-white/40', className)} />
}
