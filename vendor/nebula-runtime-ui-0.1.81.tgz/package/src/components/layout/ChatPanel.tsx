import { useEffect, useId, useRef, useState, type ReactNode } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '#nebula/components/ui/tooltip'
import { MessageList } from '#nebula/components/chat/MessageList'
import { ChatInput } from '#nebula/components/chat/ChatInput'
import { type ChatMessage, type PendingInput } from '#nebula/hooks/useChat'
import { fetchSystemPrompt, type AgentInfo, type ModelInfo, type ReasoningEffort, type ReasoningEffortChoice, type SecurityMode, type SessionInfo, type SystemPromptPayload } from '#nebula/lib/api'
import { ShieldAlert, Check, ChevronDown, X, ShieldCheck } from 'lucide-react'
import { cn } from '#nebula/lib/utils'

interface Props {
  chatName: string | null
  messages: ChatMessage[]
  loading: boolean
  streaming: boolean
  pendingInput: PendingInput | null
  session: SessionInfo | null
  agents: AgentInfo[]
  pendingAgent: string | null
  onSend: (text: string, files?: File[]) => void | Promise<void>
  onAbort: () => void
  onRespond: (choice: number, always?: boolean) => void
  onSwitchAgent: (name: string | null) => void
  lockedAgent?: string
  securityMode?: SecurityMode
  onSwitchSecurityMode?: (mode: SecurityMode) => void
  cwd?: string
  workspaceRoot?: string
  onSwitchCwd?: (path: string) => Promise<void>
  reasoningEffort?: ReasoningEffort
  reasoningEffortOverride?: ReasoningEffort | null
  inheritedReasoningEffort?: ReasoningEffort
  onSwitchReasoningEffort?: (effort: ReasoningEffortChoice) => void
  models?: ModelInfo[]
  model?: string
  modelOverride?: string | null
  inheritedModel?: string
  onSwitchModel?: (model: string | 'default') => void
  compactEmpty?: boolean
  inputPlaceholder?: string
  initialEntrance?: boolean
  onEntranceComplete?: () => void
}

export function ChatPanel({ chatName, messages, loading, streaming, pendingInput, session, agents, pendingAgent, onSend, onAbort, onRespond, onSwitchAgent, lockedAgent, securityMode = 'default', onSwitchSecurityMode, cwd = '.', workspaceRoot, onSwitchCwd, reasoningEffort = 'medium', reasoningEffortOverride = null, inheritedReasoningEffort = 'medium', onSwitchReasoningEffort, models = [], model = '', modelOverride = null, inheritedModel = '', onSwitchModel, compactEmpty = false, inputPlaceholder, initialEntrance = false, onEntranceComplete }: Props) {
  // Switching to New Session clears useChat state in an effect. Mask the old
  // chat synchronously so it cannot flash inside the empty-session layout.
  const visibleMessages = chatName ? messages : []
  const visibleLoading = Boolean(chatName) && loading
  const visibleStreaming = Boolean(chatName) && streaming
  const visiblePendingInput = chatName ? pendingInput : null
  const isEmpty = visibleMessages.length === 0 && !visibleLoading
  const showEmptyState = isEmpty && !compactEmpty
  const reduceMotion = useReducedMotion()
  const [systemOpen, setSystemOpen] = useState(false)
  const [systemPayload, setSystemPayload] = useState<SystemPromptPayload | null>(null)
  const [systemError, setSystemError] = useState('')
  const [systemLoading, setSystemLoading] = useState(false)
  const composerRef = useRef<HTMLDivElement>(null)
  const [composerHeight, setComposerHeight] = useState(0)

  useEffect(() => {
    const composer = composerRef.current
    if (!composer || typeof ResizeObserver === 'undefined') return

    const measure = () => {
      const nextHeight = Math.ceil(composer.getBoundingClientRect().height)
      setComposerHeight(currentHeight => currentHeight === nextHeight ? currentHeight : nextHeight)
    }
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(composer)
    return () => observer.disconnect()
  }, [])

  const handleSystemOpenChange = async (open: boolean) => {
    setSystemOpen(open)
    if (!open || !chatName || systemPayload?.chat === chatName) return
    setSystemLoading(true)
    setSystemError('')
    try {
      setSystemPayload(await fetchSystemPrompt(chatName))
    } catch (error) {
      setSystemError(error instanceof Error ? error.message : String(error))
    } finally {
      setSystemLoading(false)
    }
  }

  const overlapComposer = !showEmptyState && !compactEmpty

  return (
    <div className={cn(
      'relative z-10 flex h-full min-w-0 flex-1 flex-col overflow-hidden transition-colors duration-500',
      chatName ? 'bg-[var(--color-surface-page)]' : 'bg-transparent',
      compactEmpty && 'pointer-events-none',
    )}>

      {chatName && !compactEmpty && (
        <div className="absolute right-4 top-3 z-40">
          <Popover
            open={systemOpen}
            onOpenChange={open => { void handleSystemOpenChange(open) }}
          >
            <TooltipProvider delayDuration={300}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      aria-label="Show system prompt and tool definitions"
                      className={cn(
                        'flex h-7 items-center gap-1.5 rounded-lg px-2.5 text-[12px] font-medium leading-none',
                        'bg-[var(--color-surface-sidebar)] text-[var(--color-text-muted)] transition-colors duration-[var(--motion-duration-deliberate)]',
                        'hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)]',
                        'focus:outline-none focus-visible:ring-1 focus-visible:ring-[var(--focus-ring-color)]',
                        systemOpen && 'bg-[var(--color-surface-hover)] text-[var(--color-text-primary)]',
                      )}
                    >
                      <span>System</span>
                      <ChevronDown
                        aria-hidden="true"
                        className={cn(
                          'size-3.5 transition-transform duration-[var(--motion-duration-deliberate)]',
                          systemOpen && 'rotate-180',
                        )}
                      />
                    </button>
                  </PopoverTrigger>
                </TooltipTrigger>
                <TooltipContent side="bottom" align="end">
                  Show the exact system prompt and tool definitions
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <PopoverContent
              side="bottom"
              align="end"
              sideOffset={6}
              className="w-[min(var(--content-width-system),calc(100vw-2rem))] max-h-[min(70vh,40rem)] overflow-hidden bg-[var(--color-surface-sidebar)] p-0"
            >
              <div className="max-h-[min(70vh,40rem)] space-y-3 overflow-y-auto p-3">
                {systemLoading && (
                  <div className="space-y-2 py-1" role="status" aria-label="Loading system prompt">
                    <div className="h-3 w-20 animate-pulse rounded bg-white/[0.08]" />
                    <div className="h-20 animate-pulse rounded-lg bg-[var(--color-surface-recessed)]" />
                  </div>
                )}
                {systemError && <div className="px-1 py-2 text-xs text-[var(--color-status-danger)]">{systemError}</div>}
                {!systemLoading && systemPayload?.chat === chatName && (
                  <>
                    <section>
                      <div className="px-0.5 text-[10px] font-medium uppercase tracking-[0.12em] text-[var(--color-text-faint)]">
                        Prompt
                      </div>
                      <pre className="mt-1.5 whitespace-pre-wrap break-words px-0.5 font-mono text-[11px] leading-5 text-[var(--color-text-muted)]">
                        {systemPayload.system_prompt}
                      </pre>
                    </section>
                    <section>
                      <div className="px-0.5 text-[10px] font-medium uppercase tracking-[0.12em] text-[var(--color-text-faint)]">
                        Tools
                      </div>
                      <pre className="mt-1.5 whitespace-pre-wrap break-all px-0.5 font-mono text-[11px] leading-5 text-[var(--color-text-muted)]">
                        {JSON.stringify(systemPayload.tools, null, 2)}
                      </pre>
                    </section>
                  </>
                )}
              </div>
            </PopoverContent>
          </Popover>
        </div>
      )}

      {/* ── Full-screen gradient — only in empty state ── */}
      {/* ── Messages region — grows to flex-1 when messages arrive, 0 when empty ──
              The scroll track extends behind the composer to the panel edge, while
              equivalent content padding keeps the final message above the input.  */}
      <div
        className="relative min-h-0 overflow-hidden"
        style={{
          flexGrow: showEmptyState ? 0 : 1,
          flexShrink: 1,
          marginBottom: overlapComposer ? -composerHeight : 0,
        }}
      >
        <div
          className="absolute inset-0"
          style={{
            opacity: showEmptyState ? 0 : 1,
            pointerEvents: showEmptyState || compactEmpty ? 'none' : 'auto',
            transition: 'opacity 0.4s ease',
          }}
        >
          <div data-scroll-viewport className="h-full overflow-y-auto [scrollbar-gutter:stable]">
            <div
              className="relative min-h-full"
              style={{ paddingBottom: overlapComposer ? composerHeight : 0 }}
            >
              {visibleLoading && (
                <div className="pointer-events-none absolute inset-x-0 top-0 z-0">
                  <ChatHistorySkeleton reduceMotion={Boolean(reduceMotion)} />
                </div>
              )}
              {!visibleLoading && (
                <div className="relative z-10">
                  <MessageList messages={visibleMessages} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── Top spacer — pushes input+heading toward centre when empty ── */}
      <div
        style={{
          flexGrow: showEmptyState ? 1 : 0,
          flexShrink: 0,
        }}
      />

      {overlapComposer && (
        <div
          aria-hidden="true"
          className="chat-bottom-fade pointer-events-none absolute inset-x-0 bottom-0 z-10 h-36"
        />
      )}

      {/* ── Heading + input group ── */}
      <div
        ref={composerRef}
        className="relative z-20 flex-shrink-0"
        style={{
          top: showEmptyState ? 'clamp(31px, 3.7vw, 37px)' : 0,
        }}
      >
        {visiblePendingInput && (
          <div className="px-4 pb-2 pointer-events-auto">
            <div className="mx-auto max-w-[var(--content-width-reading)]">
              {visiblePendingInput.options.length === 2
                ? <ConfirmBanner pending={visiblePendingInput} onRespond={onRespond} />
                : <OptionPicker  pending={visiblePendingInput} onRespond={onRespond} />
              }
            </div>
          </div>
        )}

        <motion.div
          layoutId="workspace-chat-input"
          className="relative z-10"
          initial={reduceMotion || !initialEntrance ? false : { opacity: 0, y: 18, scale: 0.99 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          onAnimationComplete={() => {
            if (initialEntrance) onEntranceComplete?.()
          }}
          transition={{
            opacity: reduceMotion ? { duration: 0 } : { duration: 0.38, delay: initialEntrance ? 0.2 : 0 },
            y: reduceMotion ? { duration: 0 } : { duration: 0.38, delay: initialEntrance ? 0.2 : 0, ease: [0.22, 1, 0.36, 1] },
            scale: reduceMotion ? { duration: 0 } : { duration: 0.38, delay: initialEntrance ? 0.2 : 0, ease: [0.22, 1, 0.36, 1] },
            layout: {
              type: 'tween',
              duration: 0.48,
              ease: [0.22, 1, 0.36, 1],
            },
          }}
        >
          <AnimatePresence>
            {showEmptyState && (
              <motion.div
                className="absolute inset-x-0 bottom-full z-0 flex justify-center px-6 pb-6"
                initial={reduceMotion
                  ? false
                  : initialEntrance
                    ? { opacity: 0, y: 20 }
                    : { opacity: 0 }}
                animate={initialEntrance ? { opacity: 1, y: 0 } : { opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={reduceMotion
                  ? { duration: 0 }
                  : {
                      duration: initialEntrance ? 0.42 : 0.48,
                      delay: initialEntrance ? 0.12 : 0,
                      ease: [0.22, 1, 0.36, 1],
                    }}
              >
                <EmptyState />
              </motion.div>
            )}
          </AnimatePresence>

          <ChatInput
            onSend={onSend}
            onAbort={onAbort}
            streaming={visibleStreaming}
            placeholder={inputPlaceholder ?? (showEmptyState ? 'Start a new session...' : 'Send a message…')}
            session={session}
            agents={agents}
            pendingAgent={pendingAgent}
            onSwitchAgent={onSwitchAgent}
            lockedAgent={lockedAgent}
            securityMode={securityMode}
            onSwitchSecurityMode={onSwitchSecurityMode
              ? mode => {
                  setSystemPayload(null)
                  onSwitchSecurityMode(mode)
                }
              : undefined}
            cwd={cwd}
            workspaceRoot={workspaceRoot}
            onSwitchCwd={onSwitchCwd}
            reasoningEffort={reasoningEffort}
            reasoningEffortOverride={reasoningEffortOverride}
            inheritedReasoningEffort={inheritedReasoningEffort}
            onSwitchReasoningEffort={onSwitchReasoningEffort}
            models={models}
            model={model}
            modelOverride={modelOverride}
            inheritedModel={inheritedModel}
            onSwitchModel={onSwitchModel}
          />
        </motion.div>
      </div>

      {/* ── Bottom spacer — mirrors top spacer for perfect centering when empty ── */}
      <div
        style={{
          flexGrow: showEmptyState ? 1 : 0,
          flexShrink: 0,
        }}
      />
    </div>
  )
}

function ChatHistorySkeleton({ reduceMotion }: { reduceMotion: boolean }) {
  return (
    <div
      role="status"
      aria-label="Loading conversation"
      className="mx-auto flex w-full max-w-[var(--content-width-reading)] flex-col gap-9 px-6 py-8"
    >
      <span className="sr-only">Loading conversation</span>

      <SkeletonMessage side="right" delay={0} reduceMotion={reduceMotion}>
        <SkeletonBar width="w-52" />
        <SkeletonBar width="w-32" subtle />
      </SkeletonMessage>

      <SkeletonMessage side="left" delay={0.08} reduceMotion={reduceMotion}>
        <SkeletonBar width="w-[72%]" />
        <SkeletonBar width="w-[88%]" />
        <SkeletonBar width="w-[58%]" subtle />
      </SkeletonMessage>

      <SkeletonMessage side="right" delay={0.16} reduceMotion={reduceMotion}>
        <SkeletonBar width="w-40" />
      </SkeletonMessage>

      <SkeletonMessage side="left" delay={0.24} reduceMotion={reduceMotion}>
        <SkeletonBar width="w-[84%]" />
        <SkeletonBar width="w-[67%]" />
        <div className="mt-2 h-16 w-[78%] rounded-xl bg-white/[0.018]" />
      </SkeletonMessage>
    </div>
  )
}

function SkeletonMessage({ side, delay, reduceMotion, children }: {
  side: 'left' | 'right'
  delay: number
  reduceMotion: boolean
  children: ReactNode
}) {
  const isUser = side === 'right'
  return (
    <motion.div
      initial={reduceMotion ? false : { opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={reduceMotion ? { duration: 0 } : { duration: 0.4, delay, ease: 'easeOut' }}
      className={cn(
        'chat-skeleton-sheen relative overflow-hidden',
        isUser
          ? 'ml-auto flex w-fit min-w-48 max-w-[68%] flex-col gap-2 rounded-xl bg-white/[0.055] px-4 py-3'
          : 'flex w-full max-w-[92%] flex-col gap-2.5 py-1',
      )}
    >
      {children}
    </motion.div>
  )
}

function SkeletonBar({ width, subtle = false }: { width: string; subtle?: boolean }) {
  return (
    <span className={cn(
      'block h-2 rounded-full',
      width,
      subtle ? 'bg-white/[0.045]' : 'bg-white/[0.075]',
    )} />
  )
}

// ── Shared countdown hook ─────────────────────────────────────────────────────

function splitPrompt(prompt: string): { heading: string | null; body: string } {
  const match = prompt.match(/^(Allow tool:[^\r\n]*)\r?\n\r?\n([\s\S]*)$/)
  return match
    ? { heading: match[1], body: match[2] }
    : { heading: null, body: prompt }
}

function PromptText({ prompt }: { prompt: string }) {
  const { heading, body } = splitPrompt(prompt)
  if (!heading) return <>{body}</>

  return (
    <>
      <span className="font-semibold text-white/90">{heading}</span>
      <br />
      <span>{body}</span>
    </>
  )
}

// ── 2-option confirmation banner (Allow / Always / Deny) ──────────────────────

function ConfirmBanner({
  pending,
  onRespond,
}: {
  pending: PendingInput
  onRespond: (choice: number, always?: boolean) => void
}) {
  const { prompt } = pending
  const { heading, body } = splitPrompt(prompt)

  return (
    <div className="overflow-hidden rounded-xl bg-[var(--color-surface-panel)]">
      <div className="px-3.5 py-2.5">
        <div className="flex items-start gap-2.5">
          <ShieldAlert size={14} className="mt-0.5 text-white/40 flex-shrink-0" />
          <div className="min-w-0 flex-1">
            {heading && (
              <p className="text-[12px] leading-relaxed font-semibold text-white/90">
                {heading}
              </p>
            )}
            <div className={cn('flex items-end gap-3', heading && 'mt-0.5')}>
              <p className="min-w-0 flex-1 text-[12px] leading-relaxed text-white/70 whitespace-pre-wrap break-words">
                {body}
              </p>
              <div className="flex items-center gap-1 flex-shrink-0 self-end">
          <button
            onClick={() => onRespond(0)}
            className="flex h-7 items-center gap-1 rounded-lg bg-[var(--color-status-success-surface-emphasis)] px-2.5 text-[12px] text-[var(--color-status-success-strong)] whitespace-nowrap transition-colors hover:bg-[var(--color-status-success-surface-strong)]"
          >
            <Check size={11} /> Allow
          </button>
          <button
            onClick={() => onRespond(0, true)}
            className="flex h-7 items-center gap-1 rounded-lg bg-[var(--color-status-info-surface)] px-2.5 text-[12px] text-[var(--color-status-info)] whitespace-nowrap transition-colors hover:bg-[var(--color-status-info-surface-strong)] hover:text-[var(--color-status-info-strong)]"
          >
            <ShieldCheck size={11} /> Always
          </button>
          <button
            onClick={() => onRespond(1)}
            className="flex h-7 items-center gap-1 rounded-lg bg-[var(--color-status-danger-surface)] px-2.5 text-[12px] text-[var(--color-status-danger)] whitespace-nowrap transition-colors hover:bg-[var(--color-status-danger-surface-strong)] hover:text-[var(--color-status-danger-strong)]"
          >
            <X size={11} /> Deny
          </button>
              </div>
            </div>
        </div>
        </div>
      </div>
    </div>
  )
}

// ── N-option picker (3+ options) ──────────────────────────────────────────────

function OptionPicker({
  pending,
  onRespond,
}: {
  pending: PendingInput
  onRespond: (choice: number) => void
}) {
  const { prompt, options } = pending

  return (
    <div className="overflow-hidden rounded-xl bg-[var(--color-surface-panel)]">
      <div className="px-3.5 pt-2.5 pb-2">
        <div className="flex items-center gap-2 mb-2.5">
          <ShieldAlert size={13} className="text-white/40 flex-shrink-0" />
          <p className="min-w-0 text-[12px] leading-relaxed text-white/70 whitespace-pre-wrap break-words">
            <PromptText prompt={prompt} />
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {options.map((label, i) => (
            <button
              key={i}
              onClick={() => onRespond(i)}
              className="rounded-lg bg-white/[0.06] px-3 py-1 text-[12px] text-white/70 transition-colors hover:bg-white/[0.12] hover:text-white/90"
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

const EMPTY_STATE_PROMPTS = [
  'What can I help with?',
  'What would you like to work on?',
  'What should we build?',
  'What can I take care of?',
  'Where should we begin?',
]

function EmptyState() {
  const promptId = useId()
  const promptIndex = [...promptId].reduce(
    (hash, character) => ((hash * 31) + character.charCodeAt(0)) >>> 0,
    0,
  ) % EMPTY_STATE_PROMPTS.length

  return (
    <div className="text-center">
      <div className="app-heading-blob empty-state-heading-blob">
        <h1 className="max-w-xl text-[clamp(1.875rem,4vw,2.5rem)] font-medium leading-tight tracking-[-0.035em] text-white/95">
          {EMPTY_STATE_PROMPTS[promptIndex]}
        </h1>
      </div>
    </div>
  )
}
