import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react'
import { NebulaBackground } from '#nebula/components/shader/NebulaBackground'
import { RuntimeUnavailable } from '#nebula/components/workspace/RuntimeUnavailable'
import { createLocalRuntimeTransport, type RuntimeTransport } from '#nebula/runtime/transport'
import type { RuntimeWorkspaceProps } from '#nebula/components/workspace/WorkspaceApp'

const WorkspaceApp = lazy(() => import('#nebula/components/workspace/WorkspaceApp'))
const runtimeBaseUrl = import.meta.env.VITE_NEBULA_API_BASE?.replace(/\/$/, '') || '/api'

interface AppProps {
  transport?: RuntimeTransport
  workspaceProps?: Pick<
    RuntimeWorkspaceProps,
    'initialView' | 'initialChat' | 'initialAgentBuilder' | 'initialDeleteChat'
  >
}

export default function App({ transport: suppliedTransport, workspaceProps }: AppProps) {
  const [runtimeState, setRuntimeState] = useState<'checking' | 'ready' | 'unavailable'>('checking')
  const [checkAttempt, setCheckAttempt] = useState(0)
  const transport = useMemo(
    () => suppliedTransport ?? createLocalRuntimeTransport({ origin: runtimeBaseUrl }),
    [suppliedTransport],
  )

  useEffect(() => {
    const controller = new AbortController()
    const timeout = window.setTimeout(() => controller.abort(), 3500)
    void transport.request('/health', { signal: controller.signal })
      .then(response => setRuntimeState(response.ok ? 'ready' : 'unavailable'))
      .catch(() => setRuntimeState('unavailable'))
      .finally(() => window.clearTimeout(timeout))
    return () => {
      controller.abort()
      window.clearTimeout(timeout)
    }
  }, [transport, checkAttempt])

  const retryRuntime = useCallback(() => {
    setRuntimeState('checking')
    setCheckAttempt(attempt => attempt + 1)
  }, [])

  return (
    <>
      <NebulaBackground fade={0} variant="classic" palette="graphite" resolutionScale={0.5} />
      <div
        aria-hidden="true"
        className="runtime-shader-vignette pointer-events-none fixed inset-0 z-[1]"
      />
      <div
        aria-hidden="true"
        className="shader-bottom-fade pointer-events-none fixed inset-x-0 bottom-0 z-[1]"
      />
      {runtimeState === 'ready' ? (
        <Suspense fallback={<div className="relative z-[2] h-screen w-screen bg-transparent" />}>
          <WorkspaceApp {...workspaceProps} transport={transport} />
        </Suspense>
      ) : (
        <RuntimeUnavailable checking={runtimeState === 'checking'} onRetry={retryRuntime} />
      )}
    </>
  )
}
