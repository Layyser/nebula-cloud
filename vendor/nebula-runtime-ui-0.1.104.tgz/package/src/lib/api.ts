import {
  createHttpRuntimeTransport,
  type RuntimeTransport,
} from '../runtime/transport'

let transport: RuntimeTransport = createHttpRuntimeTransport(
  import.meta.env.VITE_NEBULA_API_BASE?.replace(/\/$/, '') || '/api',
)

/**
 * Selects the single runtime endpoint mounted by the current application shell.
 * Standalone Web keeps the default `/api`; Nebula Cloud supplies an
 * operator-scoped gateway URL. A browser surface mounts one active runtime at
 * a time, so container addresses and credentials never enter the UI contract.
 */
export function configureRuntimeTransport(nextTransport: RuntimeTransport): void {
  transport = nextTransport
}

/** @deprecated Pass a RuntimeTransport to RuntimeWorkspace instead. */
export function configureRuntimeApiEndpoint(baseUrl: string): void {
  configureRuntimeTransport(createHttpRuntimeTransport(baseUrl))
}

function runtimeRequest(path: string, init?: RequestInit): Promise<Response> {
  return transport.request(path, init)
}

export interface ToolDisplay {
  label: string
  primary: string
  kind: 'silent' | 'command' | 'edit' | 'list' | 'json' | string
}

export interface WorkspaceChange {
  id: string
  path: string
  absolute_path?: string
  session?: string
  run_id?: string
  tool_call_id?: string
  operation: 'create' | 'modify' | string
  status: 'applied' | 'reverted' | string
  patch?: string
  [key: string]: unknown
}

export interface SystemPromptPayload {
  chat: string
  system_prompt: string
  tools: unknown[]
}

export interface ToolCallEntry {
  id?: string
  item_id?: string
  name: string
  args: Record<string, unknown>
  result?: Record<string, unknown>
  display?: ToolDisplay
  created_at_ms?: number
  completed_at_ms?: number
}

export interface Message {
  role: 'user' | 'assistant' | 'event' | 'thinking'
  content: string
  thinking?: string
  hook?: string
  source?: string
  tool_calls?: ToolCallEntry[]
  stopped?: boolean
  created_at_ms?: number
  completed_at_ms?: number
}

export type SSEEvent =
  | { type: 'text';        content: string }
  | { type: 'thinking';    content: string }
  | { type: 'tool_call';   id?: string; item_id?: string; name: string; args: Record<string, unknown>; display?: ToolDisplay }
  | { type: 'tool_result'; id?: string; item_id?: string; name: string; result: Record<string, unknown>; display?: ToolDisplay }
  | { type: 'user_input';  id: string; prompt: string; options: string[] }
  | { type: 'status';       status: 'stopped' }

export type HookSSEEvent =
  | SSEEvent
  | { type: 'hook_start'; hook: string; trigger: string }
  | { type: 'hook_end';   hook: string }
  | { type: 'background_start'; source: 'subagent'; label?: string }
  | { type: 'background_end'; source: 'subagent' }

export interface AgentInfo {
  name: string
  prompt?: string
  description?: string
  model?: string
  temperature?: number
  max_tokens?: number
  reasoning_effort?: ReasoningEffort
  thinking?: boolean
  tools?: Record<string, string>
  mcp?: string[]
  skills?: string[]
  hooks?: string[]
  instructions?: string[]
  commands?: string[]
  context_limit?: number
  auto_summarize?: boolean
  security_mode?: SecurityMode
  is_default?: boolean
  profile?: Partial<AgentInfo>
}

export interface CapabilityFileInfo {
  name: string
  description?: string
  content: string
  scope: 'workspace' | 'inherited' | 'available' | string
  source?: string
}

export interface HookInfo {
  name: string
  event: 'webhook' | 'telegram' | 'cron' | 'file'
  default?: boolean
  prompt?: string
  path?: string
  every?: string
  at?: string
  filter?: Record<string, unknown>
  secret?: string
  telegram_token?: string
}

export interface ToolInfo {
  name: string
  description?: string
}

export interface CapabilityCatalog {
  mcps: McpInfo[]
  skills: CapabilityFileInfo[]
  commands: CapabilityFileInfo[]
  hooks: HookInfo[]
  rules: CapabilityFileInfo[]
  tools: ToolInfo[]
}

export interface ModelInfo {
  slug: string
  display_name?: string
  description?: string
  provider?: string
  reasoning_efforts?: string[]
}

export interface ModelCatalog {
  models: ModelInfo[]
  default_model: string
  warning?: string | null
}

export interface McpInfo {
  name: string
  description?: string
  transport: 'http' | 'stdio'
  url?: string
  command?: string[]
  excluded_by_default: boolean
  loaded: boolean
  tools?: number
  env?: Record<string, string>
  headers?: Record<string, string>
  include?: string[]
  exclude?: string[]
  state?: string
  error?: string
  generation?: number
}

export interface RunInfo {
  id: string
  chat: string
  parent: string | null
  source: string
  label: string
  status: string
  input_prompt: string
  input_options: string[]
  started_at_ms: number
  updated_at_ms: number
  cancellable: boolean
}

export type RunStatusEvent =
  | { type: 'run_snapshot'; runs: RunInfo[] }
  | { type: 'run_status'; action: 'started' | 'updated' | 'finished'; run: RunInfo }
  | { type: 'chat_title'; chat: string; display_name: string }

export interface ChatSession {
  name: string
  display_name?: string
  agent?: string
  description?: string
  has_hooks?: boolean
  hooks_paused?: boolean
  kind?: string
  parent_chat?: string | null
  purpose?: string
  status?: string
  terminal?: boolean
  depth?: number
  last_child?: boolean
  has_next_sibling?: boolean
  run?: RunInfo | null
  cwd?: string
  cwd_updated_at_ms?: number
  workspace_root?: string
}

export interface SessionInfo {
  chat: string
  agent?: string | null
  description?: string
  model: string
  model_source?: 'session' | 'agent' | 'config' | string
  model_override?: string | null
  temperature?: number
  max_tokens?: number
  thinking?: boolean
  reasoning_effort: ReasoningEffort
  reasoning_effort_source?: 'session' | 'agent' | 'config' | string
  reasoning_effort_override?: ReasoningEffort | null
  tools?: Record<string, string>
  mcp?: string[]
  skills?: string[]
  security_mode: SecurityMode
  security_mode_override?: Exclude<SecurityMode, 'default'> | null
  workspace_root?: string
  cwd?: string
  cwd_updated_at_ms?: number
}

export type SecurityMode = 'default' | 'sandbox' | 'full'
export type ReasoningEffort = 'none' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max'
export type ReasoningEffortChoice = ReasoningEffort | 'default'

export async function fetchAgents(): Promise<AgentInfo[]> {
  const res = await runtimeRequest('/agents')
  const data = await res.json()
  const agents = data.agents as AgentInfo[]
  const defaultAgent = data.default as AgentInfo | undefined
  return defaultAgent ? [{ ...defaultAgent, name: 'Default' }, ...agents] : agents
}

export async function saveAgent(name: string, agentMd: string): Promise<void> {
  const res = await runtimeRequest(`/agents/${encodeURIComponent(name)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ agent_md: agentMd }),
  })
  if (!res.ok) throw new Error(`Failed to save agent (${res.status})`)
}

export async function fetchMcps(): Promise<McpInfo[]> {
  const res = await runtimeRequest('/mcps')
  if (!res.ok) throw new Error(`Failed to load connections (${res.status})`)
  const data = await res.json() as { mcps: McpInfo[] }
  return data.mcps
}

export async function fetchCapabilities(): Promise<CapabilityCatalog> {
  const res = await runtimeRequest('/capabilities')
  if (!res.ok) throw new Error(`Failed to load capabilities (${res.status})`)
  return res.json() as Promise<CapabilityCatalog>
}

export async function saveFileCapability(
  kind: 'skills' | 'rules' | 'commands', name: string, content: string,
): Promise<void> {
  const res = await runtimeRequest(`/capabilities/${kind}/${encodeURIComponent(name)}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content }),
  })
  if (!res.ok) throw new Error(`Failed to save ${kind.slice(0, -1)} (${res.status})`)
}

export async function saveHook(name: string, hook: Omit<HookInfo, 'name'>): Promise<void> {
  const res = await runtimeRequest(`/capabilities/hooks/${encodeURIComponent(name)}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(hook),
  })
  if (!res.ok) throw new Error(`Failed to save hook (${res.status})`)
}

export async function deleteCapability(kind: 'mcps' | 'skills' | 'rules' | 'commands' | 'hooks', name: string): Promise<void> {
  const res = await runtimeRequest(`/capabilities/${kind}/${encodeURIComponent(name)}`, { method: 'DELETE' })
  if (!res.ok) throw new Error(`Failed to delete capability (${res.status})`)
}

export interface NewMcpInput {
  name: string
  description: string
  transport: 'http' | 'stdio'
  url?: string
  command?: string[]
  headers?: Record<string, string>
  env?: Record<string, string>
  include?: string[]
  exclude?: string[]
  excluded_by_default?: boolean
}

export async function saveMcp(input: NewMcpInput): Promise<void> {
  const res = await runtimeRequest('/mcps', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  })
  if (!res.ok) throw new Error(`Failed to save connection (${res.status})`)
}

export async function fetchSession(chatName: string): Promise<SessionInfo> {
  const res = await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/session`)
  return res.json()
}

export async function setSessionSecurityMode(chatName: string, mode: SecurityMode): Promise<SessionInfo> {
  const res = await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/security-mode`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mode }),
  })
  if (!res.ok) throw new Error(`Failed to set security mode (${res.status})`)
  return res.json() as Promise<SessionInfo>
}

export async function setSessionCwd(chatName: string, path: string): Promise<SessionInfo> {
  console.debug('[nebula] setting session workspace', { chatName, path })
  const res = await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/cwd`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path }),
  })
  if (!res.ok) {
    const data = await res.json().catch(() => null) as { error?: string } | null
    const error = new Error(data?.error ?? `Failed to set project directory (${res.status})`)
    console.error('[nebula] session workspace rejected', { chatName, path, status: res.status, error: error.message })
    throw error
  }
  const session = await res.json() as SessionInfo
  console.debug('[nebula] session workspace updated', { chatName, cwd: session.cwd })
  return session
}

export async function setSessionReasoningEffort(
  chatName: string,
  effort: ReasoningEffortChoice,
): Promise<SessionInfo> {
  const res = await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/effort`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ effort }),
  })
  if (!res.ok) throw new Error(`Failed to set reasoning effort (${res.status})`)
  return res.json() as Promise<SessionInfo>
}

export async function fetchModels(): Promise<ModelCatalog> {
  const res = await runtimeRequest('/models')
  if (!res.ok) throw new Error(`Failed to fetch models (${res.status})`)
  return res.json() as Promise<ModelCatalog>
}

export async function setSessionModel(
  chatName: string,
  model: string | 'default',
): Promise<SessionInfo> {
  const res = await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/model`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model }),
  })
  if (!res.ok) throw new Error(`Failed to set model (${res.status})`)
  return res.json() as Promise<SessionInfo>
}

export async function fetchChats(): Promise<ChatSession[]> {
  const res = await runtimeRequest('/chats')
  if (!res.ok) throw new Error(`Failed to fetch chats (${res.status})`)
  const data = await res.json()
  if (!Array.isArray(data.chats)) throw new Error('Invalid chats response')
  return data.chats as ChatSession[]
}

export interface ChatSearchResult extends ChatSession {
  project: string
  snippet: string
  updated_at_ms: number
}

export interface ChatSearchPage {
  chats: ChatSearchResult[]
  total: number
  total_chats: number
  limit: number
  offset: number
}

export async function searchChats(query: string, limit = 20, offset = 0, signal?: AbortSignal): Promise<ChatSearchPage> {
  const params = new URLSearchParams({ q: query, limit: String(limit), offset: String(offset) })
  const res = await runtimeRequest(`/chats/search?${params}`, { signal })
  if (!res.ok) throw new Error(`Failed to search chats (${res.status})`)
  const data = await res.json()
  if (!Array.isArray(data.chats) || !Number.isInteger(data.total) || data.total < 0
    || !Number.isInteger(data.total_chats) || data.total_chats < 0
    || data.chats.some((chat: ChatSearchResult) => typeof chat.name !== 'string'
      || typeof chat.project !== 'string' || typeof chat.snippet !== 'string'
      || !Number.isFinite(chat.updated_at_ms) || Math.abs(chat.updated_at_ms) > 8640000000000000)) throw new Error('Invalid search response')
  return data as ChatSearchPage
}

export async function setSessionAgent(chatName: string, agentName: string | null): Promise<void> {
  if (agentName === null) {
    await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/agent`, { method: 'DELETE' })
  } else {
    await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/agent`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent: agentName }),
    })
  }
}

export async function fetchChat(name: string): Promise<Message[]> {
  const res = await runtimeRequest(`/chat/${encodeURIComponent(name)}`)
  const data = await res.json()
  return data.messages as Message[]
}

export async function deleteChat(name: string): Promise<void> {
  const url = `/chat/${encodeURIComponent(name)}`
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await runtimeRequest(url, { method: 'DELETE' })
      if (res.ok || res.status === 404) return
      throw new Error(`Failed to delete chat (${res.status})`)
    } catch (error) {
      if (attempt === 1 || !(error instanceof TypeError))
        throw error
      await new Promise(resolve => setTimeout(resolve, 250))
    }
  }
}

export async function respondInput(chatName: string, id: string, choice: number): Promise<void> {
  await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/input`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id, choice }),
  })
}

export async function cancelChat(chatName: string): Promise<void> {
  await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/cancel`, {
    method: 'POST',
  })
}

export async function setChatHooksPaused(chatName: string, paused: boolean): Promise<void> {
  const res = await runtimeRequest(`/chat/${encodeURIComponent(chatName)}/hooks`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ paused }),
  })
  if (!res.ok) throw new Error(`Failed to update hooks (${res.status})`)
}

export function streamMessage(
  chatName: string,
  message: string,
  onEvent: (event: SSEEvent) => void,
  onDone: () => void,
  onError: (err: Error) => void,
  agentName?: string,
  securityMode?: SecurityMode,
  reasoningEffort?: ReasoningEffort,
  model?: string,
): () => void {
  const body: Record<string, string> = { message }
  if (agentName) body.agent = agentName
  if (securityMode && securityMode !== 'default') body.security_mode = securityMode
  if (reasoningEffort) body.reasoning_effort = reasoningEffort
  // "default" is a UI/API sentinel that clears an override; it is never a
  // provider model slug and must not leak into an inference request.
  if (model && model !== 'default') body.model = model

  const subscription = transport.stream<SSEEvent>(`/chat/${encodeURIComponent(chatName)}`, {
    init: {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    },
    onEvent,
    onDone,
    onError,
  })
  return () => subscription.cancel()
}

// Reconnect to a turn that is still streaming on the server.
// Replays every event from the beginning of that turn so the caller can
// rebuild the assistant message. Calls onNotFound if there is no active turn
// (HTTP 204/404), or if any network error occurs.
export function reconnectStream(
  chatName: string,
  onEvent: (event: SSEEvent) => void,
  onDone: () => void,
  onNotFound: () => void,
): () => void {
  const subscription = transport.stream<SSEEvent>(
    `/chat/${encodeURIComponent(chatName)}/stream`,
    {
      completeStatuses: [204, 404],
      onCompleteStatus: onNotFound,
      onEvent,
      onDone,
      onError: onNotFound,
    },
  )
  return () => subscription.cancel()
}

export function streamHookEvents(
  chatName: string,
  onEvent: (event: HookSSEEvent) => void,
  onError: (err: Error) => void,
): () => void {
  const subscription = transport.stream<HookSSEEvent>(
    `/chat/${encodeURIComponent(chatName)}/events`,
    { onEvent, onError },
  )
  return () => subscription.cancel()
}

// Streams status for every active run so activity indicators can update in
// sidebars without polling. The connection is re-established after a short
// delay if the daemon or network drops it.
export function streamRunStatus(
  onEvent: (event: RunStatusEvent) => void,
  onError: (err: Error) => void,
): () => void {
  const subscription = transport.reconnectingStream<RunStatusEvent>('/runs/events', {
    retryDelayMs: 1000,
    maxRetryDelayMs: 30000,
    retryBackoffFactor: 2,
    onEvent,
    onError,
  })
  return () => subscription.cancel()
}

export async function fetchWorkspaceChange(id: string): Promise<WorkspaceChange> {
  const response = await runtimeRequest(`/changes/${encodeURIComponent(id)}`)
  const body = await response.json()
  if (!response.ok || body.error) throw new Error(body.error ?? `HTTP ${response.status}`)
  return body.change as WorkspaceChange
}

export async function mutateWorkspaceChange(
  id: string,
  action: 'revert' | 'unrevert',
): Promise<WorkspaceChange> {
  const response = await runtimeRequest(
    `/changes/${encodeURIComponent(id)}/${action}`,
    { method: 'POST' },
  )
  const body = await response.json()
  if (!response.ok || body.error) throw new Error(body.error ?? `HTTP ${response.status}`)
  return body.change as WorkspaceChange
}

export async function fetchSystemPrompt(chat: string): Promise<SystemPromptPayload> {
  const response = await runtimeRequest(`/chat/${encodeURIComponent(chat)}/system-prompt`)
  const body = await response.json()
  if (!response.ok || body.error) throw new Error(body.error ?? `HTTP ${response.status}`)
  return body as SystemPromptPayload
}
