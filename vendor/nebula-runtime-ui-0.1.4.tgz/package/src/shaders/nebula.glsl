#version 300 es
precision highp float;

in vec3 vFragPos;
out vec4 fragColor;

uniform float time;
uniform float aspect;
uniform vec3 uColor1;
uniform vec3 uColor2;
uniform vec3 uColor3;
uniform float uSpeed;
uniform float uDensity;
uniform float uFade;

float hash(vec2 p) {
    p = fract(p * vec2(234.34, 435.345));
    p += dot(p, p + 34.23);
    return fract(p.x * p.y);
}

vec2 hash2(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1,0)), u.x),
               mix(hash(i + vec2(0,1)), hash(i + vec2(1,1)), u.x), u.y);
}

float fbm(vec2 p, int oct) {
    float v = 0.0, a = 0.5;
    mat2 rot = mat2(cos(0.5), -sin(0.5), sin(0.5), cos(0.5));
    for (int i = 0; i < 7; i++) {
        if (i >= oct) break;
        v += a * noise(p);
        p = rot * p * 2.07 + vec2(3.1, 1.7);
        a *= 0.49;
    }
    return v;
}

vec3 tonemap(vec3 x) {
    return x / (x + 0.65) * 1.65;
}

void main() {
    vec2 uv = vFragPos.xy;
    uv.x *= aspect;
    float t = time * uSpeed;

    vec2 q = vec2(fbm(uv + vec2(t * 0.14, t * 0.10), 5),
                  fbm(uv + vec2(3.3, 1.7) + vec2(t * 0.08, -t * 0.12), 5));

    vec2 r = vec2(fbm(uv + 2.0 * q + vec2(1.7, 9.2) + t * 0.06, 6),
                  fbm(uv + 2.0 * q + vec2(8.3, 2.8) - t * 0.05, 6));

    float density = fbm(uv + 2.5 * r, 7);
    float d = pow(clamp(density * uDensity, 0.0, 1.0), 1.6);

    vec3 col;
    if (d > 0.72) {
        col = mix(uColor2, uColor2 * 1.5 + uColor3 * 0.3, smoothstep(0.72, 0.92, d));
    } else if (d > 0.38) {
        col = mix(uColor3, uColor2, smoothstep(0.38, 0.72, d));
    } else {
        col = mix(uColor1 * 0.10, uColor3, smoothstep(0.0, 0.38, d));
    }

    vec2 starGrid = vFragPos.xy * vec2(aspect, 1.0) * 18.0;
    vec2 starCell = floor(starGrid);
    vec2 starFrac = fract(starGrid);
    float starVal = 0.0;
    for (int sy = -1; sy <= 1; sy++) {
        for (int sx = -1; sx <= 1; sx++) {
            vec2  nb      = vec2(float(sx), float(sy));
            vec2  randOff = hash2(starCell + nb);
            float br      = hash(starCell + nb + 0.5);
            float dist    = length(starFrac - nb - randOff);
            starVal += smoothstep(0.055, 0.0, dist) * pow(br, 7.0);
        }
    }
    col += starVal * 0.7 * (1.0 - smoothstep(0.3, 0.65, d)) * mix(vec3(1.0), uColor2, 0.25);

    float glow = 1.0 - smoothstep(0.0, 0.9, length(uv * 0.55));
    col += uColor2 * glow * 0.06;

    vec3 finalColor = tonemap(col);

    float dither = fract(sin(dot(vFragPos.xy, vec2(12.9898, 78.233))) * 43758.5453);
    finalColor += (dither - 0.5) * 0.012;

    // fade to black
    finalColor *= uFade;

    fragColor = vec4(clamp(finalColor, 0.0, 1.0), 1.0);
}
