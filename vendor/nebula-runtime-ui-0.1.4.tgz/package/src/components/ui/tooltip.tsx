import * as TooltipPrimitive from '@radix-ui/react-tooltip'
import { cn } from '#nebula/lib/utils'

export const TooltipProvider = TooltipPrimitive.Provider
export const Tooltip = TooltipPrimitive.Root
export const TooltipTrigger = TooltipPrimitive.Trigger

export function TooltipContent({
  className,
  sideOffset = 6,
  ...props
}: React.ComponentProps<typeof TooltipPrimitive.Content>) {
  return (
    <TooltipPrimitive.Portal>
      <TooltipPrimitive.Content
        sideOffset={sideOffset}
        className={cn(
          'z-50 rounded-lg border border-white/10 bg-zinc-900/95 px-2.5 py-1.5',
          'text-xs text-white/75 shadow-xl backdrop-blur-sm',
          className
        )}
        {...props}
      />
    </TooltipPrimitive.Portal>
  )
}
