import { Slot } from '@radix-ui/react-slot'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '#nebula/lib/utils'

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium transition-all duration-150 disabled:pointer-events-none disabled:opacity-40 cursor-pointer select-none',
  {
    variants: {
      variant: {
        default: 'bg-white/10 text-white/85 hover:bg-white/[0.14] border border-white/[0.08]',
        ghost:   'text-white/50 hover:text-white/80 hover:bg-white/[0.06]',
        danger:  'text-red-400/70 hover:text-red-400 hover:bg-red-400/10',
      },
      size: {
        default: 'h-9 px-3',
        sm:      'h-7 px-2.5 rounded-lg text-xs',
        icon:    'h-8 w-8 rounded-xl',
      },
    },
    defaultVariants: { variant: 'default', size: 'default' },
  }
)

interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

export function Button({ className, variant, size, asChild, ...props }: ButtonProps) {
  const Comp = asChild ? Slot : 'button'
  return <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />
}
