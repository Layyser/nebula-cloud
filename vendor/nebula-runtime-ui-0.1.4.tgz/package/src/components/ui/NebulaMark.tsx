import nebulaIcon from '#nebula/assets/nebula-icon-temp.svg'

export function NebulaMark({ size }: { size?: number }) {
  return (
    <img
      src={nebulaIcon}
      alt=""
      aria-hidden="true"
      className="h-6 w-6 shrink-0 object-contain"
      style={size ? { width: size, height: size } : undefined}
    />
  )
}
