import { useState } from 'react'
import { Check, ChevronDown } from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { cn } from '#nebula/lib/utils'

export interface ContextSelectOption<T extends string> {
  value: T
  label: string
}

export function ContextSelect<T extends string>({
  value, options, onChange, ariaLabel, contentWidth = 'w-44', side = 'top',
}: {
  value: T
  options: Array<ContextSelectOption<T>>
  onChange: (value: T) => void
  ariaLabel: string
  contentWidth?: string
  side?: 'top' | 'bottom' | 'left' | 'right'
}) {
  const [open, setOpen] = useState(false)
  const selected = options.find(option => option.value === value) ?? options[0]

  return <Popover open={open} onOpenChange={setOpen}>
    <PopoverTrigger asChild>
      <button type="button" aria-haspopup="listbox" aria-expanded={open} className="flex h-[34px] w-full items-center justify-between gap-2 rounded-lg border border-white/[0.10] bg-[#0b0b0b] px-3 text-[12px] text-white/70 transition-colors hover:bg-[#151515] hover:text-white/90">
        <span>{selected.label}</span>
        <ChevronDown size={13} className={cn('text-white/35 transition-transform', open && 'rotate-180')} />
      </button>
    </PopoverTrigger>
    <PopoverContent side={side} align="end" className={cn(contentWidth, 'p-1')}>
      <div role="listbox" aria-label={ariaLabel}>
        {options.map(option => <button key={option.value} type="button" role="option" aria-selected={option.value === value} onClick={() => { onChange(option.value); setOpen(false) }} className="flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-[12px] text-white/65 transition-colors hover:bg-white/[0.08] hover:text-white/90">
          {option.label}
          <Check size={13} className={cn('text-white/80', option.value === value ? 'opacity-100' : 'opacity-0')} />
        </button>)}
      </div>
    </PopoverContent>
  </Popover>
}
