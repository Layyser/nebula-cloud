import { Check, ChevronsUpDown } from 'lucide-react'
import { Button } from '#nebula/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { cn } from '#nebula/lib/utils'

export interface MultiSelectOption {
  value: string
  label: string
  description?: string
}

interface MultiSelectProps {
  options: MultiSelectOption[]
  value: string[]
  onChange: (value: string[]) => void
  placeholder?: string
  disabled?: boolean
}

export function MultiSelect({ options, value, onChange, placeholder = 'Select options', disabled }: MultiSelectProps) {
  const selectedLabels = options.filter(option => value.includes(option.value)).map(option => option.label)
  const label = selectedLabels.length === 0
    ? placeholder
    : selectedLabels.length <= 2
      ? selectedLabels.join(', ')
      : `${selectedLabels.slice(0, 2).join(', ')} +${selectedLabels.length - 2}`

  const toggle = (option: string) => {
    onChange(value.includes(option)
      ? value.filter(item => item !== option)
      : [...value, option])
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          disabled={disabled}
          aria-haspopup="listbox"
          className="w-full h-[34px] justify-between min-w-0 rounded-lg border border-white/[0.10] bg-[#0b0b0b] px-2.5 text-[12px] font-medium text-white/60 hover:bg-[#151515] hover:text-white/90"
        >
          <span className={cn('truncate', selectedLabels.length === 0 && 'text-zinc-600')}>{label}</span>
          <ChevronsUpDown size={13} className="shrink-0 text-white/35" />
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        className="p-1"
        style={{ width: 'var(--radix-popover-trigger-width)' }}
      >
        <div role="listbox" aria-multiselectable="true" className="max-h-52 overflow-y-auto">
          {options.length === 0 ? (
            <p className="px-2 py-2 text-[12px] text-white/35">No options available.</p>
          ) : options.map(option => {
            const selected = value.includes(option.value)
            return (
              <button
                key={option.value}
                type="button"
                role="option"
                aria-selected={selected}
                onClick={() => toggle(option.value)}
                className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-[12px] text-white/65 hover:bg-white/[0.08] hover:text-white/90 transition-colors"
              >
                <span className={cn(
                  'flex h-4 w-4 shrink-0 items-center justify-center rounded border',
                  selected ? 'border-white/40 bg-white/[0.16] text-white' : 'border-white/20 text-transparent',
                )}>
                  <Check size={11} strokeWidth={2.5} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate">{option.label}</span>
                  {option.description && <span className="block truncate text-[10px] text-white/30">{option.description}</span>}
                </span>
              </button>
            )
          })}
        </div>
      </PopoverContent>
    </Popover>
  )
}
