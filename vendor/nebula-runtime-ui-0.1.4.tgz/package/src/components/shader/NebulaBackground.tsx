import { useEffect, useRef } from 'react'
import vertexSrc from '../../shaders/vertex.glsl?raw'
import {
  getNebulaPalette,
  getNebulaVariant,
  type NebulaPaletteId,
  type NebulaVariantId,
} from '#nebula/components/shader/nebulaOptions'

interface Props {
  /** 0 = fully visible, 1 = fully faded to black */
  fade: number
  variant?: NebulaVariantId
  palette?: NebulaPaletteId
  resolutionScale?: number
}

function detectSoftwareRenderer(): boolean {
  if (typeof document === 'undefined') return false
  const probe = document.createElement('canvas')
  const gl = probe.getContext('webgl2', { failIfMajorPerformanceCaveat: true })
  if (!gl) return true
  const ext = gl.getExtension('WEBGL_debug_renderer_info')
  if (!ext) return false
  const renderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) as string
  return /swiftshader|software|llvmpipe|mesa offscreen|microsoft basic/i.test(renderer)
}

const IS_SOFTWARE = detectSoftwareRenderer()
const SHOULD_ANIMATE = typeof window !== 'undefined'
  && !IS_SOFTWARE
  && !window.matchMedia('(prefers-reduced-motion: reduce)').matches

export function NebulaBackground({ fade: _fade, variant = 'classic', palette = 'graphite', resolutionScale }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fadeRef = useRef(_fade)
  const variantConfig = getNebulaVariant(IS_SOFTWARE ? 'clean' : variant)
  const paletteConfig = getNebulaPalette(palette)

  useEffect(() => {
    fadeRef.current = _fade
  }, [_fade])

  useEffect(() => {
    if (IS_SOFTWARE) return

    const canvas = canvasRef.current!
    const gl = canvas.getContext('webgl2', { antialias: false })
    if (!gl) return

    const compile = (type: number, src: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, src)
      gl.compileShader(s)
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
        console.error('Shader:', gl.getShaderInfoLog(s))
      return s
    }

    const vertexShader = compile(gl.VERTEX_SHADER, vertexSrc)
    const fragmentShader = compile(gl.FRAGMENT_SHADER, variantConfig.fragmentSource)
    const prog = gl.createProgram()!
    gl.attachShader(prog, vertexShader)
    gl.attachShader(prog, fragmentShader)
    gl.linkProgram(prog)
    gl.useProgram(prog)

    const verts = new Float32Array([
      -1, -1, 0,  0, 0, 1,  1, 1, 1,
       1, -1, 0,  0, 0, 1,  1, 1, 1,
      -1,  1, 0,  0, 0, 1,  1, 1, 1,
      -1,  1, 0,  0, 0, 1,  1, 1, 1,
       1, -1, 0,  0, 0, 1,  1, 1, 1,
       1,  1, 0,  0, 0, 1,  1, 1, 1,
    ])
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, verts, gl.STATIC_DRAW)

    const stride = 9 * 4
    const pos = gl.getAttribLocation(prog, 'position')
    if (pos >= 0) {
      gl.enableVertexAttribArray(pos)
      gl.vertexAttribPointer(pos, 3, gl.FLOAT, false, stride, 0)
    }

    const nor = gl.getAttribLocation(prog, 'normal')
    if (nor >= 0) {
      gl.enableVertexAttribArray(nor)
      gl.vertexAttribPointer(nor, 3, gl.FLOAT, false, stride, 3 * 4)
    }

    const uTime    = gl.getUniformLocation(prog, 'time')
    const uAspect  = gl.getUniformLocation(prog, 'aspect')
    const uColor1  = gl.getUniformLocation(prog, 'uColor1')
    const uColor2  = gl.getUniformLocation(prog, 'uColor2')
    const uColor3  = gl.getUniformLocation(prog, 'uColor3')
    const uSpeed   = gl.getUniformLocation(prog, 'uSpeed')
    const uDensity = gl.getUniformLocation(prog, 'uDensity')
    const uFade    = gl.getUniformLocation(prog, 'uFade')

    gl.uniform3fv(uColor1, new Float32Array(paletteConfig.uniforms[0]))
    gl.uniform3fv(uColor2, new Float32Array(paletteConfig.uniforms[1]))
    gl.uniform3fv(uColor3, new Float32Array(paletteConfig.uniforms[2]))
    gl.uniform1f(uSpeed, variantConfig.speed)
    gl.uniform1f(uDensity, variantConfig.density)

    const draw = (now: number) => {
      gl.uniform1f(uTime, now * 0.001)
      gl.uniform1f(uFade, 1.0 - fadeRef.current)
      gl.clearColor(0, 0, 0, 1)
      gl.clear(gl.COLOR_BUFFER_BIT)
      gl.drawArrays(gl.TRIANGLES, 0, 6)
    }

    const resize = () => {
      const requestedScale = resolutionScale ?? variantConfig.renderScale
      const scale = IS_SOFTWARE ? Math.min(requestedScale, 0.2) : requestedScale
      const w = Math.max(1, Math.floor(canvas.clientWidth * scale))
      const h = Math.max(1, Math.floor(canvas.clientHeight * scale))
      canvas.width = w
      canvas.height = h
      gl.viewport(0, 0, w, h)
      gl.uniform1f(uAspect, w / h)
      draw(performance.now())
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(canvas)

    let raf = 0
    const render = (now: number) => {
      draw(now)
      if (SHOULD_ANIMATE) raf = requestAnimationFrame(render)
    }
    raf = requestAnimationFrame(render)

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      gl.deleteBuffer(buf)
      gl.deleteProgram(prog)
      gl.deleteShader(vertexShader)
      gl.deleteShader(fragmentShader)
    }
  }, [paletteConfig, resolutionScale, variantConfig])

  if (IS_SOFTWARE) {
    return (
      <div
        aria-hidden="true"
        data-shader-mode="static-fallback"
        data-shader-variant="clean"
        className="nebula-static-fallback pointer-events-none fixed inset-0"
        style={{ zIndex: 0 }}
      />
    )
  }

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      data-shader-mode="animated"
      data-shader-variant={variantConfig.id}
      className="nebula-scroll-canvas pointer-events-none absolute inset-x-0 top-0 block h-[100dvh] w-full"
      style={{ zIndex: 0, imageRendering: 'auto' }}
    />
  )
}
