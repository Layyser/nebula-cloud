import classicSource from '../../shaders/nebula.glsl?raw'
import cleanSource from '../../shaders/nebula-clean.glsl?raw'

export type NebulaVariantId = 'clean' | 'classic'
export type NebulaPaletteId = 'graphite' | 'lunar' | 'violet'
export type Rgb = readonly [number, number, number]

export interface NebulaPalette {
  id: NebulaPaletteId
  label: string
  colors: readonly [string, string, string]
  uniforms: readonly [Rgb, Rgb, Rgb]
}

export interface NebulaVariant {
  id: NebulaVariantId
  label: string
  description: string
  fragmentSource: string
  speed: number
  density: number
  renderScale: number
}

export function hexToRgb(hex: string): Rgb {
  const value = Number.parseInt(hex.replace('#', ''), 16)
  return [
    ((value >> 16) & 255) / 255,
    ((value >> 8) & 255) / 255,
    (value & 255) / 255,
  ]
}

function palette(
  id: NebulaPaletteId,
  label: string,
  colors: readonly [string, string, string],
): NebulaPalette {
  return {
    id,
    label,
    colors,
    uniforms: colors.map(hexToRgb) as unknown as readonly [Rgb, Rgb, Rgb],
  }
}

export const NEBULA_PALETTES: readonly NebulaPalette[] = [
  palette('graphite', 'Graphite', ['#ffffff', '#535353', '#000000']),
  palette('lunar', 'Lunar', ['#f3f7ff', '#b6c9e8', '#1d2738']),
  palette('violet', 'Violet', ['#fbf8ff', '#c8b7df', '#2d243a']),
]

export const NEBULA_VARIANTS: readonly NebulaVariant[] = [
  {
    id: 'classic',
    label: 'Classic',
    description: 'The original layered cloud field with scattered stars.',
    fragmentSource: classicSource,
    speed: 0.1,
    density: 1.45,
    renderScale: 0.18,
  },
  {
    id: 'clean',
    label: 'Veil',
    description: 'Static fallback with broad negative space and one luminous filament.',
    fragmentSource: cleanSource,
    speed: 0.46,
    density: 1.12,
    renderScale: 0.42,
  },
]

export function getNebulaVariant(id: string | null | undefined): NebulaVariant {
  return NEBULA_VARIANTS.find(variant => variant.id === id) ?? NEBULA_VARIANTS[0]
}

export function getNebulaPalette(id: string | null | undefined): NebulaPalette {
  return NEBULA_PALETTES.find(item => item.id === id) ?? NEBULA_PALETTES[0]
}
