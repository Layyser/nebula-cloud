import { RefreshCw } from 'lucide-react'

export function RuntimeUnavailable({ checking, onRetry }: { checking: boolean; onRetry: () => void }) {
  return (
    <div className="relative z-[2] flex h-screen w-screen items-center justify-center px-6">
      <div className="w-full max-w-md rounded-xl border border-white/[0.09] bg-[#101111]/90 p-4 shadow-xl shadow-black/50 backdrop-blur-xl">
        <h1 className="text-lg font-medium text-white/90">Nebula runtime unavailable</h1>
        <p className="mt-2 text-[13px] leading-6 text-white/45">
          Start the local runtime, then reconnect this interface.
        </p>
        <code className="mt-4 block rounded-xl border border-white/[0.06] bg-black/30 px-4 py-3 text-[12px] text-white/65">nebula --serve</code>
        <button type="button" onClick={onRetry} disabled={checking} className="mt-5 flex h-9 items-center gap-2 rounded-xl bg-white px-3 text-[12px] font-medium text-black transition hover:bg-white/90 disabled:opacity-50">
          <RefreshCw size={13} className={checking ? 'animate-spin' : ''} />
          {checking ? 'Connecting…' : 'Try again'}
        </button>
      </div>
    </div>
  )
}
