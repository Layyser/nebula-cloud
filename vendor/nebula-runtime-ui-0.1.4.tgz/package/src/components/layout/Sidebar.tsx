import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import {
  Blocks, Bot, Search, SquarePen,
  Folder, FolderOpen, PanelLeftClose, PanelLeftOpen, Trash2,
} from 'lucide-react'
import { cn } from '#nebula/lib/utils'
import { NebulaMark } from '#nebula/components/ui/NebulaMark'
import { ScrollArea } from '#nebula/components/ui/scroll-area'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '#nebula/components/ui/tooltip'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { type ChatSession } from '#nebula/lib/api'
import { type RuntimeIdentityMenuItem, type RuntimeNavigationItem } from '#nebula/components/workspace/WorkspaceApp'

interface Props {
  chats: ChatSession[]
  activeChat: string | null
  onSelect: (name: string) => void
  onNew: () => void
  onNewInProject: (path: string) => void
  onDelete: (name: string) => Promise<void>
  onDeleteProject: (names: string[]) => Promise<void>
  onToggleHooks: (name: string, paused: boolean) => Promise<void>
  activeView: 'sessions' | 'agents' | 'connections' | null
  onAgents: () => void
  onConnections: () => void
  brandLabel: string
  identityLabel: string
  identityInitial: string
  identityMenuItems?: RuntimeIdentityMenuItem[]
  onBrandSelect?: () => void
  externalNavigation: RuntimeNavigationItem[]
}

interface ProjectGroup {
  key: string
  label: string
  path: string
  chats: ChatSession[]
}

function normalizePath(path?: string): string {
  return (path ?? '').replace(/\\/g, '/').replace(/\/+$/, '')
}

function projectGroups(chats: ChatSession[]): ProjectGroup[] {
  const groups = new Map<string, ProjectGroup>()
  for (const chat of chats) {
    const cwd = normalizePath(chat.cwd)
    const root = normalizePath(chat.workspace_root)
    const isWorkspace = !cwd || !root || cwd === root
    const key = isWorkspace ? '__workspace__' : cwd
    let group = groups.get(key)
    if (!group) {
      group = {
        key,
        label: isWorkspace
          ? 'Workspace'
          : (cwd.split('/').filter(Boolean).at(-1) ?? 'Workspace'),
        path: isWorkspace ? (root || 'Workspace') : cwd,
        chats: [],
      }
      groups.set(key, group)
    }
    group.chats.push(chat)
  }
  return [...groups.values()]
}

export function Sidebar({ chats, activeChat, onSelect, onNew, onNewInProject, onDelete, onDeleteProject, onToggleHooks, activeView, onAgents, onConnections, brandLabel, identityLabel, identityInitial, identityMenuItems = [], onBrandSelect, externalNavigation }: Props) {
  const [collapsed, setCollapsed] = useState(false)
  const [hovered, setHovered]     = useState(false)
  const [showExpandHint, setShowExpandHint] = useState(false)
  const [closedProjects, setClosedProjects] = useState<Set<string>>(() => new Set())
  const [confirmProject, setConfirmProject] = useState<string | null>(null)
  const [identityMenuOpen, setIdentityMenuOpen] = useState(false)
  const reduceMotion              = useReducedMotion()
  const groupedChats = useMemo(() => projectGroups(chats), [chats])

  useEffect(() => {
    if (!showExpandHint) return

    const timeout = window.setTimeout(() => setShowExpandHint(false), 3000)
    return () => window.clearTimeout(timeout)
  }, [showExpandHint])

  return (
    <TooltipProvider delayDuration={400}>
      <motion.aside
        initial={reduceMotion ? false : { opacity: 0, x: -14 }}
        animate={{ opacity: 1, x: 0 }}
        transition={reduceMotion
          ? { duration: 0 }
          : { duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className="flex-shrink-0 flex flex-col h-full overflow-hidden"
        style={{
          width: collapsed ? 56 : 240,
          transition: 'width 260ms cubic-bezier(0.4,0,0.2,1)',
          background: '#111111',
          borderRight: '1px solid rgba(255,255,255,0.07)',
          boxShadow: '4px 0 28px rgba(0,0,0,0.55)',
        }}
      >

        {/* ── Header — fixed h-16 so nav buttons never shift ── */}
        {collapsed ? (
          <div className="px-2 h-16 flex items-center flex-shrink-0">
            <button
              onClick={() => {
                setShowExpandHint(false)
                setCollapsed(false)
              }}
              className="relative ml-0.5 flex h-9 w-9 items-center justify-center rounded-xl text-white/55 hover:text-white/90 hover:bg-white/[0.06] transition-colors duration-150"
            >
              <AnimatePresence initial={false}>
                {showExpandHint || hovered ? (
                  <motion.span
                    key="expand"
                    className="absolute inset-0 flex items-center justify-center"
                    initial={reduceMotion ? false : { opacity: 0, scale: 0.82 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.82 }}
                    transition={reduceMotion ? { duration: 0 } : { duration: 0.18, ease: 'easeOut' }}
                  >
                    <PanelLeftOpen size={14} />
                  </motion.span>
                ) : (
                  <motion.span
                    key="nebula"
                    className="absolute inset-0 flex items-center justify-center"
                    initial={reduceMotion ? false : { opacity: 0, scale: 0.82 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.82 }}
                    transition={reduceMotion ? { duration: 0 } : { duration: 0.18, ease: 'easeOut' }}
                  >
                    <NebulaMark />
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-between h-16 pl-4 pr-3 flex-shrink-0">
            <button
              type="button"
              onClick={onBrandSelect}
              disabled={!onBrandSelect}
              className="flex min-w-0 items-center gap-2 overflow-hidden rounded-lg text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/35 disabled:cursor-default"
              aria-label={`${brandLabel} workspace`}
            >
              <NebulaMark />
              <span className="nebula-wordmark text-[14px] font-semibold tracking-tight select-none whitespace-nowrap">
                {brandLabel}
              </span>
            </button>
            <button
              onClick={() => {
                setShowExpandHint(true)
                setCollapsed(true)
              }}
              className="w-8 h-8 flex items-center justify-center rounded-lg flex-shrink-0 text-white/35 hover:text-white/80 hover:bg-white/[0.06] transition-colors duration-150"
            >
              <PanelLeftClose size={14} />
            </button>
          </div>
        )}

        {/* ── Nav buttons ── */}
        <div className="flex flex-col gap-0.5 px-2 pb-3 flex-shrink-0">
          <NavBtn icon={<SquarePen size={15} />}         label="New Session" collapsed={collapsed} active={activeView === 'sessions' && activeChat === null} onClick={onNew} />
          <NavBtn icon={<Bot size={15} />}              label="Agents"      collapsed={collapsed} active={activeView === 'agents'} onClick={onAgents} />
          <NavBtn icon={<Blocks size={15} />}            label="Capabilities" collapsed={collapsed} active={activeView === 'connections'} onClick={onConnections} />
          <NavBtn icon={<Search size={15} />}           label="Search"      collapsed={collapsed} active={false} onClick={() => {}} />
          {externalNavigation.map(item => (
            <NavBtn
              key={item.id}
              icon={item.icon}
              label={item.label}
              collapsed={collapsed}
              active={item.active ?? false}
              onClick={item.onSelect}
            />
          ))}
        </div>

        <div className="mx-3 mb-2 flex-shrink-0" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }} />

        {/* ── Sessions list (expanded only) ── */}
        {!collapsed ? (
          <ScrollArea className="flex-1 px-2 pb-2">
            <p className="sticky top-0 z-10 bg-[#111111] px-3 py-1.5 text-[10px] font-semibold text-white/35 uppercase tracking-widest select-none">
              Sessions
            </p>

            <div className="space-y-1">
              {groupedChats.map((group, groupIndex) => {
                const closed = closedProjects.has(group.key)
                return (
                  <motion.section
                    key={group.key}
                    layout
                    initial={reduceMotion ? false : { opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={reduceMotion ? { duration: 0 } : { duration: 0.22, delay: groupIndex * 0.025 }}
                  >
                    <div className="group/project mb-0.5 flex h-9 w-full items-center rounded-xl transition-colors hover:bg-white/[0.04]">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            type="button"
                            onClick={() => setClosedProjects(current => {
                              const next = new Set(current)
                              if (next.has(group.key)) next.delete(group.key)
                              else next.add(group.key)
                              return next
                            })}
                            aria-expanded={!closed}
                            className="flex h-full min-w-0 flex-1 items-center gap-2 px-2.5 text-left text-[12px] font-medium text-white/70 transition-colors hover:text-white/90"
                          >
                            {closed
                              ? <Folder size={13} className="shrink-0 text-white/45" />
                              : <FolderOpen size={13} className="shrink-0 text-white/45" />}
                            <span className="truncate">{group.label}</span>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="top" align="start">{group.path}</TooltipContent>
                      </Tooltip>

                      <div className={cn(
                        'mr-2 flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover/project:opacity-100',
                        confirmProject === group.key && 'opacity-100',
                      )}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              type="button"
                              onClick={event => {
                                event.stopPropagation()
                                onNewInProject(group.key === '__workspace__' ? '.' : group.path)
                              }}
                              className="flex h-5 w-5 items-center justify-center rounded-md p-1 text-white/35 transition-colors hover:bg-white/[0.06] hover:text-white/80"
                              aria-label={`New session in ${group.label}`}
                            >
                              <SquarePen size={12} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>New session here</TooltipContent>
                        </Tooltip>

                        <Popover open={confirmProject === group.key} onOpenChange={open => setConfirmProject(open ? group.key : null)}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <PopoverTrigger asChild>
                                <button
                                  type="button"
                                  onClick={event => { event.stopPropagation(); setConfirmProject(group.key) }}
                                  className={cn(
                                    'group/delete flex h-5 w-5 items-center justify-center rounded-md p-1 text-white/35 transition-colors hover:bg-red-400/10 hover:text-red-400/80',
                                    confirmProject === group.key && 'bg-red-400/10 text-red-400/80',
                                  )}
                                  aria-label={`Delete sessions in ${group.label}`}
                                >
                                  <Trash2 size={12} className="transition-colors group-hover/delete:text-red-400" />
                                </button>
                              </PopoverTrigger>
                            </TooltipTrigger>
                            <TooltipContent>Delete project sessions</TooltipContent>
                          </Tooltip>
                          <PopoverContent side="right" align="center" sideOffset={8} className="w-44 min-w-0" onOpenAutoFocus={event => event.preventDefault()}>
                            <div className="space-y-3 px-1 py-0.5">
                              <div>
                                <p className="text-[12px] font-semibold text-white/90">Delete project sessions?</p>
                                <p className="mt-1 text-[11px] leading-relaxed text-white/45">
                                  Removes all {group.chats.length} chat {group.chats.length === 1 ? 'history' : 'histories'} in {group.label}.
                                  The folder and agent definitions are not affected.
                                </p>
                              </div>
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={event => { event.stopPropagation(); setConfirmProject(null) }}
                                  className="flex h-7 flex-1 items-center justify-center rounded-lg pt-0.5 text-[11px] font-medium text-white/50 transition-colors hover:bg-white/[0.06] hover:text-white/80"
                                >
                                  Cancel
                                </button>
                                <button
                                  type="button"
                                  onClick={event => {
                                    event.stopPropagation()
                                    setConfirmProject(null)
                                    void onDeleteProject(group.chats.map(chat => chat.name))
                                      .catch(() => setConfirmProject(group.key))
                                  }}
                                  className="flex h-7 flex-1 items-center justify-center rounded-lg bg-red-500/10 pt-0.5 text-[11px] font-medium text-red-400/80 transition-colors hover:bg-red-500/20 hover:text-red-400"
                                >
                                  Delete
                                </button>
                              </div>
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>

                    <AnimatePresence initial={false}>
                      {!closed && (
                        <motion.div
                          key="sessions"
                          initial={reduceMotion ? false : { height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={reduceMotion ? { duration: 0 } : { duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
                          className="overflow-hidden"
                        >
                          {group.chats.map((chat, index) => (
                            <motion.div
                              key={chat.name}
                              layout
                              initial={reduceMotion ? false : { opacity: 0, y: -5 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={reduceMotion ? { duration: 0 } : { duration: 0.2, delay: index * 0.02 }}
                              style={{ overflow: 'hidden', marginBottom: 2 }}
                            >
                              <SessionItem
                                chat={chat}
                                grouped
                                active={chat.name === activeChat}
                                onSelect={() => onSelect(chat.name)}
                                onDelete={() => onDelete(chat.name)}
                                onToggleHooks={() => onToggleHooks(chat.name, !chat.hooks_paused)}
                              />
                            </motion.div>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.section>
                )
              })}
            </div>
          </ScrollArea>
        ) : (
          <div className="flex-1" />
        )}

        {/* ── Footer ── */}
        <div
          className="px-2 pt-2 pb-4 flex-shrink-0"
          style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}
        >
          {identityMenuItems.length > 0 ? <Popover open={identityMenuOpen} onOpenChange={setIdentityMenuOpen}>
            <Tooltip>
              <TooltipTrigger asChild>
                <PopoverTrigger asChild>
                  <button type="button" className={cn(
                    'flex min-w-0 items-center gap-2.5 rounded-xl text-left transition-colors duration-150 hover:bg-white/[0.06]',
                    collapsed
                      ? 'ml-0.5 h-9 w-9 justify-center'
                      : 'w-full px-2 py-2',
                  )}>
                    <div className="w-6 h-6 min-w-[24px] rounded-full bg-gradient-to-br from-violet-500/70 to-indigo-600/70 border border-white/15 flex items-center justify-center flex-shrink-0">
                      <span className="text-[10px] font-semibold text-white leading-none">{identityInitial.slice(0, 1).toUpperCase()}</span>
                    </div>
                    {!collapsed && (
                      <span className="min-w-0 flex-1 truncate text-[13px] text-white/65">{identityLabel}</span>
                    )}
                  </button>
                </PopoverTrigger>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right">{identityLabel}</TooltipContent>}
            </Tooltip>
            <PopoverContent side={collapsed ? 'right' : 'top'} align="start" sideOffset={8} className="w-52 p-1.5">
              <div className="mb-1 border-b border-white/[0.07] px-2 py-2">
                <p className="truncate text-[12px] font-medium text-white/80">{identityLabel}</p>
              </div>
              {identityMenuItems.map(item => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => {
                      setIdentityMenuOpen(false)
                      item.onSelect()
                    }}
                    disabled={item.disabled}
                    className={cn(
                      'flex h-8 w-full items-center gap-2 rounded-lg px-2 text-left text-[12px] transition-colors disabled:cursor-not-allowed disabled:opacity-35',
                      item.tone === 'danger'
                        ? 'text-red-300/65 hover:bg-red-400/[0.08] hover:text-red-300'
                        : 'text-white/55 hover:bg-white/[0.06] hover:text-white/85',
                    )}
                  >
                    <span className="flex h-5 w-5 items-center justify-center">{item.icon}</span>
                    <span>{item.label}</span>
                  </button>
              ))}
            </PopoverContent>
          </Popover> : (
            <Tooltip>
              <TooltipTrigger asChild>
                <div className={cn(
                  'flex min-w-0 items-center gap-2.5 rounded-xl transition-colors duration-150',
                  collapsed ? 'ml-0.5 h-9 w-9 justify-center' : 'w-full px-2 py-2',
                )}>
                  <div className="w-6 h-6 min-w-[24px] rounded-full bg-gradient-to-br from-violet-500/70 to-indigo-600/70 border border-white/15 flex items-center justify-center flex-shrink-0">
                    <span className="text-[10px] font-semibold text-white leading-none">{identityInitial.slice(0, 1).toUpperCase()}</span>
                  </div>
                  {!collapsed && <span className="min-w-0 flex-1 truncate text-[13px] text-white/65">{identityLabel}</span>}
                </div>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right">{identityLabel}</TooltipContent>}
            </Tooltip>
          )}
        </div>

      </motion.aside>
    </TooltipProvider>
  )
}

// ── Nav button ────────────────────────────────────────────────────────────────

function NavBtn({
  icon, label, collapsed, active, onClick,
}: {
  icon: React.ReactNode
  label: string
  collapsed: boolean
  onClick: () => void
  active: boolean
}) {
  const btn = (
    <button
      onClick={onClick}
      className={cn(
        'ml-0.5 flex h-9 items-center rounded-xl px-0 transition-colors duration-150',
        collapsed ? 'w-9' : 'w-[calc(100%-0.125rem)]',
        active
          ? 'bg-white/[0.08] text-white/90'
          : 'text-white/55 hover:text-white/90 hover:bg-white/[0.06]',
      )}
    >
      <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center">{icon}</span>
      <span
        className="overflow-hidden whitespace-nowrap transition-all duration-[260ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
        style={{
          maxWidth: collapsed ? 0 : 160,
          opacity: collapsed ? 0 : 1,
        }}
      >
        <span className="relative -top-[2px] text-[13px] font-medium">{label}</span>
      </span>
    </button>
  )

  if (!collapsed) return btn

  return (
    <Tooltip>
      <TooltipTrigger asChild>{btn}</TooltipTrigger>
      <TooltipContent side="right">{label}</TooltipContent>
    </Tooltip>
  )
}

// ── Session item ──────────────────────────────────────────────────────────────

function formatChatName(chatName: string): string {
  return chatName
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase())
}

function isGeneratedChatName(chatName: string): boolean {
  return /^chat-\d{13}-[a-f0-9]{8}$/i.test(chatName) ||
    /^\d{4}-\d{2}-\d{2}-\d{6}$/.test(chatName)
}

function compactChatName(chatName: string, isSubagent: boolean): string {
  const formatted = formatChatName(chatName)
  const maxLength = isSubagent ? 13 : 16
  if (formatted.length <= maxLength) return formatted
  return `${formatted.slice(0, maxLength).trimEnd()}...`
}

function treePrefix(chat: ChatSession): string {
  const depth = chat.depth ?? 0
  if (depth <= 0) return ''
  return `${'  '.repeat(Math.max(0, depth - 1))}${chat.last_child ? '└─ ' : '├─ '}`
}

function needsInput(chat: ChatSession): boolean {
  return chat.run?.status === 'needs_input' ||
    Boolean(chat.run?.input_prompt) ||
    Boolean(chat.run?.input_options?.length)
}

function RunIndicator({ chat, onSelect }: { chat: ChatSession; onSelect: () => void }) {
  if (!chat.run) return null

  const waitingForInput = needsInput(chat)
  const label = waitingForInput
    ? 'Needs input'
    : chat.run.status === 'cancelling' ? 'Stopping' : 'Thinking'

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span
          className={cn(
            'flex items-center flex-shrink-0 ml-1 cursor-pointer rounded-md transition-colors hover:bg-amber-400/10 hover:text-amber-200 text-[10px] leading-none font-medium whitespace-nowrap',
            waitingForInput ? 'text-amber-300/90' : 'text-sky-300/85',
          )}
          onClick={e => {
            e.stopPropagation()
            onSelect()
          }}
          role="button"
          tabIndex={0}
          onKeyDown={e => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault()
              e.stopPropagation()
              onSelect()
            }
          }}
          aria-label={label}
        >
          {waitingForInput
            ? <span className="flex items-center justify-center w-5 h-5 p-1 rounded-md"><span>✵</span></span>
            : <span className="flex items-center justify-center w-5 h-5 p-1 rounded-md"><span className="run-spinner" aria-hidden="true" /></span>}
        </span>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  )
}

function SessionItem({
  chat, active, grouped = false, onSelect, onDelete, onToggleHooks,
}: {
  chat: ChatSession
  active: boolean
  grouped?: boolean
  onSelect: () => void
  onDelete: () => Promise<void>
  onToggleHooks: () => Promise<void>
}) {
  const [confirmOpen, setConfirmOpen] = useState(false)
  const label = chat.agent ?? 'Default'
  const isSubagent = chat.kind === 'subagent'
  const displayName = isGeneratedChatName(chat.name)
    ? (chat.display_name ?? 'New chat')
    : (chat.display_name ?? chat.name)

  return (
    <div
      onClick={onSelect}
      className={cn(
        'group flex items-center w-full h-9 rounded-xl transition-colors duration-150 cursor-pointer',
        grouped ? 'pl-6 pr-3' : 'px-3',
        active
          ? 'bg-white/[0.06] text-white'
          : 'text-white/55 hover:text-white/90 hover:bg-white/[0.06]',
      )}
    >
      <span className="flex-1 min-w-0 flex items-center text-left overflow-hidden">
        {(chat.depth ?? 0) > 0 && (
          <span className="text-[12px] text-white/25 flex-shrink-0 whitespace-pre">
            {treePrefix(chat)}
          </span>
        )}
        <span className={cn(
          'min-w-0 text-[13px] font-medium truncate',
          isSubagent && 'text-white/45',
        )}>
          {compactChatName(displayName, isSubagent)}
        </span>
        {chat.has_hooks && (
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={e => {
                  e.stopPropagation()
                  void onToggleHooks()
                }}
                className="flex items-center justify-center w-5 h-5 ml-1 p-1 rounded-md text-sky-300/80 hover:text-sky-200 hover:bg-sky-400/10 transition-colors flex-shrink-0"
                aria-label={chat.hooks_paused ? 'Enable hooks' : 'Stop hooks'}
              >
                {chat.hooks_paused
                  ? <span className="hook-paused" aria-hidden="true" />
                  : <span className="hook-listening" aria-hidden="true" />}
              </button>
            </TooltipTrigger>
            <TooltipContent>{chat.hooks_paused ? 'Enable hooks' : 'Stop hooks'}</TooltipContent>
          </Tooltip>
        )}
        <RunIndicator chat={chat} onSelect={onSelect} />
      </span>
      <span className={cn(
        'text-[11px] text-white/30 ml-2 flex-shrink-0 group-hover:hidden',
        confirmOpen && 'hidden',
      )}>
        {formatChatName(label)}
      </span>
      <Popover open={confirmOpen} onOpenChange={setConfirmOpen}>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <button
                onClick={e => { e.stopPropagation(); setConfirmOpen(true) }}
                className={cn(
                  'group/delete hidden group-hover:flex opacity-0 group-hover:opacity-100 transition-opacity w-5 h-5 p-1 rounded-md text-white/35 hover:text-red-400/80 hover:bg-red-400/10 flex-shrink-0',
                  confirmOpen && 'flex opacity-100',
                )}
                aria-label="Delete session"
              >
                <Trash2 size={12} className="transition-colors group-hover/delete:text-red-400" />
              </button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent>Delete session</TooltipContent>
        </Tooltip>
        <PopoverContent side="right" align="center" sideOffset={8} className="w-44 min-w-0" onOpenAutoFocus={e => e.preventDefault()}>
          <div className="space-y-3 px-1 py-0.5">
            <div>
              <p className="text-[12px] font-semibold text-white/90">Delete session?</p>
              <p className="text-[11px] text-white/45 mt-1 leading-relaxed">
                Removes the chat history and its agent config link.
                The agent definition itself is not affected.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={e => { e.stopPropagation(); setConfirmOpen(false) }}
                className="flex-1 h-7 rounded-lg text-[11px] font-medium text-white/50 hover:text-white/80 hover:bg-white/[0.06] transition-colors flex items-center justify-center pt-0.5"
              >
                Cancel
              </button>
              <button
                onClick={e => {
                  e.stopPropagation()
                  setConfirmOpen(false)
                  void onDelete().catch(() => setConfirmOpen(true))
                }}
                className="flex-1 h-7 rounded-lg text-[11px] font-medium bg-red-500/10 text-red-400/80 hover:bg-red-500/20 hover:text-red-400 transition-colors flex items-center justify-center pt-0.5"
              >
                Delete
              </button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
