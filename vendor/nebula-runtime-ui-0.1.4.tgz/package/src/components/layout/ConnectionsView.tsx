import { useCallback, useEffect, useMemo, useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { AtSign, BookOpen, CheckCircle2, Clock3, Code2, Plus, Save, ScrollText, Trash2, X } from 'lucide-react'
import { ScrollArea } from '#nebula/components/ui/scroll-area'
import { ContextSelect } from '#nebula/components/ui/context-select'
import {
  deleteCapability, fetchCapabilities, saveFileCapability, saveHook, saveMcp,
  type CapabilityCatalog, type CapabilityFileInfo, type HookInfo, type McpInfo,
} from '#nebula/lib/api'
import { cn } from '#nebula/lib/utils'

interface Props { mcps: McpInfo[]; onRefresh: () => Promise<void> }
type Tab = 'mcps' | 'skills' | 'commands' | 'hooks' | 'rules'
const tabs: Array<{ id: Tab; label: string; icon: React.ReactNode; detail: string }> = [
  { id: 'mcps', label: 'MCPs', icon: <AtSign size={13} />, detail: 'External tools and services' },
  { id: 'skills', label: 'Skills', icon: <BookOpen size={13} />, detail: 'Reusable agent playbooks' },
  { id: 'commands', label: 'Commands', icon: <Code2 size={13} />, detail: 'CLI slash commands' },
  { id: 'hooks', label: 'Hooks', icon: <Clock3 size={13} />, detail: 'Automated event triggers' },
  { id: 'rules', label: 'Rules', icon: <ScrollText size={13} />, detail: 'Reusable instruction files' },
]
const emptyCatalog: CapabilityCatalog = { mcps: [], skills: [], commands: [], hooks: [], rules: [], tools: [] }
const inputClass = 'w-full rounded-lg border border-white/[0.10] bg-[#0b0b0b] px-3 py-2 text-[12px] text-white/80 placeholder:text-zinc-600 outline-none focus:border-white/[0.25]'
const surfaceShadow = { boxShadow: '0 8px 40px rgba(0,0,0,0.55), 0 2px 12px rgba(0,0,0,0.35)' }
const capabilitySignature = (value: Record<string, unknown>) => JSON.stringify(value)
const blankEditor = { name: '', description: '', content: '', transport: 'http', event: 'webhook', detail: '', envJson: '', headersJson: '', includeText: '', excludeText: '', excluded: false, hookDefault: false, filterJson: '', every: '', at: '', secret: '', telegramToken: '' }
const emptySignature = capabilitySignature(blankEditor)
function parseJsonObject(text: string, label: string): Record<string, string> | undefined {
  if (!text.trim()) return undefined
  let parsed: unknown
  try { parsed = JSON.parse(text) } catch { throw new Error(`${label} must be valid JSON.`) }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error(`${label} must be a JSON object.`)
  return Object.fromEntries(Object.entries(parsed).map(([key, value]) => [key, String(value)]))
}

export function ConnectionsView({ mcps, onRefresh }: Props) {
  const reduceMotion = useReducedMotion()
  const [tab, setTab] = useState<Tab>('mcps')
  const [catalog, setCatalog] = useState<CapabilityCatalog>({ ...emptyCatalog, mcps })
  const [editing, setEditing] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [content, setContent] = useState('')
  const [transport, setTransport] = useState<'http' | 'stdio'>('http')
  const [event, setEvent] = useState<HookInfo['event']>('webhook')
  const [detail, setDetail] = useState('')
  const [envJson, setEnvJson] = useState('')
  const [headersJson, setHeadersJson] = useState('')
  const [includeText, setIncludeText] = useState('')
  const [excludeText, setExcludeText] = useState('')
  const [excluded, setExcluded] = useState(false)
  const [hookDefault, setHookDefault] = useState(false)
  const [filterJson, setFilterJson] = useState('')
  const [every, setEvery] = useState('')
  const [at, setAt] = useState('')
  const [secret, setSecret] = useState('')
  const [telegramToken, setTelegramToken] = useState('')
  const [feedback, setFeedback] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [originalSignature, setOriginalSignature] = useState(emptySignature)

  const refresh = useCallback(async () => {
    const next = await fetchCapabilities()
    setCatalog(next)
  }, [])
  useEffect(() => { void refresh().catch(() => setCatalog(current => ({ ...current, mcps }))) }, [refresh, mcps])

  const resetExtended = () => { setEnvJson(''); setHeadersJson(''); setIncludeText(''); setExcludeText(''); setExcluded(false); setHookDefault(false); setFilterJson(''); setEvery(''); setAt(''); setSecret(''); setTelegramToken('') }
  const close = () => { setCreating(false); setEditing(null); setName(''); setDescription(''); setContent(''); setTransport('http'); setEvent('webhook'); setDetail(''); resetExtended(); setFeedback(null); setConfirmDelete(false); setOriginalSignature(emptySignature) }
  const beginNew = () => { close(); setCreating(true); setOriginalSignature(emptySignature) }
  const switchTab = (nextTab: Tab) => {
    if (nextTab === tab) return
    close()
    setTab(nextTab)
  }
  const items = useMemo(() => catalog[tab] ?? [], [catalog, tab])
  const activeItem = editing ? (items as Array<McpInfo | CapabilityFileInfo | HookInfo>).find(item => item.name === editing) : undefined
  const currentEditor = { name, description, content, transport, event, detail, envJson, headersJson, includeText, excludeText, excluded, hookDefault, filterJson, every, at, secret, telegramToken }
  const currentSignature = capabilitySignature(currentEditor)
  const hasChanges = currentSignature !== originalSignature

  const editItem = (item: McpInfo | CapabilityFileInfo | HookInfo) => {
    setCreating(true); setEditing(item.name); setName(item.name); setFeedback(null)
    if (tab === 'mcps') {
      const mcp = item as McpInfo
      const nextDescription = mcp.description ?? ''
      const nextDetail = mcp.transport === 'http' ? (mcp.url ?? '') : (mcp.command ?? []).join('\n')
      const nextEnv = mcp.env ? JSON.stringify(mcp.env, null, 2) : ''
      const nextHeaders = mcp.headers ? JSON.stringify(mcp.headers, null, 2) : ''
      const nextInclude = (mcp.include ?? []).join('\n')
      const nextExclude = (mcp.exclude ?? []).join('\n')
      setDescription(nextDescription); setTransport(mcp.transport); setContent(''); setEvent('webhook'); setDetail(nextDetail)
      setEnvJson(nextEnv); setHeadersJson(nextHeaders); setIncludeText(nextInclude); setExcludeText(nextExclude); setExcluded(mcp.excluded_by_default)
      setHookDefault(false); setFilterJson(''); setEvery(''); setAt(''); setSecret(''); setTelegramToken('')
      setOriginalSignature(capabilitySignature({ ...blankEditor, name: item.name, description: nextDescription, transport: mcp.transport, detail: nextDetail, envJson: nextEnv, headersJson: nextHeaders, includeText: nextInclude, excludeText: nextExclude, excluded: mcp.excluded_by_default }))
    } else if (tab === 'hooks') {
      const hook = item as HookInfo
      const nextContent = hook.prompt ?? ''
      const nextDetail = hook.path ?? ''
      const nextFilter = hook.filter && Object.keys(hook.filter).length ? JSON.stringify(hook.filter, null, 2) : ''
      setDescription(''); setTransport('http'); setEvent(hook.event); setContent(nextContent); setDetail(nextDetail)
      setEnvJson(''); setHeadersJson(''); setIncludeText(''); setExcludeText(''); setExcluded(false)
      setHookDefault(Boolean(hook.default)); setFilterJson(nextFilter); setEvery(hook.every ?? ''); setAt(hook.at ?? ''); setSecret(hook.secret ?? ''); setTelegramToken(hook.telegram_token ?? '')
      setOriginalSignature(capabilitySignature({ ...blankEditor, name: item.name, content: nextContent, event: hook.event, detail: nextDetail, hookDefault: Boolean(hook.default), filterJson: nextFilter, every: hook.every ?? '', at: hook.at ?? '', secret: hook.secret ?? '', telegramToken: hook.telegram_token ?? '' }))
    } else {
      const file = item as CapabilityFileInfo
      const nextDescription = file.description ?? ''
      const nextContent = file.content ?? ''
      setDescription(nextDescription); setContent(nextContent); setTransport('http'); setEvent('webhook'); setDetail('')
      resetExtended()
      setOriginalSignature(capabilitySignature({ ...blankEditor, name: item.name, description: nextDescription, content: nextContent }))
    }
  }

  const submit = async () => {
    const cleanName = name.trim().toLowerCase().replace(/[^a-z0-9._-]+/g, '-')
    if (!cleanName) { setFeedback('Add a name before saving.'); return }
    setSaving(true); setFeedback(null)
    try {
      if (tab === 'mcps') {
        const command = detail.split(/\r?\n/).map(value => value.trim()).filter(Boolean)
        const env = parseJsonObject(envJson, 'Environment variables') ?? {}
        const headers = parseJsonObject(headersJson, 'Headers') ?? {}
        const include = includeText.split(/\r?\n/).map(value => value.trim()).filter(Boolean)
        const exclude = excludeText.split(/\r?\n/).map(value => value.trim()).filter(Boolean)
        if (transport === 'http' && !detail.trim()) throw new Error('Add the MCP server URL.')
        if (transport === 'stdio' && command.length === 0) throw new Error('Add at least one command token.')
        await saveMcp({ name: cleanName, description: description.trim(), transport,
          url: transport === 'http' ? detail.trim() : undefined,
          command: transport === 'stdio' ? command : undefined,
          env: transport === 'stdio' ? env : undefined,
          headers: transport === 'http' ? headers : undefined,
          include,
          exclude,
          excluded_by_default: excluded })
        await onRefresh()
      } else if (tab === 'hooks') {
        let filter: Record<string, unknown> | undefined
        if (filterJson.trim()) {
          try { filter = JSON.parse(filterJson) as Record<string, unknown> } catch { throw new Error('Filter must be valid JSON.') }
          if (!filter || typeof filter !== 'object' || Array.isArray(filter)) throw new Error('Filter must be a JSON object.')
        }
        if (!content.trim()) throw new Error('Add a prompt template.')
        if ((event === 'webhook' || event === 'file') && !detail.trim()) throw new Error('Add the hook path.')
        if (event === 'cron' && !every.trim() && !at.trim()) throw new Error('Add an interval, a time of day, or both.')
        const hook: Omit<HookInfo, 'name'> = { event, prompt: content, default: hookDefault, filter }
        if (event === 'webhook' || event === 'file') hook.path = detail.trim()
        if (event === 'webhook') hook.secret = secret.trim()
        if (event === 'cron') { hook.every = every.trim(); hook.at = at.trim() }
        if (event === 'telegram' && telegramToken.trim()) hook.telegram_token = telegramToken.trim()
        await saveHook(cleanName, hook)
      } else {
        let source = content
        if (tab === 'skills') source = `---\nname: ${cleanName}\ndescription: ${description.trim()}\n---\n\n${content.trim()}\n`
        if (tab === 'commands' && !source.startsWith('#!')) source = `#!/bin/sh\n${source}`
        await saveFileCapability(tab, cleanName, source)
      }
      await refresh(); close()
    } catch (error) { setFeedback(error instanceof Error ? error.message : 'Failed to save capability.') }
    finally { setSaving(false) }
  }
  const removeCurrent = async () => {
    if (!editing) return
    if (!confirmDelete) { setConfirmDelete(true); return }
    setSaving(true); setFeedback(null)
    try { await deleteCapability(tab, editing); await onRefresh(); await refresh(); close() }
    catch (error) { setFeedback(error instanceof Error ? error.message : 'Failed to delete capability.') }
    finally { setSaving(false) }
  }

  return <div className="relative flex-1 h-full w-full min-w-0 overflow-hidden">
    <ScrollArea className="h-full"><main className="mx-auto w-full max-w-6xl px-8 py-8">
      <div className="flex items-start justify-between gap-4 mb-6">
        <div className="app-heading-blob"><p className="text-[11px] uppercase tracking-[0.2em] text-white/35 font-semibold">Workspace</p>
          <h1 className="text-2xl font-semibold text-white/90 mt-1">Capabilities</h1>
          <p className="text-sm text-white/45 mt-1">Build the tools, knowledge, automation, and rules available to your agents.</p>
        </div>
        <button aria-label={creating ? 'Close capability editor' : `New ${tabs.find(value => value.id === tab)?.label.slice(0, -1)}`} onClick={creating ? close : beginNew} className={cn('inline-flex h-9 items-center justify-center gap-1.5 rounded-xl border border-white/[0.13] bg-black/20 text-xs font-medium text-white/60 backdrop-blur-md transition hover:bg-white/[0.08] hover:text-white', creating ? 'w-9' : 'px-3 pl-2')}>
          {creating ? <X size={15} /> : <><Plus size={14} />{`New ${tabs.find(value => value.id === tab)?.label.slice(0, -1)}`}</>}
        </button>
      </div>

      <div role="tablist" aria-label="Capability type" className="mb-5 inline-flex max-w-full overflow-x-auto rounded-xl border border-white/[0.10] bg-black/20 backdrop-blur-md">
        {tabs.map((item, index) => <button key={item.id} type="button" role="tab" aria-selected={tab === item.id} onClick={() => switchTab(item.id)} className={cn('flex h-9 min-w-[104px] items-center justify-center gap-1.5 border-r border-white/[0.08] px-3 text-[12px] transition-colors duration-200 last:border-r-0', tab === item.id ? 'bg-white/[0.10] text-white/90 shadow-sm' : 'text-white/42 hover:bg-white/[0.05] hover:text-white/70', index === 0 && 'rounded-l-[11px]', index === tabs.length - 1 && 'rounded-r-[11px]')}>
          {item.icon}<span>{item.label}</span>
        </button>)}
      </div>

      {creating && <section style={surfaceShadow} className="mb-5 rounded-xl border border-white/[0.10] bg-[#111] p-5">
        <div className="mb-4"><h2 className="text-[15px] font-semibold text-white/85">{editing ? 'Edit' : 'Create'} {tabs.find(value => value.id === tab)?.label.slice(0, -1)}</h2>
          <p className="mt-1 text-[12px] text-white/40">Saved in this workspace. Organization publishing can be added without changing this format.</p></div>
        {editing && activeItem && <CapabilityStatus tab={tab} item={activeItem} />}
        <div className="grid gap-4 lg:grid-cols-2">
          <Field label="Name"><input disabled={Boolean(editing)} value={name} onChange={e => setName(e.target.value)} className={cn(inputClass, editing && 'opacity-50')} placeholder="capability-name" /></Field>
          {tab === 'mcps' && <Field label="Transport"><ContextSelect value={transport} onChange={setTransport} ariaLabel="MCP transport" options={[{ value: 'http', label: 'HTTP' }, { value: 'stdio', label: 'Local process (stdio)' }]} contentWidth="w-52" /></Field>}
          {tab === 'hooks' && <Field label="Event"><ContextSelect value={event} onChange={setEvent} ariaLabel="Hook event" options={[{ value: 'webhook', label: 'Webhook' }, { value: 'cron', label: 'Cron' }, { value: 'telegram', label: 'Telegram' }, { value: 'file', label: 'File' }]} /></Field>}
          {(tab === 'mcps' || tab === 'skills') && <Field label="Description"><input value={description} onChange={e => setDescription(e.target.value)} className={inputClass} placeholder="What does this provide?" /></Field>}
          {tab === 'mcps' && <div className="lg:col-span-2"><Field label={transport === 'http' ? 'URL' : 'Launch command — one token per line'}><textarea value={detail} onChange={e => setDetail(e.target.value)} className={cn(inputClass, 'min-h-20 font-mono leading-5')} placeholder={transport === 'http' ? 'https://example.com/mcp' : 'python3\n.nebula/servers/example.py'} /></Field></div>}
          {tab === 'mcps' && transport === 'stdio' && <Field label="Environment variables (JSON)"><textarea value={envJson} onChange={e => setEnvJson(e.target.value)} className={cn(inputClass, 'min-h-24 font-mono leading-5')} placeholder={'{\n  "API_TOKEN": "$API_TOKEN"\n}'} /></Field>}
          {tab === 'mcps' && transport === 'http' && <Field label="HTTP headers (JSON)"><textarea value={headersJson} onChange={e => setHeadersJson(e.target.value)} className={cn(inputClass, 'min-h-24 font-mono leading-5')} placeholder={'{\n  "Authorization": "Bearer $TOKEN"\n}'} /></Field>}
          {tab === 'mcps' && <Field label="Only include tools (one per line)"><textarea value={includeText} onChange={e => setIncludeText(e.target.value)} className={cn(inputClass, 'min-h-24 font-mono leading-5')} placeholder="search_repositories" /></Field>}
          {tab === 'mcps' && <Field label="Exclude tools (one per line)"><textarea value={excludeText} onChange={e => setExcludeText(e.target.value)} className={cn(inputClass, 'min-h-24 font-mono leading-5')} placeholder="delete_repository" /></Field>}
          {tab === 'mcps' && <label className="flex items-center gap-2 text-[12px] text-white/55"><input type="checkbox" checked={excluded} onChange={e => setExcluded(e.target.checked)} /> Exclude from default sessions</label>}
          {tab === 'hooks' && (event === 'webhook' || event === 'file') && <Field label="Path"><input value={detail} onChange={e => setDetail(e.target.value)} className={inputClass} placeholder={event === 'webhook' ? '/webhook/github' : '/tmp/nebula-trigger'} /></Field>}
          {tab === 'hooks' && event === 'webhook' && <Field label="HMAC secret or environment reference"><input value={secret} onChange={e => setSecret(e.target.value)} className={inputClass} placeholder="$GITHUB_WEBHOOK_SECRET" /></Field>}
          {tab === 'hooks' && event === 'cron' && <Field label="Interval"><input value={every} onChange={e => setEvery(e.target.value)} className={inputClass} placeholder="30m" /></Field>}
          {tab === 'hooks' && event === 'cron' && <Field label="Time of day"><input value={at} onChange={e => setAt(e.target.value)} className={inputClass} placeholder="09:00" /></Field>}
          {tab === 'hooks' && event === 'telegram' && <div className="lg:col-span-2"><Field label="Telegram token or environment reference"><input value={telegramToken} onChange={e => setTelegramToken(e.target.value)} className={inputClass} placeholder="$TELEGRAM_BOT_TOKEN" /></Field></div>}
          {tab === 'hooks' && <label className="flex items-center gap-2 text-[12px] text-white/55"><input type="checkbox" checked={hookDefault} onChange={e => setHookDefault(e.target.checked)} /> Also fire in the default session</label>}
          {tab === 'hooks' && <Field label="Payload filter (JSON)"><textarea value={filterJson} onChange={e => setFilterJson(e.target.value)} className={cn(inputClass, 'min-h-24 font-mono leading-5')} placeholder={'{\n  "ref": "refs/heads/main"\n}'} /></Field>}
          {tab !== 'mcps' && <div className="lg:col-span-2"><Field label={tab === 'hooks' ? 'Prompt template' : tab === 'commands' ? 'Shell script' : tab === 'rules' ? 'Rule content' : 'Skill instructions'}><textarea value={content} onChange={e => setContent(e.target.value)} className={cn(inputClass, 'min-h-44 font-mono leading-5 resize-y')} /></Field></div>}
        </div>
        <div className="mt-5 flex items-center justify-between border-t border-white/[0.07] pt-4"><div className="flex items-center gap-3">{editing && <button disabled={saving} onClick={removeCurrent} className="flex h-9 items-center gap-1.5 rounded-xl border border-red-400/15 bg-red-400/[0.05] px-3 text-[12px] text-red-300/65 hover:bg-red-400/[0.10]"><Trash2 size={13} />{confirmDelete ? 'Confirm delete' : 'Delete'}</button>}<p className="text-[12px] text-red-400/80">{feedback}</p></div>
          <button disabled={saving || !hasChanges} onClick={submit} className="flex h-9 items-center gap-1.5 rounded-xl bg-white/90 px-3 text-[12px] font-medium text-black disabled:cursor-not-allowed disabled:opacity-40"><Save size={13} />{saving ? 'Saving…' : editing ? 'Save changes' : `Save ${tabs.find(value => value.id === tab)?.label.slice(0, -1)}`}</button></div>
      </section>}

      {!creating && <div key={tab} className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {(items as Array<McpInfo | CapabilityFileInfo | HookInfo>).map((item, index) => <CapabilityCard key={`${tab}:${item.name}`} tab={tab} item={item} index={index} reduceMotion={Boolean(reduceMotion)} onClick={() => editItem(item)} />)}
        {items.length === 0 && <div className="col-span-full rounded-xl border border-dashed border-white/[0.13] bg-black/20 p-10 text-center text-xs text-white/40 backdrop-blur-md">No {tab} are configured yet.</div>}
      </div>}
    </main></ScrollArea>
  </div>
}

function CapabilityStatus({ tab, item }: { tab: Tab; item: McpInfo | CapabilityFileInfo | HookInfo }) {
  if (tab === 'mcps') {
    const mcp = item as McpInfo
    return <div className="mb-4 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl border border-white/[0.07] bg-black/20 px-3 py-2 text-[11px] text-white/42">
      <span><span className="text-white/65">Status</span> {mcp.loaded ? 'Connected' : (mcp.state ?? 'Configured')}</span>
      <span><span className="text-white/65">Tools</span> {mcp.tools ?? 0}</span>
      <span><span className="text-white/65">Generation</span> {mcp.generation ?? '—'}</span>
      <span><span className="text-white/65">Default</span> {mcp.excluded_by_default ? 'Excluded' : 'Enabled'}</span>
      {mcp.error && <span className="w-full text-red-300/65">{mcp.error}</span>}
    </div>
  }
  if (tab === 'hooks') {
    const hook = item as HookInfo
    return <div className="mb-4 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl border border-white/[0.07] bg-black/20 px-3 py-2 text-[11px] text-white/42"><span><span className="text-white/65">Event</span> {hook.event}</span><span><span className="text-white/65">Routing</span> {hook.default ? 'Agents + default session' : 'Assigned agents only'}</span><span>Runtime reload required after changes</span></div>
  }
  const file = item as CapabilityFileInfo
  return <div className="mb-4 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl border border-white/[0.07] bg-black/20 px-3 py-2 text-[11px] text-white/42"><span><span className="text-white/65">Scope</span> {file.scope}</span>{file.source && <span className="min-w-0 truncate"><span className="text-white/65">Source</span> {file.source}</span>}</div>
}

function CapabilityCard({ tab, item, index, reduceMotion, onClick }: { tab: Tab; item: McpInfo | CapabilityFileInfo | HookInfo; index: number; reduceMotion: boolean; onClick: () => void }) {
  const description = tab === 'mcps' ? ((item as McpInfo).description || 'External tool connection.') : tab === 'hooks' ? ((item as HookInfo).prompt || 'Automated event trigger.') : ((item as CapabilityFileInfo).description || `${tabs.find(value => value.id === tab)?.detail}.`)
  const badge = tab === 'mcps' ? (item as McpInfo).transport : tab === 'hooks' ? (item as HookInfo).event : (item as CapabilityFileInfo).scope
  const icon = tabs.find(value => value.id === tab)?.icon
  const status = tab === 'mcps'
    ? ((item as McpInfo).loaded ? 'Connected' : ((item as McpInfo).state || 'Configured'))
    : tab === 'hooks'
      ? ((item as HookInfo).default ? 'Default session' : 'Agent routed')
      : ((item as CapabilityFileInfo).scope || 'Available')
  return <motion.article
    initial={reduceMotion ? false : { opacity: 0, y: 8, scale: 0.985, filter: 'blur(3px)' }}
    animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
    transition={reduceMotion ? { duration: 0 } : { duration: 0.42, delay: Math.min(index, 8) * 0.045, ease: [0.22, 1, 0.36, 1] }}
    style={surfaceShadow} role="button" tabIndex={0} onClick={onClick} className="min-h-[164px] cursor-pointer rounded-xl border border-white/[0.08] bg-[#111] p-4 transition-colors hover:bg-[#171717]">
    <div className="flex items-start justify-between gap-3"><div className="flex min-w-0 items-center gap-2"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white/[0.07] text-white/55">{icon}</div><h2 className="truncate text-[14px] font-semibold text-white/85">{item.name}</h2></div><span className="rounded-full bg-white/[0.08] px-2 py-0.5 text-[9px] uppercase text-white/42">{badge}</span></div>
    <p className="mt-4 line-clamp-3 min-h-[54px] text-[12px] leading-relaxed text-white/48">{description}</p>
    <div className="mt-3 flex flex-wrap items-center gap-2 text-[10px] text-emerald-300/55"><span className="inline-flex items-center gap-1"><CheckCircle2 size={11} />{status}</span>{tab === 'mcps' && (item as McpInfo).tools !== undefined && <span className="text-white/35">{(item as McpInfo).tools} tools</span>}{tab === 'mcps' && (item as McpInfo).excluded_by_default && <span className="text-white/35">Excluded by default</span>}</div>
  </motion.article>
}

function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="block"><span className="mb-1.5 block text-[10px] font-semibold uppercase tracking-widest text-white/35">{label}</span>{children}</label> }
