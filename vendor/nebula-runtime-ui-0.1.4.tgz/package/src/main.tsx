import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { configureDesktopRuntime } from './runtime/desktopRuntime'

async function start() {
  const transport = await configureDesktopRuntime()
  const { default: App } = await import('./App.tsx')

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App transport={transport ?? undefined} />
    </StrictMode>,
  )
}

void start()
