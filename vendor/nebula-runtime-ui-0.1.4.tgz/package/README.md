# Nebula standalone web

Standalone React + TypeScript frontend for the Nebula agent runtime. This
repository also exports the organization-agnostic runtime workspace consumed
by Nebula Cloud.

## Run locally

Run:

```bash
bun install
bun run dev
```

## Windows desktop shell (WSL runtime)

Nebula Desktop is a native Tauri window that starts the Linux runtime through
`wsl.exe`. It bundles the sibling `../agentic/nebula` binary, creates a
`workspace` folder beside a portable executable (or falls back to
`%USERPROFILE%\\NebulaWorkspace` when installed), waits for the API, and
stops only the runtime process that it owns when the window closes.

```powershell
bun install
bun run desktop:dev
bun run desktop:build
```

The machine needs WSL with an `Ubuntu` distribution. Override the defaults with
`NEBULA_WSL_DISTRO`, `NEBULA_DESKTOP_RUNTIME`, or
`NEBULA_DESKTOP_WORKSPACE`. The desktop shell generates an ephemeral bearer
token for each launch and exposes the runtime only on `127.0.0.1:7777`.

### Synchronizing the Windows mirror

The WSL repository at `/home/jorge/nebula-frontend` is the canonical working
tree. The portable Windows source directory is a one-way mirror used for native
Tauri builds; do not edit both copies independently.

```powershell
$pack = 'C:\Users\Jorge\Desktop\Nebula-pack'
robocopy '\\wsl.localhost\Ubuntu\home\jorge\nebula-frontend' "$pack\source\nebula-frontend" /MIR /XD .git node_modules dist target
New-Item -ItemType Directory -Force "$pack\source\agentic" | Out-Null
Copy-Item '\\wsl.localhost\Ubuntu\home\jorge\agentic\nebula' "$pack\source\agentic\nebula" -Force
```

After the current work is committed, GitHub should become the source sync:
push from WSL and use `git pull --ff-only` in a real Windows clone of
`https://github.com/Layyser/Nebula-frontend.git`. The executable, Linux runtime,
workspace configuration, and build cache remain generated/local artifacts and
should not be synchronized through Git.

The development server checks the local runtime and launches `nebula --serve`
in the background when it is not already running. It leaves an independently
started runtime untouched and stops only a runtime process that it launched.

Local development discovers the sibling binary at `../agentic/nebula`. Other
layouts and packaged launchers can configure the boundary explicitly:

```bash
NEBULA_BIN=/path/to/nebula \
NEBULA_WORKSPACE=/path/to/workspace \
NEBULA_RUNTIME_ORIGIN=http://127.0.0.1:7777 \
bun run dev
```

- `NEBULA_BIN` selects the executable or Tauri sidecar.
- `NEBULA_WORKSPACE` becomes the runtime process working directory.
- `NEBULA_RUNTIME_ORIGIN` selects the health-check and proxy target.

The native launcher passes the workspace explicitly as `--workspace` and
stores all persistent runtime configuration and data under the adjacent
`workspace/.nebula` directory through `--nebula-dir`. This remains a local,
no-login launch path; neither option contains organization behavior.

This launcher belongs to the native/development host, not browser JavaScript.
A normal browser cannot start an operating-system process. A future Tauri app
will use the same health-check/start/own lifecycle around its bundled sidecar.

`/` opens the local Nebula workspace directly. The standalone application
intentionally contains no organization dashboard, authentication, billing,
operator lifecycle, or commercial landing routes. Those belong to
`nebula-cloud`.

## Runtime UI boundary

The package exports `RuntimeWorkspace`, the shared visual interface for one
Nebula runtime. It owns sessions, chat, agents, capabilities, models, security
modes, and tool output. Cloud-specific navigation and data stay outside this
package.

`@nebula/runtime-ui` is versioned independently and may be installed directly
from a pinned Git commit until a registry release pipeline is introduced. Its
public imports are limited to the package exports; internal source resolution
uses package-scoped `#nebula/*` imports so consumers do not need repository
aliases or a sibling checkout.

The current supported composition is exactly one mounted `RuntimeWorkspace` per
browser application. Runtime API helpers use one configured transport for that
workspace. Mounting several live operators side by side is explicitly deferred
future work; before enabling it, transport ownership must move from the current
module-level configuration into an instance-scoped React context. This does not
limit the number of organization members or operators managed by the Cloud
control plane—only simultaneous interactive workspace mounts in one page.

The standalone build connects to `/api`, which Vite proxies to the local
`nebula --serve` process at `127.0.0.1:7777` during development.

## Shader background

The workspace uses the Classic shader with the Graphite palette. Browsers
without accelerated WebGL receive a static Veil fallback.

## Checks

```bash
bun test
bun run build
```
