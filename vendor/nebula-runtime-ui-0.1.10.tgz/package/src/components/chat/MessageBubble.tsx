import { cn } from '#nebula/lib/utils'
import { type ChatMessage, type ContentBlock } from '#nebula/hooks/useChat'
import { ToolCallCard } from '#nebula/components/chat/ToolCallCard'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '#nebula/components/ui/tooltip'
import { Loader2, Copy, Check, Activity, ThumbsUp, ThumbsDown } from 'lucide-react'
import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'

interface MessageBubbleProps {
  message: ChatMessage
  isLatestAssistant?: boolean
}

export function MessageBubble({ message, isLatestAssistant = false }: MessageBubbleProps) {
  if (message.role === 'event') return <EventBubble message={message} />
  const isUser = message.role === 'user'
  const copyContent = message.blocks
    .filter((block): block is Extract<ContentBlock, { type: 'text' }> => block.type === 'text')
    .map(block => block.content)
    .join('\n\n')

  return (
    <div className={cn('flex gap-3 w-full', isUser ? 'justify-end' : 'justify-start')}>
      <div className={cn(
        'group/message relative flex flex-col gap-2',
        copyContent && 'pb-7 -mb-7',
        isUser ? 'items-end max-w-[82%]' : 'items-start flex-1 min-w-0',
      )}>
        {isUser ? (
          // User: single plain-text bubble
          <div className="rounded-xl bg-white/[0.08] px-3 py-1 text-sm leading-7 text-white/90">
            <span className="whitespace-pre-wrap break-words">
              {message.blocks.find(b => b.type === 'text')?.type === 'text'
                ? (message.blocks.find(b => b.type === 'text') as { type: 'text'; content: string }).content
                : ''}
            </span>
          </div>
        ) : (
          // Assistant: render blocks in order
          <div className="flex w-full flex-col gap-2 text-sm leading-7 text-white/80">
            <AnimatePresence initial={false}>
              {message.blocks.map((block, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.25, ease: 'easeOut' }}
                >
                  <Block block={block} />
                </motion.div>
              ))}
            </AnimatePresence>
            {message.streaming && message.blocks.length === 0 && <BlinkCursor />}
          </div>
        )}
        {copyContent && (!isLatestAssistant || !message.streaming) && (
          <MessageActions
            content={copyContent}
            isUser={isUser}
            alwaysVisible={!isUser && isLatestAssistant}
            createdAtMs={message.createdAtMs}
          />
        )}
      </div>

    </div>
  )
}

function MessageActions({
  content,
  isUser,
  alwaysVisible,
  createdAtMs,
}: {
  content: string
  isUser: boolean
  alwaysVisible: boolean
  createdAtMs?: number
}) {
  const [feedback, setFeedback] = useState<'good' | 'bad' | null>(null)

  const toggleFeedback = (next: 'good' | 'bad') => {
    setFeedback(current => current === next ? null : next)
  }

  return (
    <TooltipProvider delayDuration={250} disableHoverableContent>
      <div
        className={cn(
          'absolute bottom-0 flex items-center gap-0.5',
          isUser ? 'right-0' : '-left-[5px]',
        )}
      >
        {isUser && <MessageTimestamp createdAtMs={createdAtMs} />}
        <div
          className={cn(
            'flex items-center gap-0.5 transition-opacity duration-150 ease-out',
            alwaysVisible
              ? 'message-actions-latest opacity-100'
              : 'opacity-0 group-hover/message:opacity-100',
          )}
        >
          <MessageCopyButton content={content} />
          {!isUser && (
            <>
              {/* TODO: Wire assistant feedback to the backend once feedback persistence is available. */}
              <FeedbackButton
                label="Good response"
                selected={feedback === 'good'}
                selectedColor="green"
                onClick={() => toggleFeedback('good')}
              >
                <ThumbsUp size={13} className="block shrink-0" />
              </FeedbackButton>
              <FeedbackButton
                label="Bad response"
                selected={feedback === 'bad'}
                selectedColor="red"
                onClick={() => toggleFeedback('bad')}
              >
                <ThumbsDown size={13} className="block shrink-0" />
              </FeedbackButton>
            </>
          )}
        </div>
        {!isUser && <MessageTimestamp createdAtMs={createdAtMs} />}
      </div>
    </TooltipProvider>
  )
}

function formatMessageTime(createdAtMs: number): string {
  return new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  })
    .format(new Date(createdAtMs))
    .replace(/\sAM$/, ' a.m.')
    .replace(/\sPM$/, ' p.m.')
}

function MessageTimestamp({ createdAtMs }: { createdAtMs?: number }) {
  if (!createdAtMs) return null
  const label = formatMessageTime(createdAtMs)
  return (
    <time
      dateTime={new Date(createdAtMs).toISOString()}
      className="ml-1 mr-1 whitespace-nowrap text-[13px] leading-none text-white/30 opacity-0 transition-opacity duration-150 ease-out group-hover/message:opacity-100"
    >
      {label}
    </time>
  )
}

function MessageCopyButton({ content }: { content: string }) {
  const [copied, setCopied] = useState(false)

  const copy = async () => {
    await navigator.clipboard.writeText(content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          onClick={() => void copy()}
          aria-label={copied ? 'Copied' : 'Copy message'}
          className="flex h-[23px] w-[23px] items-center justify-center rounded-lg leading-none text-white/35 transition-colors duration-150 hover:bg-white/[0.06] hover:text-white/70 focus-visible:bg-white/[0.06] focus-visible:text-white/70 focus-visible:outline-none"
        >
          {copied
            ? <Check size={13} className="block shrink-0 text-green-400/70" />
            : <Copy size={13} className="block shrink-0" />
          }
        </button>
      </TooltipTrigger>
      <TooltipContent side="top">{copied ? 'Copied' : 'Copy message'}</TooltipContent>
    </Tooltip>
  )
}

function FeedbackButton({
  label,
  selected,
  selectedColor,
  onClick,
  children,
}: {
  label: string
  selected: boolean
  selectedColor: 'green' | 'red'
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          aria-label={label}
          aria-pressed={selected}
          onClick={onClick}
          className={cn(
            'flex h-[23px] w-[23px] items-center justify-center rounded-lg leading-none transition-colors duration-150 focus-visible:outline-none',
            selected
              ? selectedColor === 'green'
                ? 'text-green-500 hover:bg-green-500/10 focus-visible:bg-green-500/10'
                : 'text-red-500 hover:bg-red-500/10 focus-visible:bg-red-500/10'
              : 'text-white/35 hover:bg-white/[0.06] hover:text-white/70 focus-visible:bg-white/[0.06] focus-visible:text-white/70',
          )}
        >
          {children}
        </button>
      </TooltipTrigger>
      <TooltipContent side="top">{label}</TooltipContent>
    </Tooltip>
  )
}

// ── Event bubble (hook-triggered turns) ──────────────────────────────────────

function EventBubble({ message }: { message: ChatMessage }) {
  return (
    <div className="flex flex-col gap-3 w-full">
      <div className="flex items-center gap-2">
        <div className="flex-1 h-px bg-white/[0.06]" />
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/[0.04]">
          <Activity size={10} className="text-white/35" />
          <span className="text-[11px] font-medium text-white/45">{message.hook}</span>
          {message.trigger && (
            <span className="text-[10px] font-mono text-white/25">· {message.trigger}</span>
          )}
          {message.streaming && <Loader2 size={9} className="text-white/30 animate-spin" />}
        </div>
        <div className="flex-1 h-px bg-white/[0.06]" />
      </div>

      {(message.blocks.length > 0 || message.streaming) && (
        <div className="pl-4 border-l border-white/[0.06] flex flex-col gap-2 text-sm leading-7 text-white/80">
          <AnimatePresence initial={false}>
            {message.blocks.map((block, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
              >
                <Block block={block} />
                </motion.div>
              ))}
            </AnimatePresence>
            {message.streaming && message.blocks.length === 0 && <BlinkCursor />}
            {message.stopped && (
              <span className="text-[11px] text-white/35 italic">Stopped — partial response saved</span>
            )}
          </div>
      )}
    </div>
  )
}

// ── Block dispatcher ──────────────────────────────────────────────────────────

function Block({ block }: { block: ContentBlock }) {
  switch (block.type) {
    case 'text':     return <TextBlock content={block.content.trim()} />
    case 'thinking': return <ThinkingBlock content={block.content.trim()} />
    case 'tool_call': return <ToolCallCard toolCall={block} />
  }
}

// ── Text block ────────────────────────────────────────────────────────────────

const mdComponents: React.ComponentProps<typeof ReactMarkdown>['components'] = {
  p:      ({ children }) => <p className="mb-3 last:mb-0">{children}</p>,
  strong: ({ children }) => <strong className="font-semibold text-white/95">{children}</strong>,
  em:     ({ children }) => <em className="italic text-white/80">{children}</em>,
  h1:     ({ children }) => <h1 className="text-xl font-bold text-white/95 mt-5 mb-2">{children}</h1>,
  h2:     ({ children }) => <h2 className="text-lg font-semibold text-white/95 mt-4 mb-2">{children}</h2>,
  h3:     ({ children }) => <h3 className="text-base font-semibold text-white/90 mt-3 mb-1.5">{children}</h3>,
  ul:     ({ children }) => <ul className="list-disc list-outside pl-5 mb-3 space-y-1">{children}</ul>,
  ol:     ({ children }) => <ol className="list-decimal list-outside pl-5 mb-3 space-y-1">{children}</ol>,
  li:     ({ children }) => <li className="text-white/80">{children}</li>,
  blockquote: ({ children }) => (
    <blockquote className="border-l-2 border-white/20 pl-4 my-3 text-white/60 italic">{children}</blockquote>
  ),
  code: ({ children, className }) => {
    const match = /language-(\w+)/.exec(className ?? '')
    if (match) {
      return <CodeBlock language={match[1]} code={String(children).replace(/\n$/, '')} />
    }
    return (
      <code className="bg-white/[0.08] rounded px-1.5 py-0.5 text-[12px] font-mono text-white/85">
        {children}
      </code>
    )
  },
  pre: ({ children }) => <>{children}</>,
  hr:  () => <hr className="border-white/[0.08] my-4" />,
  a:   ({ href, children }) => (
    <a href={href} target="_blank" rel="noreferrer" className="text-white/75 underline underline-offset-2 hover:text-white/95 transition-colors">
      {children}
    </a>
  ),
  table: ({ children }) => (
    <div className="my-3 overflow-x-auto rounded-xl border border-white/[0.08] bg-white/[0.015]">
      <table className="w-full border-separate border-spacing-0 text-[13px] [&_tbody_tr:last-child_td]:border-b-0">{children}</table>
    </div>
  ),
  th: ({ children }) => (
    <th className="border-b border-r border-white/[0.08] bg-white/[0.05] px-3 py-2 text-left font-semibold text-white/85 last:border-r-0">{children}</th>
  ),
  td: ({ children }) => (
    <td className="border-b border-r border-white/[0.08] px-3 py-2 text-white/70 last:border-r-0">{children}</td>
  ),
}

function TextBlock({ content }: { content: string }) {
  return (
    <ReactMarkdown remarkPlugins={[remarkGfm]} components={mdComponents}>
      {content}
    </ReactMarkdown>
  )
}

// ── Thinking block ────────────────────────────────────────────────────────────

function ThinkingBlock({ content }: { content: string }) {
  // Keep live reasoning visible as chunks arrive. It can still be collapsed,
  // but hiding it by default made a healthy stream look like an empty block.
  const [open, setOpen] = useState(true)
  const { header, details } = splitThinkingContent(content)
  return (
    <div>
      <button
        onClick={() => setOpen(o => !o)}
        aria-expanded={open}
        className="block py-0.5 text-left text-[12px] text-white/45 transition-colors hover:text-white/65 select-none"
      >
        {header}
      </button>
      <div
        className="grid transition-[grid-template-rows] duration-200 ease-in-out"
        style={{ gridTemplateRows: open && details ? '1fr' : '0fr' }}
      >
        <div className="overflow-hidden">
          <p className="mt-2 text-sm text-white/40 italic whitespace-pre-wrap leading-7">
            {details}
          </p>
        </div>
      </div>
    </div>
  )
}

function splitThinkingContent(content: string): { header: string; details: string } {
  const normalized = content.trimStart()
  if (normalized.startsWith('**')) {
    const closing = normalized.indexOf('**', 2)
    if (closing < 0) {
      return { header: normalized.slice(2).trim() || 'Thinking', details: '' }
    }
    return {
      header: normalized.slice(2, closing).trim() || 'Thinking',
      details: normalized.slice(closing + 2).trim(),
    }
  }

  const [firstLine = '', ...rest] = normalized.split(/\r?\n/)
  return {
    header: firstLine.trim() || 'Thinking',
    details: rest.join('\n').trim(),
  }
}

// ── Tool call block ───────────────────────────────────────────────────────────


// Code block

function CodeBlock({ language, code }: { language: string; code: string }) {
  const [copied, setCopied] = useState(false)

  const copy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="my-3 overflow-hidden rounded-xl bg-black/10">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-1 bg-white/[0.04] border-b border-white/[0.06]">
        <span className="text-[11px] leading-6 font-mono text-white/40 select-none">{language}</span>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 text-[11px] text-white/40 hover:text-white/70 transition-colors duration-150"
        >
          {copied
            ? <><Check size={11} className="text-green-400/70" /><span className="text-green-400/70">Copied</span></>
            : <><Copy size={11} /><span>Copy</span></>
          }
        </button>
      </div>
      {/* Code */}
      <SyntaxHighlighter
        language={language}
        style={oneDark}
        customStyle={{
          margin: 0,
          padding: '0.5rem 0.75rem',
          background: 'rgba(255,255,255,0.02)',
          fontSize: '13px',
          lineHeight: '1.25rem',
        }}
        codeTagProps={{ style: { fontFamily: 'inherit' } }}
      >
        {code}
      </SyntaxHighlighter>
    </div>
  )
}

// ── Utilities ─────────────────────────────────────────────────────────────────

function BlinkCursor() {
  return (
    <span
      className="inline-block w-[2px] h-[14px] bg-white/40 ml-0.5 align-middle"
      style={{ animation: 'blink 1s step-end infinite' }}
    />
  )
}
