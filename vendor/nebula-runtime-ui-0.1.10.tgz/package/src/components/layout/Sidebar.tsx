import { useEffect, useMemo, useRef, useState, type KeyboardEvent, type PointerEvent as ReactPointerEvent } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import {
  Blocks, Bot, Search, SquarePen,
  Folder, FolderOpen, PanelLeftClose, PanelLeftOpen, Trash2,
} from 'lucide-react'
import { cn } from '#nebula/lib/utils'
import { NebulaMark } from '#nebula/components/ui/NebulaMark'
import { ScrollArea } from '#nebula/components/ui/scroll-area'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '#nebula/components/ui/tooltip'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { Button, IconButton } from '#nebula/components/ui/button'
import { type ChatSession } from '#nebula/lib/api'
import { type RuntimeIdentityMenuItem, type RuntimeNavigationItem } from '#nebula/components/workspace/WorkspaceApp'

interface Props {
  chats: ChatSession[]
  activeChat: string | null
  onSelect: (name: string) => void
  onNew: () => void
  onNewInProject: (path: string) => void
  onDelete: (name: string) => Promise<void>
  onDeleteProject: (names: string[]) => Promise<void>
  onToggleHooks: (name: string, paused: boolean) => Promise<void>
  activeView: 'sessions' | 'agents' | 'connections' | null
  onAgents: () => void
  onConnections: () => void
  brandLabel: string
  identityLabel: string
  identityInitial: string
  identityMenuItems?: RuntimeIdentityMenuItem[]
  onBrandSelect?: () => void
  externalNavigation: RuntimeNavigationItem[]
  initialDeleteChat?: string | null
}

interface ProjectGroup {
  key: string
  label: string
  path: string
  chats: ChatSession[]
}

const SIDEBAR_MIN_WIDTH = 240
const SIDEBAR_MAX_WIDTH = SIDEBAR_MIN_WIDTH * 2.5
const WORKSPACE_MIN_WIDTH = 320
const SIDEBAR_WIDTH_STORAGE_KEY = 'nebula.sidebar.width'

function availableSidebarMaxWidth(): number {
  if (typeof window === 'undefined') return SIDEBAR_MAX_WIDTH
  return Math.max(
    SIDEBAR_MIN_WIDTH,
    Math.min(SIDEBAR_MAX_WIDTH, window.innerWidth - WORKSPACE_MIN_WIDTH),
  )
}

function clampSidebarWidth(width: number): number {
  return Math.min(Math.max(width, SIDEBAR_MIN_WIDTH), availableSidebarMaxWidth())
}

function normalizePath(path?: string): string {
  return (path ?? '').replace(/\\/g, '/').replace(/\/+$/, '')
}

function projectGroups(chats: ChatSession[]): ProjectGroup[] {
  const groups = new Map<string, ProjectGroup>()
  for (const chat of chats) {
    const cwd = normalizePath(chat.cwd)
    const root = normalizePath(chat.workspace_root)
    const isWorkspace = !cwd || !root || cwd === root
    const key = isWorkspace ? '__workspace__' : cwd
    let group = groups.get(key)
    if (!group) {
      group = {
        key,
        label: isWorkspace
          ? 'Workspace'
          : (cwd.split('/').filter(Boolean).at(-1) ?? 'Workspace'),
        path: isWorkspace ? (root || 'Workspace') : cwd,
        chats: [],
      }
      groups.set(key, group)
    }
    group.chats.push(chat)
  }
  return [...groups.values()]
}

export function Sidebar({ chats, activeChat, onSelect, onNew, onNewInProject, onDelete, onDeleteProject, onToggleHooks, activeView, onAgents, onConnections, brandLabel, identityLabel, identityInitial, identityMenuItems = [], onBrandSelect, externalNavigation, initialDeleteChat = null }: Props) {
  const [collapsed, setCollapsed] = useState(false)
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    if (typeof window === 'undefined') return SIDEBAR_MIN_WIDTH
    const storedWidth = Number.parseFloat(window.localStorage.getItem(SIDEBAR_WIDTH_STORAGE_KEY) ?? '')
    return Number.isFinite(storedWidth) ? clampSidebarWidth(storedWidth) : SIDEBAR_MIN_WIDTH
  })
  const [isResizing, setIsResizing] = useState(false)
  const [hovered, setHovered]     = useState(false)
  const [showExpandHint, setShowExpandHint] = useState(false)
  const [closedProjects, setClosedProjects] = useState<Set<string>>(() => new Set())
  const [confirmProject, setConfirmProject] = useState<string | null>(null)
  const [identityMenuOpen, setIdentityMenuOpen] = useState(false)
  const reduceMotion              = useReducedMotion()
  const groupedChats = useMemo(() => projectGroups(chats), [chats])
  const sidebarRef = useRef<HTMLElement>(null)
  const resizeStart = useRef({ pointerX: 0, width: SIDEBAR_MIN_WIDTH })
  const liveResizeWidth = useRef(sidebarWidth)

  const updateSidebarWidth = (width: number) => {
    setSidebarWidth(clampSidebarWidth(width))
  }

  const finishResizing = () => {
    setSidebarWidth(liveResizeWidth.current)
    setIsResizing(false)
  }

  const stopResizing = (event?: ReactPointerEvent<HTMLDivElement>) => {
    if (event?.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId)
    }
    finishResizing()
  }

  const handleResizeStart = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (collapsed || event.button !== 0) return
    event.preventDefault()
    resizeStart.current = { pointerX: event.clientX, width: sidebarWidth }
    liveResizeWidth.current = sidebarWidth
    event.currentTarget.setPointerCapture(event.pointerId)
    setIsResizing(true)
  }

  const handleResizeMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (!isResizing) return
    const nextWidth = clampSidebarWidth(
      resizeStart.current.width + event.clientX - resizeStart.current.pointerX,
    )
    liveResizeWidth.current = nextWidth
    sidebarRef.current?.style.setProperty('width', `${nextWidth}px`)
  }

  const handleResizeKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (collapsed) return

    const step = event.shiftKey ? 48 : 16
    if (event.key === 'ArrowLeft') updateSidebarWidth(sidebarWidth - step)
    else if (event.key === 'ArrowRight') updateSidebarWidth(sidebarWidth + step)
    else if (event.key === 'Home') updateSidebarWidth(SIDEBAR_MIN_WIDTH)
    else if (event.key === 'End') updateSidebarWidth(availableSidebarMaxWidth())
    else return

    event.preventDefault()
  }

  useEffect(() => {
    if (!showExpandHint) return

    const timeout = window.setTimeout(() => setShowExpandHint(false), 3000)
    return () => window.clearTimeout(timeout)
  }, [showExpandHint])

  useEffect(() => {
    window.localStorage.setItem(SIDEBAR_WIDTH_STORAGE_KEY, String(sidebarWidth))
  }, [sidebarWidth])

  useEffect(() => {
    const handleWindowResize = () => setSidebarWidth(current => clampSidebarWidth(current))
    window.addEventListener('resize', handleWindowResize)
    return () => window.removeEventListener('resize', handleWindowResize)
  }, [])

  useEffect(() => {
    if (!isResizing) return

    const previousCursor = document.body.style.cursor
    const previousUserSelect = document.body.style.userSelect
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'

    return () => {
      document.body.style.cursor = previousCursor
      document.body.style.userSelect = previousUserSelect
    }
  }, [isResizing])

  return (
    <TooltipProvider delayDuration={400}>
      <motion.aside
        ref={sidebarRef}
        initial={reduceMotion ? false : { opacity: 0, x: -14 }}
        animate={{ opacity: 1, x: 0 }}
        transition={reduceMotion
          ? { duration: 0 }
          : { duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className="relative flex-shrink-0 flex flex-col h-full overflow-hidden"
        style={{
          width: collapsed ? 56 : sidebarWidth,
          transition: isResizing ? 'none' : 'width 260ms cubic-bezier(0.4,0,0.2,1)',
          background: 'var(--color-surface-sidebar)',
          borderRight: '1px solid var(--color-border-subtle)',
          boxShadow: 'var(--shadow-sidebar)',
        }}
      >

        {!collapsed && (
          <div
            role="separator"
            aria-label="Resize sidebar"
            aria-orientation="vertical"
            aria-valuemin={SIDEBAR_MIN_WIDTH}
            aria-valuemax={availableSidebarMaxWidth()}
            aria-valuenow={Math.round(sidebarWidth)}
            tabIndex={0}
            className="sidebar-resize-handle"
            data-resizing={isResizing ? 'true' : 'false'}
            onPointerDown={handleResizeStart}
            onPointerMove={handleResizeMove}
            onPointerUp={stopResizing}
            onPointerCancel={stopResizing}
            onLostPointerCapture={finishResizing}
            onDoubleClick={() => updateSidebarWidth(SIDEBAR_MIN_WIDTH)}
            onKeyDown={handleResizeKeyDown}
          />
        )}

        {/* ── Header — fixed h-16 so nav buttons never shift ── */}
        {collapsed ? (
          <div className="px-2 h-16 flex items-center flex-shrink-0">
            <IconButton
              label="Expand sidebar"
              variant="ghost"
              onClick={() => {
                setShowExpandHint(false)
                setCollapsed(false)
              }}
              className="relative ml-0.5 h-9 w-9 text-white/55"
            >
              <AnimatePresence initial={false}>
                {showExpandHint || hovered ? (
                  <motion.span
                    key="expand"
                    className="absolute inset-0 flex items-center justify-center"
                    initial={reduceMotion ? false : { opacity: 0, scale: 0.82 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.82 }}
                    transition={reduceMotion ? { duration: 0 } : { duration: 0.18, ease: 'easeOut' }}
                  >
                    <PanelLeftOpen size={14} />
                  </motion.span>
                ) : (
                  <motion.span
                    key="nebula"
                    className="absolute inset-0 flex items-center justify-center"
                    initial={reduceMotion ? false : { opacity: 0, scale: 0.82 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.82 }}
                    transition={reduceMotion ? { duration: 0 } : { duration: 0.18, ease: 'easeOut' }}
                  >
                    <NebulaMark />
                  </motion.span>
                )}
              </AnimatePresence>
            </IconButton>
          </div>
        ) : (
          <div className="flex items-center justify-between h-16 pl-4 pr-3 flex-shrink-0">
            <Button
              variant="ghost"
              onClick={onBrandSelect}
              disabled={!onBrandSelect}
              className="h-auto min-w-0 justify-start gap-2 overflow-hidden p-0 text-left disabled:pointer-events-none disabled:opacity-100"
              aria-label={`${brandLabel} workspace`}
            >
              <NebulaMark />
              <span className="nebula-wordmark text-[14px] font-semibold tracking-tight select-none whitespace-nowrap">
                {brandLabel}
              </span>
            </Button>
            <IconButton
              label="Collapse sidebar"
              variant="ghost"
              onClick={() => {
                setShowExpandHint(true)
                setCollapsed(true)
              }}
              className="h-8 w-8 text-white/35"
            >
              <PanelLeftClose size={14} />
            </IconButton>
          </div>
        )}

        {/* ── Nav buttons ── */}
        <div className="flex flex-col gap-0.5 px-2 pb-3 flex-shrink-0">
          <NavBtn icon={<SquarePen size={15} />}         label="New Session" collapsed={collapsed} active={activeView === 'sessions' && activeChat === null} onClick={onNew} />
          <NavBtn icon={<Bot size={15} />}              label="Agents"      collapsed={collapsed} active={activeView === 'agents'} onClick={onAgents} />
          <NavBtn icon={<Blocks size={15} />}            label="Capabilities" collapsed={collapsed} active={activeView === 'connections'} onClick={onConnections} />
          <NavBtn icon={<Search size={15} />}           label="Search"      collapsed={collapsed} active={false} onClick={() => {}} />
          {externalNavigation.map(item => (
            <NavBtn
              key={item.id}
              icon={item.icon}
              label={item.label}
              collapsed={collapsed}
              active={item.active ?? false}
              onClick={item.onSelect}
            />
          ))}
        </div>

        <div className="mx-3 mb-2 flex-shrink-0" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }} />

        {/* ── Sessions list (expanded only) ── */}
        {!collapsed ? (
          <ScrollArea className="flex-1 px-2 pb-2">
              <p className="sticky top-0 z-10 bg-[var(--color-surface-sidebar)] px-3 py-1.5 text-[10px] font-semibold text-white/35 uppercase tracking-widest select-none">
              Sessions
            </p>

            <div className="w-0 min-w-full space-y-1">
              {groupedChats.map((group, groupIndex) => {
                const closed = closedProjects.has(group.key)
                return (
                  <motion.section
                    key={group.key}
                    initial={reduceMotion ? false : { opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={reduceMotion ? { duration: 0 } : { duration: 0.22, delay: groupIndex * 0.025 }}
                  >
                    <div className="group/project mb-0.5 flex h-9 w-full items-center rounded-xl transition-colors hover:bg-white/[0.04]">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            onClick={() => setClosedProjects(current => {
                              const next = new Set(current)
                              if (next.has(group.key)) next.delete(group.key)
                              else next.add(group.key)
                              return next
                            })}
                            aria-expanded={!closed}
                            className="h-full min-w-0 flex-1 justify-start gap-2 rounded-xl px-2.5 text-left text-[12px] text-white/70 hover:bg-transparent hover:text-white/90"
                          >
                            {closed
                              ? <Folder size={13} className="shrink-0 text-white/45" />
                              : <FolderOpen size={13} className="shrink-0 text-white/45" />}
                            <span className="truncate">{group.label}</span>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent side="top" align="start">{group.path}</TooltipContent>
                      </Tooltip>

                      <div className={cn(
                        'mr-2 flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover/project:opacity-100',
                        confirmProject === group.key && 'opacity-100',
                      )}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <IconButton
                              label={`New session in ${group.label}`}
                              variant="ghost"
                              size="compact"
                              onClick={event => {
                                event.stopPropagation()
                                onNewInProject(group.key === '__workspace__' ? '.' : group.path)
                              }}
                              className="h-5 w-5 p-0 text-white/35"
                            >
                              <SquarePen size={12} />
                            </IconButton>
                          </TooltipTrigger>
                          <TooltipContent>New session here</TooltipContent>
                        </Tooltip>

                        <Popover open={confirmProject === group.key} onOpenChange={open => setConfirmProject(open ? group.key : null)}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <PopoverTrigger asChild>
                                <IconButton
                                  label={`Delete sessions in ${group.label}`}
                                  variant="ghost"
                                  size="compact"
                                  onClick={event => { event.stopPropagation(); setConfirmProject(group.key) }}
                                  className={cn(
                                    'group/delete h-5 w-5 p-0 text-white/35 hover:bg-[var(--color-status-danger-surface-muted)] hover:text-[var(--color-status-danger)]',
                                    confirmProject === group.key && 'bg-[var(--color-status-danger-surface-muted)] text-[var(--color-status-danger)]',
                                  )}
                                >
                                  <Trash2 size={12} className="transition-colors group-hover/delete:text-red-400" />
                                </IconButton>
                              </PopoverTrigger>
                            </TooltipTrigger>
                            <TooltipContent>Delete project sessions</TooltipContent>
                          </Tooltip>
                          <PopoverContent side="right" align="center" sideOffset={8} className="w-44 min-w-0" onOpenAutoFocus={event => event.preventDefault()}>
                            <div className="space-y-3 px-1 py-0.5">
                              <div>
                                <p className="text-[12px] font-semibold text-white/90">Delete project sessions?</p>
                                <p className="mt-1 text-[11px] leading-relaxed text-white/45">
                                  Removes all {group.chats.length} chat {group.chats.length === 1 ? 'history' : 'histories'} in {group.label}.
                                  The folder and agent definitions are not affected.
                                </p>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  size="compact"
                                  onClick={event => { event.stopPropagation(); setConfirmProject(null) }}
                                  className="h-7 flex-1 pt-0.5 text-[11px]"
                                >
                                  Cancel
                                </Button>
                                <Button
                                  variant="danger"
                                  size="compact"
                                  onClick={event => {
                                    event.stopPropagation()
                                    setConfirmProject(null)
                                    void onDeleteProject(group.chats.map(chat => chat.name))
                                      .catch(() => setConfirmProject(group.key))
                                  }}
                                  className="h-7 flex-1 bg-[var(--color-status-danger-surface)] pt-0.5 text-[11px]"
                                >
                                  Delete
                                </Button>
                              </div>
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>

                    <AnimatePresence initial={false}>
                      {!closed && (
                        <motion.div
                          key="sessions"
                          initial={reduceMotion ? false : { height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={reduceMotion ? { duration: 0 } : { duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
                          className="overflow-hidden"
                        >
                          {group.chats.map((chat, index) => (
                            <motion.div
                              key={chat.name}
                              initial={reduceMotion ? false : { opacity: 0, y: -5 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={reduceMotion ? { duration: 0 } : { duration: 0.2, delay: index * 0.02 }}
                              style={{ overflow: 'hidden', marginBottom: 2 }}
                            >
                              <SessionItem
                                chat={chat}
                                grouped
                                isResizing={isResizing}
                                initialConfirmOpen={chat.name === initialDeleteChat}
                                active={chat.name === activeChat}
                                onSelect={() => onSelect(chat.name)}
                                onDelete={() => onDelete(chat.name)}
                                onToggleHooks={() => onToggleHooks(chat.name, !chat.hooks_paused)}
                              />
                            </motion.div>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.section>
                )
              })}
            </div>
          </ScrollArea>
        ) : (
          <div className="flex-1" />
        )}

        {/* ── Footer ── */}
        <div
          className="px-2 pt-2 pb-4 flex-shrink-0"
          style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}
        >
          {identityMenuItems.length > 0 ? <Popover open={identityMenuOpen} onOpenChange={setIdentityMenuOpen}>
            <Tooltip>
              <TooltipTrigger asChild>
                <PopoverTrigger asChild>
                  <Button variant="ghost" className={cn(
                    'min-w-0 gap-2.5 text-left',
                    collapsed
                      ? 'ml-0.5 h-9 w-9 p-0'
                      : 'h-auto w-full justify-start px-2 py-2',
                  )}>
                    <div className="flex h-6 w-6 min-w-[24px] flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500/70 to-indigo-600/70">
                      <span className="text-[10px] font-semibold text-white leading-none">{identityInitial.slice(0, 1).toUpperCase()}</span>
                    </div>
                    {!collapsed && (
                      <span className="min-w-0 flex-1 truncate text-[13px] text-white/65">{identityLabel}</span>
                    )}
                  </Button>
                </PopoverTrigger>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right">{identityLabel}</TooltipContent>}
            </Tooltip>
            <PopoverContent side={collapsed ? 'right' : 'top'} align="start" sideOffset={8} className="w-52 p-1.5">
              <div className="mb-1 border-b border-[var(--color-border-subtle)] px-2 py-2">
                <p className="truncate text-[12px] font-medium text-white/80">{identityLabel}</p>
              </div>
              {identityMenuItems.map(item => (
                  <Button
                    key={item.label}
                    variant="ghost"
                    size="compact"
                    onClick={() => {
                      setIdentityMenuOpen(false)
                      item.onSelect()
                    }}
                    disabled={item.disabled}
                    className={cn(
                      'h-8 w-full justify-start gap-2 px-2 text-left text-[12px] disabled:text-[var(--color-text-disabled)]',
                      item.tone === 'danger'
                        ? 'text-red-300/65 hover:bg-red-400/[0.08] hover:text-red-300'
                        : 'text-white/55 hover:bg-white/[0.06] hover:text-white/85',
                    )}
                  >
                    <span className="flex h-5 w-5 items-center justify-center">{item.icon}</span>
                    <span>{item.label}</span>
                  </Button>
              ))}
            </PopoverContent>
          </Popover> : (
            <Tooltip>
              <TooltipTrigger asChild>
                <div className={cn(
                  'flex min-w-0 items-center gap-2.5 rounded-xl transition-colors duration-150',
                  collapsed ? 'ml-0.5 h-9 w-9 justify-center' : 'w-full px-2 py-2',
                )}>
                  <div className="flex h-6 w-6 min-w-[24px] flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500/70 to-indigo-600/70">
                    <span className="text-[10px] font-semibold text-white leading-none">{identityInitial.slice(0, 1).toUpperCase()}</span>
                  </div>
                  {!collapsed && <span className="min-w-0 flex-1 truncate text-[13px] text-white/65">{identityLabel}</span>}
                </div>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right">{identityLabel}</TooltipContent>}
            </Tooltip>
          )}
        </div>

      </motion.aside>
    </TooltipProvider>
  )
}

// ── Nav button ────────────────────────────────────────────────────────────────

function NavBtn({
  icon, label, collapsed, active, onClick,
}: {
  icon: React.ReactNode
  label: string
  collapsed: boolean
  onClick: () => void
  active: boolean
}) {
  const btn = (
    <Button
      variant="ghost"
      onClick={onClick}
      className={cn(
        'ml-0.5 h-9 justify-start gap-0 px-0',
        collapsed ? 'w-9' : 'w-[calc(100%-0.125rem)]',
        active
          ? 'bg-white/[0.08] text-white/90'
          : 'text-white/55 hover:text-white/90 hover:bg-white/[0.06]',
      )}
    >
      <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center">{icon}</span>
      <span
        className="overflow-hidden whitespace-nowrap transition-all duration-[260ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
        style={{
          maxWidth: collapsed ? 0 : 160,
          opacity: collapsed ? 0 : 1,
        }}
      >
        <span className="relative -top-[2px] text-[13px] font-medium">{label}</span>
      </span>
    </Button>
  )

  if (!collapsed) return btn

  return (
    <Tooltip>
      <TooltipTrigger asChild>{btn}</TooltipTrigger>
      <TooltipContent side="right">{label}</TooltipContent>
    </Tooltip>
  )
}

// ── Session item ──────────────────────────────────────────────────────────────

function formatChatName(chatName: string): string {
  return chatName
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase())
}

function isGeneratedChatName(chatName: string): boolean {
  return /^chat-\d{13}-[a-f0-9]{8}$/i.test(chatName) ||
    /^\d{4}-\d{2}-\d{2}-\d{6}$/.test(chatName)
}

function treePrefix(chat: ChatSession): string {
  const depth = chat.depth ?? 0
  if (depth <= 0) return ''
  return `${'  '.repeat(Math.max(0, depth - 1))}${chat.last_child ? '└─ ' : '├─ '}`
}

function SessionName({ name, isSubagent, isResizing }: {
  name: string
  isSubagent: boolean
  isResizing: boolean
}) {
  const viewportRef = useRef<HTMLSpanElement>(null)
  const contentRef = useRef<HTMLSpanElement>(null)
  const [overflowing, setOverflowing] = useState(false)
  const formattedName = formatChatName(name)

  useEffect(() => {
    const viewport = viewportRef.current
    const content = contentRef.current
    if (!viewport || !content) return

    const updateOverflow = () => {
      const nextOverflowing = content.scrollWidth > viewport.clientWidth + 1
      const loopDistance = content.scrollWidth + 20
      setOverflowing(nextOverflowing)
      viewport.style.setProperty('--session-loop-offset', `${-loopDistance}px`)
      viewport.style.setProperty(
        '--session-scroll-duration',
        `${Math.max(4.2, loopDistance / 28).toFixed(2)}s`,
      )
    }

    updateOverflow()
    const observer = new ResizeObserver(updateOverflow)
    observer.observe(viewport)
    observer.observe(content)
    return () => observer.disconnect()
  }, [name])

  return (
    <span
      ref={viewportRef}
      className={cn(
        'session-name-viewport min-w-0 flex-1 overflow-hidden text-[13px] font-medium',
        isSubagent && 'text-white/45',
      )}
      data-overflow={!isResizing && overflowing ? 'true' : 'false'}
    >
      <span className="session-name-track">
        <span ref={contentRef} className="session-name-copy">
          {formattedName}
        </span>
        {overflowing && !isResizing && (
          <span aria-hidden="true" className="session-name-copy">
            {formattedName}
          </span>
        )}
      </span>
    </span>
  )
}

function needsInput(chat: ChatSession): boolean {
  return chat.run?.status === 'needs_input' ||
    Boolean(chat.run?.input_prompt) ||
    Boolean(chat.run?.input_options?.length)
}

function RunIndicator({ chat, onSelect }: { chat: ChatSession; onSelect: () => void }) {
  if (!chat.run) return null

  const waitingForInput = needsInput(chat)
  const label = waitingForInput
    ? 'Needs input'
    : chat.run.status === 'cancelling' ? 'Stopping' : 'Thinking'

  return (
    <span className="relative mr-2 h-5 w-[13px] shrink-0">
      <Tooltip>
        <TooltipTrigger asChild>
          <IconButton
            label={label}
            variant="ghost"
            size="compact"
            className={cn(
              'absolute left-1/2 top-0 h-5 w-5 -translate-x-1/2 p-0 text-[10px] leading-none hover:bg-amber-400/10 hover:text-amber-200',
              waitingForInput ? 'text-amber-300/90' : 'text-sky-300/85',
            )}
            onClick={e => {
              e.stopPropagation()
              onSelect()
            }}
          >
            {waitingForInput
              ? <span aria-hidden="true">✵</span>
              : <span className="run-spinner" aria-hidden="true" />}
          </IconButton>
        </TooltipTrigger>
        <TooltipContent>{label}</TooltipContent>
      </Tooltip>
    </span>
  )
}

function HookIndicator({ chat, onToggleHooks }: {
  chat: ChatSession
  onToggleHooks: () => Promise<void>
}) {
  const label = chat.hooks_paused ? 'Enable hooks' : 'Stop hooks'

  return (
    <span className="relative mr-2 h-5 w-[13px] shrink-0">
      <Tooltip>
        <TooltipTrigger asChild>
          <IconButton
            label={label}
            variant="ghost"
            size="compact"
            onClick={event => {
              event.stopPropagation()
              void onToggleHooks()
            }}
            className="absolute left-1/2 top-0 h-5 w-5 -translate-x-1/2 p-0 text-[var(--color-status-info)] hover:bg-[var(--color-status-info-surface)] hover:text-[var(--color-status-info-strong)]"
          >
            {chat.hooks_paused
              ? <span className="hook-paused" aria-hidden="true" />
              : <span className="hook-listening" aria-hidden="true" />}
          </IconButton>
        </TooltipTrigger>
        <TooltipContent>{label}</TooltipContent>
      </Tooltip>
    </span>
  )
}

function SessionItem({
  chat, active, grouped = false, isResizing, initialConfirmOpen, onSelect, onDelete, onToggleHooks,
}: {
  chat: ChatSession
  active: boolean
  grouped?: boolean
  isResizing: boolean
  initialConfirmOpen: boolean
  onSelect: () => void
  onDelete: () => Promise<void>
  onToggleHooks: () => Promise<void>
}) {
  const [confirmOpen, setConfirmOpen] = useState(initialConfirmOpen)
  const label = chat.agent ?? 'Default'
  const isSubagent = chat.kind === 'subagent'
  const displayName = isGeneratedChatName(chat.name)
    ? (chat.display_name ?? 'New chat')
    : (chat.display_name ?? chat.name)

  return (
    <div
      onClick={onSelect}
      className={cn(
        'session-row group flex items-center w-full h-9 rounded-xl transition-colors duration-150 cursor-pointer',
        grouped ? 'pl-2.5 pr-2' : 'px-3',
        active
          ? 'bg-white/[0.06] text-white'
          : 'text-white/55 hover:text-white/90 hover:bg-white/[0.06]',
      )}
    >
      <span className="flex min-w-0 flex-1 items-center text-left">
        {chat.run
          ? <RunIndicator chat={chat} onSelect={onSelect} />
          : chat.has_hooks
            ? <HookIndicator chat={chat} onToggleHooks={onToggleHooks} />
            : <span aria-hidden="true" className="mr-2 h-5 w-[13px] shrink-0" />}
        {(chat.depth ?? 0) > 0 && (
          <span className="text-[12px] text-white/25 flex-shrink-0 whitespace-pre">
            {treePrefix(chat)}
          </span>
        )}
        <SessionName name={displayName} isSubagent={isSubagent} isResizing={isResizing} />
      </span>
      <span className={cn(
        'text-[11px] text-white/30 ml-2 flex-shrink-0 group-hover:hidden',
        confirmOpen && 'hidden',
      )}>
        {formatChatName(label)}
      </span>
      <Popover open={confirmOpen} onOpenChange={setConfirmOpen}>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <IconButton
                label="Delete session"
                variant="ghost"
                size="compact"
                onClick={e => { e.stopPropagation(); setConfirmOpen(true) }}
                className={cn(
                  'group/delete ml-2 hidden h-5 w-5 p-0 text-white/35 opacity-0 transition-opacity hover:bg-[var(--color-status-danger-surface-muted)] hover:text-[var(--color-status-danger)] group-hover:flex group-hover:opacity-100',
                  confirmOpen && 'flex opacity-100',
                )}
              >
                <Trash2 size={12} className="transition-colors group-hover/delete:text-red-400" />
              </IconButton>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent>Delete session</TooltipContent>
        </Tooltip>
        <PopoverContent side="right" align="center" sideOffset={8} className="w-44 min-w-0" onOpenAutoFocus={e => e.preventDefault()}>
          <div className="space-y-3 px-1 py-0.5">
            <div>
              <p className="text-[12px] font-semibold text-white/90">Delete session?</p>
              <p className="text-[11px] text-white/45 mt-1 leading-relaxed">
                Removes the chat history and its agent config link.
                The agent definition itself is not affected.
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="compact"
                onClick={e => { e.stopPropagation(); setConfirmOpen(false) }}
                className="h-7 flex-1 pt-0.5 text-[11px]"
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                size="compact"
                onClick={e => {
                  e.stopPropagation()
                  setConfirmOpen(false)
                  void onDelete().catch(() => setConfirmOpen(true))
                }}
                className="h-7 flex-1 bg-[var(--color-status-danger-surface)] pt-0.5 text-[11px]"
              >
                Delete
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
