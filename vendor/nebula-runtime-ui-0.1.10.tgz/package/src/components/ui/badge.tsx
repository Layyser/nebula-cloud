import type { VariantProps } from 'class-variance-authority'
import { forwardRef, type HTMLAttributes } from 'react'
import { cn } from '#nebula/lib/utils'
import { badgeVariants, statusDotVariants } from './badge-variants'

export interface BadgeProps
  extends HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export const Badge = forwardRef<HTMLSpanElement, BadgeProps>(function Badge(
  { className, tone, size, ...props },
  ref,
) {
  return <span ref={ref} className={cn(badgeVariants({ tone, size }), className)} {...props} />
})

export interface StatusBadgeProps extends BadgeProps {
  showDot?: boolean
}

export const StatusBadge = forwardRef<HTMLSpanElement, StatusBadgeProps>(function StatusBadge(
  { children, showDot = true, tone = 'neutral', ...props },
  ref,
) {
  return (
    <Badge ref={ref} tone={tone} {...props}>
      {showDot && <span aria-hidden="true" className={statusDotVariants({ tone })} />}
      {children}
    </Badge>
  )
})
