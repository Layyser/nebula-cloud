import { cva } from 'class-variance-authority'

export const tabsListVariants = cva(
  'inline-flex max-w-full items-center overflow-x-auto rounded-[var(--radius-surface)]',
  {
    variants: {
      variant: {
        glass: 'bg-[var(--color-surface-glass-subtle)] backdrop-blur-[var(--blur-subtle)]',
        panel: 'bg-[var(--color-surface-panel)]',
      },
      size: {
        compact: 'h-[var(--control-height-sm)]',
        default: 'h-[var(--control-height-md)]',
      },
    },
    defaultVariants: { variant: 'glass', size: 'default' },
  },
)

export const tabsTriggerVariants = cva(
  'inline-flex h-full min-w-[104px] shrink-0 cursor-pointer items-center justify-center gap-1.5 border-r border-[var(--color-border-subtle)] px-3 text-[12px] text-[var(--color-text-subtle)] outline-none transition-[color,background-color] duration-[var(--motion-duration-deliberate)] last:border-r-0 hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-secondary)] focus-visible:[outline:var(--focus-ring-width-strong)_solid_var(--focus-ring-color-strong)] focus-visible:-outline-offset-2 disabled:pointer-events-none disabled:opacity-40 data-[state=active]:bg-[var(--color-surface-selected)] data-[state=active]:text-[var(--color-text-primary)]',
)
