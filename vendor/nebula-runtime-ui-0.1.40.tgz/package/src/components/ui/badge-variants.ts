import { cva } from 'class-variance-authority'

export const badgeVariants = cva(
  'inline-flex w-fit shrink-0 items-center justify-center gap-1 whitespace-nowrap rounded-[var(--radius-pill)] font-medium leading-none',
  {
    variants: {
      tone: {
        neutral: 'bg-[var(--color-surface-selected)] text-[var(--color-text-muted)]',
        info: 'bg-[var(--color-status-info-surface)] text-[var(--color-status-info)]',
        success: 'bg-[var(--color-status-success-surface)] text-[var(--color-status-success)]',
        warning: 'bg-[var(--color-status-warning-surface)] text-[var(--color-status-warning)]',
        danger: 'bg-[var(--color-status-danger-surface-muted)] text-[var(--color-status-danger)]',
      },
      size: {
        compact: 'min-h-5 px-1.5 text-[10px]',
        default: 'min-h-6 px-2 text-[11px]',
      },
    },
    defaultVariants: { tone: 'neutral', size: 'compact' },
  },
)

export const statusDotVariants = cva('h-1.5 w-1.5 shrink-0 rounded-[var(--radius-pill)]', {
  variants: {
    tone: {
      neutral: 'bg-[var(--color-text-disabled)]',
      info: 'bg-[var(--color-status-info-strong)]',
      success: 'bg-[var(--color-status-success-strong)]',
      warning: 'bg-[var(--color-status-warning-strong)]',
      danger: 'bg-[var(--color-status-danger-strong)]',
    },
  },
  defaultVariants: { tone: 'neutral' },
})
