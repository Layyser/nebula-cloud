import { forwardRef, type HTMLAttributes, type ReactNode } from 'react'
import { cn } from '#nebula/lib/utils'
import { capabilityMetadata, formatMetadataCount, type CapabilityIconKind } from './capability-metadata'

export interface MetadataChipProps extends HTMLAttributes<HTMLSpanElement> {
  icon?: ReactNode
}

export const MetadataChip = forwardRef<HTMLSpanElement, MetadataChipProps>(function MetadataChip(
  { children, className, icon, ...props },
  ref,
) {
  return (
    <span
      ref={ref}
      className={cn(
        'inline-flex min-h-5 items-center gap-1 rounded-[var(--radius-control)] bg-[var(--legacy-white-06)] px-1.5 py-1 text-[10px] leading-none text-[var(--color-text-muted)]',
        className,
      )}
      {...props}
    >
      {icon}
      {children}
    </span>
  )
})

export interface CapabilityCountChipProps extends Omit<MetadataChipProps, 'children' | 'icon'> {
  count: number
  kind: CapabilityIconKind
}

export const CapabilityCountChip = forwardRef<HTMLSpanElement, CapabilityCountChipProps>(function CapabilityCountChip(
  { count, kind, ...props },
  ref,
) {
  const metadata = capabilityMetadata[kind]
  const Icon = metadata.icon
  return (
    <MetadataChip ref={ref} icon={<Icon aria-hidden="true" size={10} />} {...props}>
      {formatMetadataCount(count, metadata.singular, metadata.plural)}
    </MetadataChip>
  )
})
