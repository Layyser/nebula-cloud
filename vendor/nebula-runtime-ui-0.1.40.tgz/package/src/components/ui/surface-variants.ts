import { cva } from 'class-variance-authority'

export const surfaceVariants = cva(
  'relative text-[var(--color-text-secondary)]',
  {
    variants: {
      variant: {
        panel: 'bg-[var(--color-surface-panel)]',
        raised: 'bg-[var(--color-surface-raised)] shadow-[var(--shadow-surface-subtle)]',
        recessed: 'bg-[var(--color-surface-recessed)]',
        glass: 'bg-[var(--color-surface-glass)] shadow-[var(--shadow-surface-subtle)] backdrop-blur-[var(--blur-glass)]',
        'glass-subtle': 'bg-[var(--color-surface-glass-subtle)] backdrop-blur-[var(--blur-subtle)]',
      },
      density: {
        none: 'p-0',
        compact: 'p-3',
        default: 'p-4',
        comfortable: 'p-6',
      },
      radius: {
        control: 'rounded-[var(--radius-control)]',
        surface: 'rounded-[var(--radius-surface)]',
        large: 'rounded-[var(--radius-large)]',
      },
      interaction: {
        static: '',
        hover: 'transition-[background-color,box-shadow] duration-[var(--motion-duration-fast)] ease-[var(--motion-ease-standard)] hover:bg-[var(--color-surface-hover)]',
        selectable: 'cursor-pointer outline-none transition-[background-color,box-shadow] duration-[var(--motion-duration-fast)] ease-[var(--motion-ease-standard)] hover:bg-[var(--color-surface-hover)] focus-visible:[outline:var(--focus-ring-width-strong)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-2',
      },
      selected: {
        true: 'bg-[var(--color-surface-selected)]',
        false: '',
      },
    },
    defaultVariants: {
      variant: 'panel',
      density: 'default',
      radius: 'surface',
      interaction: 'static',
      selected: false,
    },
  },
)
