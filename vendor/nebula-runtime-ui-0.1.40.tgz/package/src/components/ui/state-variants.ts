import { cva } from 'class-variance-authority'

export const emptyStateVariants = cva(
  'flex w-full flex-col items-center justify-center text-center',
  {
    variants: {
      appearance: {
        glass: 'bg-[var(--color-surface-glass-subtle)] backdrop-blur-[var(--blur-subtle)]',
        panel: 'bg-[var(--color-surface-panel)]',
        plain: 'bg-transparent',
      },
      size: {
        compact: 'min-h-28 gap-1.5 p-5',
        card: 'min-h-[164px] gap-2 p-8',
        page: 'min-h-64 gap-2.5 p-10',
      },
    },
    defaultVariants: { appearance: 'glass', size: 'card' },
  },
)

export const spinnerSizeVariants = cva('shrink-0 animate-spin motion-reduce:animate-none', {
  variants: {
    size: {
      compact: 'h-3.5 w-3.5',
      default: 'h-[19px] w-[19px]',
      large: 'h-6 w-6',
    },
  },
  defaultVariants: { size: 'default' },
})

export const loadingStateVariants = cva('flex items-center justify-center text-[var(--color-text-muted)]', {
  variants: {
    appearance: {
      inline: 'w-fit gap-2',
      surface: 'min-h-28 w-full gap-2 rounded-[var(--radius-surface)] bg-[var(--color-surface-glass-subtle)] p-5 backdrop-blur-[var(--blur-subtle)]',
    },
  },
  defaultVariants: { appearance: 'inline' },
})
