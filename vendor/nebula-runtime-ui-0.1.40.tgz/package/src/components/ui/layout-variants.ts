import { cva } from 'class-variance-authority'

export const contentContainerVariants = cva('mx-auto w-full min-w-0', {
  variants: {
    width: {
      narrow: 'max-w-[var(--content-width-narrow)]',
      reading: 'max-w-[var(--content-width-reading)]',
      workspace: 'max-w-[var(--content-width-workspace)]',
      system: 'max-w-[var(--content-width-system)]',
      full: 'max-w-none',
    },
    gutter: {
      none: '',
      responsive: 'px-4 sm:px-6 lg:px-8',
      workspace: 'px-8',
    },
    spacing: {
      none: '',
      page: 'py-8',
      pageWithFooter: 'pb-48 pt-8',
    },
  },
  defaultVariants: { width: 'workspace', gutter: 'responsive', spacing: 'page' },
})

export const pageHeaderVariants = cva(
  'flex items-start justify-between gap-4',
  {
    variants: {
      spacing: {
        compact: 'mb-5',
        default: 'mb-6',
        comfortable: 'mb-7',
      },
      responsive: {
        true: 'max-sm:flex-col max-sm:items-stretch',
        false: '',
      },
    },
    defaultVariants: { spacing: 'default', responsive: true },
  },
)
