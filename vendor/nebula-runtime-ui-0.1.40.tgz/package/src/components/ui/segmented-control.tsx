import * as TabsPrimitive from '@radix-ui/react-tabs'
import type { ReactNode } from 'react'
import { cn } from '#nebula/lib/utils'

export interface SegmentedOption<T extends string> {
  value: T
  label: ReactNode
}

export interface SegmentedControlProps<T extends string> {
  ariaLabel: string
  value: T
  options: readonly SegmentedOption<T>[]
  onValueChange: (value: T) => void
  tone?: 'neutral' | 'high-contrast'
  className?: string
}

export function SegmentedControl<T extends string>({
  ariaLabel,
  value,
  options,
  onValueChange,
  tone = 'neutral',
  className,
}: SegmentedControlProps<T>) {
  const selectedIndex = options.findIndex(option => option.value === value)
  const highContrast = tone === 'high-contrast'
  const optionCount = Math.max(options.length, 1)
  const twoOptions = optionCount === 2

  return (
    <TabsPrimitive.Root value={value} onValueChange={nextValue => onValueChange(nextValue as T)}>
      <TabsPrimitive.List
        aria-label={ariaLabel}
        className={cn(
          'relative grid h-10 items-center rounded-[var(--radius-pill)]',
          highContrast ? 'border border-[var(--color-border-strong)]' : 'bg-[var(--color-surface-segment)]',
          className,
        )}
        style={{ gridTemplateColumns: `repeat(${optionCount}, minmax(0, 1fr))` }}
      >
        <span
          aria-hidden="true"
          className={cn(
            'pointer-events-none absolute rounded-[var(--radius-pill)] shadow-sm',
            'transition-[left,width] duration-[var(--motion-duration-slow)] ease-[var(--motion-ease-emphasized)]',
            twoOptions && 'w-[calc(54%+4px)]',
            twoOptions && (selectedIndex === 0 ? '-left-[3px]' : 'left-[calc(46%-1px)]'),
            highContrast
              ? '-inset-y-[3px] bg-[var(--color-control-primary)] shadow-[var(--shadow-control-emphasis)]'
              : '-inset-y-0.5 bg-[var(--color-surface-segment-selected)]',
          )}
          style={twoOptions ? undefined : {
            left: `calc(${Math.max(selectedIndex, 0)} * 100% / ${optionCount} - 1px)`,
            width: `calc(100% / ${optionCount} + 2px)`,
          }}
        />
        {options.map((option, index) => (
          <TabsPrimitive.Trigger
            key={option.value}
            value={option.value}
            className={cn(
              'relative z-10 flex h-10 cursor-pointer items-center justify-center self-center rounded-[var(--radius-pill)] px-4 text-center text-sm leading-none outline-none',
              'transition-colors duration-[var(--motion-duration-slow)] focus-visible:[outline:var(--focus-ring-width-strong)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-2',
              highContrast
                ? 'text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] data-[state=active]:text-[var(--color-control-on-primary)]'
                : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] data-[state=active]:text-[var(--color-text-primary)]',
            )}
          >
            <span className={cn(
              'flex w-full items-center justify-center gap-1.5',
              twoOptions && (index === 0 ? 'translate-x-[4%]' : '-translate-x-[4%]'),
            )}>
              {option.label}
            </span>
          </TabsPrimitive.Trigger>
        ))}
      </TabsPrimitive.List>
    </TabsPrimitive.Root>
  )
}
