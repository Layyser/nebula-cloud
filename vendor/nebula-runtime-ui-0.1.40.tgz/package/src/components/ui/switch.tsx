import * as React from 'react'
import * as SwitchPrimitive from '@radix-ui/react-switch'
import { cn } from '#nebula/lib/utils'

const Switch = React.forwardRef<
  React.ComponentRef<typeof SwitchPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitive.Root>
>(({ className, ...props }, ref) => (
  <SwitchPrimitive.Root
    ref={ref}
    className={cn(
      'peer inline-flex h-4 w-7 shrink-0 cursor-pointer items-center rounded-[var(--radius-pill)]',
      'outline-none transition-colors duration-[var(--motion-duration-fast)] ease-[var(--motion-ease-standard)] focus-visible:[outline:var(--focus-ring-width-strong)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-2',
      'disabled:cursor-not-allowed disabled:opacity-50',
      'data-[state=checked]:bg-[var(--color-control-primary)] data-[state=unchecked]:bg-[var(--color-surface-field)]',
      className,
    )}
    {...props}
  >
    <SwitchPrimitive.Thumb
      className={cn(
        'pointer-events-none block h-3 w-3 rounded-[var(--radius-pill)] shadow-sm ring-0 transition-transform duration-[var(--motion-duration-fast)] ease-[var(--motion-ease-standard)]',
        'data-[state=checked]:translate-x-3.5 data-[state=unchecked]:translate-x-0.5',
        'data-[state=checked]:bg-[var(--color-control-on-primary)] data-[state=unchecked]:bg-[var(--color-text-muted)]',
      )}
    />
  </SwitchPrimitive.Root>
))
Switch.displayName = SwitchPrimitive.Root.displayName

export { Switch }
