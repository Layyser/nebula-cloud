import { cva } from 'class-variance-authority'

export const fieldControlVariants = cva(
  'w-full rounded-[var(--radius-control)] border-0 bg-[var(--color-surface-field)] px-3 text-[12px] text-[var(--color-text-secondary)] outline-none transition-[background-color,box-shadow,opacity] duration-[var(--motion-duration-fast)] ease-[var(--motion-ease-standard)] placeholder:text-[var(--color-text-disabled)] focus:bg-[var(--color-surface-field-focus)] focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1 disabled:cursor-not-allowed disabled:opacity-45',
  {
    variants: {
      size: {
        default: 'h-[var(--control-height-field)]',
        large: 'h-[var(--control-height-lg)] text-sm',
      },
      invalid: {
        true: 'bg-[var(--color-status-danger-surface-muted)] focus-visible:[outline-color:var(--color-status-danger)]',
        false: '',
      },
    },
    defaultVariants: { size: 'default', invalid: false },
  },
)

export const formMessageVariants = cva(
  'text-[12px] leading-5',
  {
    variants: {
      tone: {
        neutral: 'text-[var(--color-text-muted)]',
        success: 'text-[var(--color-status-success)]',
        warning: 'text-[var(--color-status-warning)]',
        danger: 'text-[var(--color-status-danger)]',
      },
      appearance: {
        inline: '',
        surface: 'rounded-[var(--radius-control)] px-3 py-2',
      },
    },
    compoundVariants: [
      { appearance: 'surface', tone: 'neutral', className: 'bg-[var(--color-surface-field)]' },
      { appearance: 'surface', tone: 'success', className: 'bg-[var(--color-status-success-surface)]' },
      { appearance: 'surface', tone: 'warning', className: 'bg-[var(--color-status-warning-surface)]' },
      { appearance: 'surface', tone: 'danger', className: 'bg-[var(--color-status-danger-surface-muted)]' },
    ],
    defaultVariants: { tone: 'neutral', appearance: 'inline' },
  },
)

export const checkboxLabelVariants = cva(
  'flex cursor-pointer gap-2 text-[12px] text-[var(--color-text-muted)] transition-colors duration-[var(--motion-duration-fast)] has-[:disabled]:cursor-not-allowed',
  {
    variants: {
      appearance: {
        plain: 'items-start',
        field: 'h-[var(--control-height-field)] items-center rounded-[var(--radius-control)] bg-[var(--color-surface-field)] px-3 hover:bg-[var(--color-surface-field-focus)]',
      },
    },
    defaultVariants: { appearance: 'plain' },
  },
)

export const checkboxIndicatorVariants = cva(
  'flex h-4 w-4 shrink-0 items-center justify-center rounded border border-[var(--color-border-strong)] text-transparent transition-[background-color,border-color,color] duration-[var(--motion-duration-fast)] peer-checked:border-[var(--color-border-focus)] peer-checked:bg-[var(--color-surface-selected)] peer-checked:text-[var(--color-text-primary)] peer-focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] peer-focus-visible:outline-offset-2 peer-disabled:opacity-45',
  {
    variants: {
      appearance: {
        plain: 'mt-0.5',
        field: 'mt-0',
      },
    },
    defaultVariants: { appearance: 'plain' },
  },
)
