export const scrollAreaScrollbarClassName = 'flex w-[6px] touch-none select-none p-px transition-colors duration-[var(--motion-duration-fast)] hover:bg-[var(--color-surface-selected)]'
export const scrollAreaThumbClassName = 'relative flex-1 rounded-[var(--radius-pill)] bg-[var(--color-border-default)] transition-colors duration-[var(--motion-duration-fast)] hover:bg-[var(--color-border-strong)]'
