export const dialogOverlayClassName = [
  'fixed inset-0 z-50 bg-black/65 backdrop-blur-[4px]',
  'transition-opacity duration-[var(--motion-duration-deliberate)] ease-[var(--motion-ease-standard)]',
  'data-[state=closed]:opacity-0 data-[state=open]:opacity-100',
  'motion-reduce:transition-none',
].join(' ')

export const dialogContentClassName = [
  'fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4',
  'rounded-[var(--radius-large)] bg-[var(--color-surface-overlay)] p-6 text-[var(--color-text-primary)]',
  'shadow-[var(--shadow-surface)] backdrop-blur-[var(--blur-overlay)] outline-none',
  'transition-[opacity,transform,filter] duration-[var(--motion-duration-deliberate)] ease-[var(--motion-ease-emphasized)]',
  'data-[state=closed]:scale-[0.985] data-[state=closed]:opacity-0 data-[state=closed]:blur-[2px]',
  'data-[state=open]:scale-100 data-[state=open]:opacity-100 data-[state=open]:blur-0',
  'motion-reduce:transition-none',
].join(' ')

export const dialogHeaderClassName = 'flex flex-col gap-1.5 text-left'
export const dialogFooterClassName = 'flex flex-col-reverse gap-2 sm:flex-row sm:justify-end'
export const dialogTitleClassName = 'text-base font-semibold leading-none tracking-tight text-[var(--color-text-primary)]'
export const dialogDescriptionClassName = 'text-sm leading-relaxed text-[var(--color-text-secondary)]'
