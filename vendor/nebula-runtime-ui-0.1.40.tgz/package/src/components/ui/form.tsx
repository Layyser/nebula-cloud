import { createContext, forwardRef, useContext, useId, type HTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react'
import { Check } from 'lucide-react'
import type { VariantProps } from 'class-variance-authority'
import { cn } from '#nebula/lib/utils'
import { checkboxIndicatorVariants, checkboxLabelVariants, fieldControlVariants, formMessageVariants } from './form-variants'

interface FieldContextValue {
  controlId: string
  describedBy?: string
  invalid: boolean
}

const FieldContext = createContext<FieldContextValue | null>(null)

export interface FieldProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  label: ReactNode
  children: ReactNode
  controlId?: string
  description?: ReactNode
  error?: ReactNode
  required?: boolean
}

export const Field = forwardRef<HTMLDivElement, FieldProps>(function Field(
  { className, label, children, controlId, description, error, required = false, ...props },
  ref,
) {
  const generatedId = useId()
  const id = controlId ?? `field-${generatedId}`
  const descriptionId = description ? `${id}-description` : undefined
  const errorId = error ? `${id}-error` : undefined
  const describedBy = [descriptionId, errorId].filter(Boolean).join(' ') || undefined

  return (
    <FieldContext.Provider value={{ controlId: id, describedBy, invalid: Boolean(error) }}>
      <div ref={ref} className={cn('block', className)} {...props}>
        <label htmlFor={id} className="mb-1.5 block text-[10px] font-semibold uppercase tracking-widest text-white/35">
          {label}
          {required && <span aria-hidden="true" className="ml-1 text-[var(--color-status-danger)]">*</span>}
        </label>
        {children}
        {description && <FormMessage id={descriptionId} className="mt-1.5">{description}</FormMessage>}
        {error && <FormMessage id={errorId} tone="danger" className="mt-1.5">{error}</FormMessage>}
      </div>
    </FieldContext.Provider>
  )
})

function describedBy(own: string | undefined, field: FieldContextValue | null): string | undefined {
  return [own, field?.describedBy].filter(Boolean).join(' ') || undefined
}

export interface InputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'>,
    VariantProps<typeof fieldControlVariants> {}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { className, id, size, invalid, 'aria-describedby': ariaDescribedBy, 'aria-invalid': ariaInvalid, ...props },
  ref,
) {
  const field = useContext(FieldContext)
  const isInvalid = invalid ?? field?.invalid ?? false
  return (
    <input
      ref={ref}
      id={id ?? field?.controlId}
      aria-describedby={describedBy(ariaDescribedBy, field)}
      aria-invalid={ariaInvalid ?? (isInvalid || undefined)}
      className={cn(fieldControlVariants({ size, invalid: isInvalid }), className)}
      {...props}
    />
  )
})

export interface TextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement>,
    Pick<VariantProps<typeof fieldControlVariants>, 'invalid'> {}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { className, id, invalid, 'aria-describedby': ariaDescribedBy, 'aria-invalid': ariaInvalid, ...props },
  ref,
) {
  const field = useContext(FieldContext)
  const isInvalid = invalid ?? field?.invalid ?? false
  return (
    <textarea
      ref={ref}
      id={id ?? field?.controlId}
      aria-describedby={describedBy(ariaDescribedBy, field)}
      aria-invalid={ariaInvalid ?? (isInvalid || undefined)}
      className={cn(fieldControlVariants({ invalid: isInvalid }), 'min-h-24 resize-y py-2 leading-5', className)}
      {...props}
    />
  )
})

export interface CheckboxProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'>,
    VariantProps<typeof checkboxLabelVariants> {
  label: ReactNode
  description?: ReactNode
}

export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(function Checkbox(
  { appearance, className, label, description, id, ...props },
  ref,
) {
  const generatedId = useId()
  const controlId = id ?? `checkbox-${generatedId}`
  const descriptionId = description ? `${controlId}-description` : undefined
  return (
    <label htmlFor={controlId} className={cn(checkboxLabelVariants({ appearance }), className)}>
      <input
        ref={ref}
        id={controlId}
        type="checkbox"
        aria-describedby={descriptionId}
        className="peer sr-only"
        {...props}
      />
      <span
        aria-hidden="true"
        className={checkboxIndicatorVariants({ appearance })}
      >
        <Check size={11} strokeWidth={2.5} />
      </span>
      <span>
        <span className="block leading-5">{label}</span>
        {description && <span id={descriptionId} className="mt-0.5 block text-[11px] leading-4 text-[var(--color-text-subtle)]">{description}</span>}
      </span>
    </label>
  )
})

export interface FormMessageProps
  extends HTMLAttributes<HTMLParagraphElement>,
    VariantProps<typeof formMessageVariants> {}

export const FormMessage = forwardRef<HTMLParagraphElement, FormMessageProps>(function FormMessage(
  { className, tone, appearance, ...props },
  ref,
) {
  return <p ref={ref} className={cn(formMessageVariants({ tone, appearance }), className)} {...props} />
})
