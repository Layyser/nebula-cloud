import { Slot } from '@radix-ui/react-slot'
import type { VariantProps } from 'class-variance-authority'
import { forwardRef, type HTMLAttributes, type ReactNode } from 'react'
import { cn } from '#nebula/lib/utils'
import { contentContainerVariants, pageHeaderVariants } from './layout-variants'

export interface ContentContainerProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof contentContainerVariants> {
  asChild?: boolean
}

export const ContentContainer = forwardRef<HTMLDivElement, ContentContainerProps>(function ContentContainer(
  { asChild = false, className, gutter, spacing, width, ...props },
  ref,
) {
  const Component = asChild ? Slot : 'div'
  return <Component ref={ref} className={cn(contentContainerVariants({ gutter, spacing, width }), className)} {...props} />
})

export interface PageHeaderProps
  extends Omit<HTMLAttributes<HTMLElement>, 'title'>,
    VariantProps<typeof pageHeaderVariants> {
  eyebrow?: ReactNode
  title: ReactNode
  description?: ReactNode
  action?: ReactNode
  withBackdrop?: boolean
}

export const PageHeader = forwardRef<HTMLElement, PageHeaderProps>(function PageHeader(
  { action, children, className, description, eyebrow, responsive, spacing, title, withBackdrop = true, ...props },
  ref,
) {
  return (
    <header ref={ref} className={cn(pageHeaderVariants({ responsive, spacing }), className)} {...props}>
      <div className={cn('min-w-0', withBackdrop && 'app-heading-blob')}>
        {eyebrow && <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-white/35">{eyebrow}</p>}
        <h1 className={cn('text-2xl font-semibold text-white/90', eyebrow && 'mt-1')}>{title}</h1>
        {description && <p className="mt-1 max-w-3xl text-sm text-white/45">{description}</p>}
        {children}
      </div>
      {action && <div className="shrink-0 max-sm:self-start">{action}</div>}
    </header>
  )
})
