import { Slot } from '@radix-ui/react-slot'
import { cva, type VariantProps } from 'class-variance-authority'
import { forwardRef, type AnchorHTMLAttributes, type ButtonHTMLAttributes, type MouseEvent, type ReactNode } from 'react'
import { cn } from '#nebula/lib/utils'

export const buttonVariants = cva(
  'inline-flex shrink-0 cursor-pointer select-none items-center justify-center gap-2 whitespace-nowrap border border-transparent font-medium outline-none transition-[color,background-color,border-color,box-shadow,opacity] duration-[var(--motion-duration-fast)] ease-[var(--motion-ease-standard)] focus-visible:[outline:var(--focus-ring-width-strong)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-2 disabled:pointer-events-none disabled:opacity-40',
  {
    variants: {
      variant: {
        primary: 'bg-[var(--color-control-primary)] text-[var(--color-control-on-primary)] hover:bg-[var(--color-control-primary-hover)]',
        secondary: 'bg-[var(--color-control-glass)] text-[var(--color-text-secondary)] backdrop-blur-[var(--blur-glass)] hover:bg-[var(--color-control-glass-hover)] hover:text-[var(--color-text-primary)]',
        recessed: 'bg-[var(--color-surface-recessed)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)]',
        glass: 'bg-[var(--color-control-glass)] text-[var(--color-text-secondary)] backdrop-blur-[var(--blur-glass)] hover:bg-[var(--color-control-glass-hover)] hover:text-[var(--color-text-primary)]',
        ghost: 'text-[var(--color-text-muted)] hover:bg-[var(--legacy-white-06)] hover:text-[var(--color-text-primary)]',
        danger: 'bg-[var(--color-status-danger-surface-muted)] text-[var(--color-status-danger)] hover:bg-[var(--color-status-danger-surface)] hover:text-[var(--color-status-danger-strong)]',
      },
      size: {
        compact: 'h-[var(--control-height-xs)] px-2.5 text-xs',
        default: 'h-[var(--control-height-md)] px-3 text-xs',
        large: 'h-[var(--control-height-lg)] px-4 text-sm',
        hero: 'h-[var(--control-height-hero)] px-6 text-sm',
      },
      radius: {
        default: 'rounded-[var(--radius-surface)]',
        compact: 'rounded-[var(--radius-control)]',
        'marketing-pill': 'rounded-[var(--radius-pill)]',
      },
    },
    compoundVariants: [
      { size: 'compact', radius: 'default', className: 'rounded-[var(--radius-control)]' },
    ],
    defaultVariants: { variant: 'secondary', size: 'default', radius: 'default' },
  }
)

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant, size, radius, asChild = false, type, ...props },
  ref,
) {
  const Comp = asChild ? Slot : 'button'
  return <Comp ref={ref} type={asChild ? undefined : (type ?? 'button')} className={cn(buttonVariants({ variant, size, radius }), className)} {...props} />
})

export interface LinkButtonProps
  extends AnchorHTMLAttributes<HTMLAnchorElement>,
    VariantProps<typeof buttonVariants> {
  disabled?: boolean
}

export const LinkButton = forwardRef<HTMLAnchorElement, LinkButtonProps>(function LinkButton(
  { className, variant, size, radius, disabled = false, onClick, tabIndex, ...props },
  ref,
) {
  const handleClick = (event: MouseEvent<HTMLAnchorElement>) => {
    if (disabled) {
      event.preventDefault()
      return
    }
    onClick?.(event)
  }

  return <a
    ref={ref}
    aria-disabled={disabled || undefined}
    tabIndex={disabled ? -1 : tabIndex}
    className={cn(buttonVariants({ variant, size, radius }), disabled && 'pointer-events-none opacity-40', className)}
    onClick={handleClick}
    {...props}
  />
})

type IconButtonSize = 'compact' | 'default' | 'large'

export interface IconButtonProps extends Omit<ButtonProps, 'aria-label' | 'children' | 'size'> {
  label: string
  children: ReactNode
  size?: IconButtonSize
}

const iconButtonSize: Record<IconButtonSize, string> = {
  compact: 'w-[var(--control-height-xs)] px-0',
  default: 'w-[var(--control-height-md)] px-0',
  large: 'w-[var(--control-height-lg)] px-0',
}

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { className, label, size = 'default', ...props },
  ref,
) {
  return <Button ref={ref} aria-label={label} size={size} className={cn(iconButtonSize[size], className)} {...props} />
})
