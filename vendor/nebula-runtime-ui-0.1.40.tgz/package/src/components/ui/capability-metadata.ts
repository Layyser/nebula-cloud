import { AtSign, Blocks, BookOpen, Clock3, Code2, ScrollText, Wrench, type LucideIcon } from 'lucide-react'

export type CapabilityKind = 'mcps' | 'skills' | 'commands' | 'hooks' | 'rules'
export type CapabilityIconKind = 'capabilities' | CapabilityKind | 'tools'

export const capabilityKinds: CapabilityKind[] = ['mcps', 'skills', 'commands', 'hooks', 'rules']

export interface CapabilityMetadata {
  icon: LucideIcon
  singular: string
  plural: string
  detail: string
}

export const capabilityMetadata: Record<CapabilityIconKind, CapabilityMetadata> = {
  capabilities: {
    icon: Blocks,
    singular: 'Capability',
    plural: 'Capabilities',
    detail: 'Tools, knowledge, automation, and rules',
  },
  mcps: {
    icon: AtSign,
    singular: 'MCP',
    plural: 'MCPs',
    detail: 'External tools and services',
  },
  skills: {
    icon: BookOpen,
    singular: 'Skill',
    plural: 'Skills',
    detail: 'Reusable agent playbooks',
  },
  commands: {
    icon: Code2,
    singular: 'Command',
    plural: 'Commands',
    detail: 'CLI slash commands',
  },
  hooks: {
    icon: Clock3,
    singular: 'Hook',
    plural: 'Hooks',
    detail: 'Automated event triggers',
  },
  rules: {
    icon: ScrollText,
    singular: 'Rule',
    plural: 'Rules',
    detail: 'Reusable instruction files',
  },
  tools: {
    icon: Wrench,
    singular: 'Tool',
    plural: 'Tools',
    detail: 'Runtime tool permissions',
  },
}

export function formatMetadataCount(count: number, singular: string, plural: string) {
  return `${count} ${count === 1 ? singular : plural}`
}
