import { LoaderCircle } from 'lucide-react'
import type { VariantProps } from 'class-variance-authority'
import { forwardRef, type HTMLAttributes, type ReactNode } from 'react'
import { cn } from '#nebula/lib/utils'
import { emptyStateVariants, loadingStateVariants, spinnerSizeVariants } from './state-variants'

export interface EmptyStateProps
  extends Omit<HTMLAttributes<HTMLDivElement>, 'title'>,
    VariantProps<typeof emptyStateVariants> {
  icon?: ReactNode
  title: ReactNode
  description?: ReactNode
  action?: ReactNode
}

export const EmptyState = forwardRef<HTMLDivElement, EmptyStateProps>(function EmptyState(
  { action, appearance, className, description, icon, size, title, ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn(emptyStateVariants({ appearance, size }), 'rounded-[var(--radius-surface)]', className)} {...props}>
      {icon && <div className="mb-1 text-[var(--color-text-subtle)]">{icon}</div>}
      <p className="text-sm font-medium text-[var(--color-text-secondary)]">{title}</p>
      {description && <p className="max-w-md text-xs leading-relaxed text-[var(--color-text-subtle)]">{description}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  )
})

export interface SpinnerProps
  extends Omit<HTMLAttributes<HTMLSpanElement>, 'children'>,
    VariantProps<typeof spinnerSizeVariants> {
  label?: string
}

export const Spinner = forwardRef<HTMLSpanElement, SpinnerProps>(function Spinner(
  { className, label = 'Loading', size, ...props },
  ref,
) {
  return (
    <span ref={ref} role="status" aria-label={label} className={cn('inline-flex text-[var(--color-text-muted)]', className)} {...props}>
      <LoaderCircle aria-hidden="true" className={spinnerSizeVariants({ size })} />
    </span>
  )
})

export interface LoadingStateProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof loadingStateVariants> {
  label?: string
  spinnerSize?: SpinnerProps['size']
}

export const LoadingState = forwardRef<HTMLDivElement, LoadingStateProps>(function LoadingState(
  { appearance, className, label = 'Loading', spinnerSize, ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn(loadingStateVariants({ appearance }), className)} {...props}>
      <Spinner size={spinnerSize} label={label} />
      <span className="text-xs">{label}</span>
    </div>
  )
})
