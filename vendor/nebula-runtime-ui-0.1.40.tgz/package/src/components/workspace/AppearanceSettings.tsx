import { ContextSelect } from '#nebula/components/ui/context-select'
import { Surface } from '#nebula/components/ui/surface'
import { useThemePreference, type ThemePreference } from '#nebula/theme/theme'
import { Monitor, Moon, Sun } from 'lucide-react'

export const THEME_OPTIONS = [
  { value: 'dark', label: 'Dark', icon: <Moon size={14} /> },
  { value: 'light', label: 'Light', icon: <Sun size={14} /> },
  { value: 'system', label: 'System', icon: <Monitor size={14} /> },
] as const

export function AppearanceSettings() {
  const { preference, resolvedTheme, setPreference } = useThemePreference()

  return (
    <div>
      <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[var(--color-text-muted)]">
        Appearance
      </p>
      <h3 className="mt-2 text-xl font-semibold tracking-[-0.02em] text-[var(--color-text-primary)]">
        Choose how Nebula looks.
      </h3>
      <p className="mt-2 max-w-xl text-sm leading-6 text-[var(--color-text-muted)]">
        Use a fixed color mode or follow your operating system automatically.
      </p>

      <Surface
        variant="panel"
        density="compact"
        radius="surface"
        className="mt-8 flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <p className="text-[13px] font-medium text-[var(--color-text-primary)]">Color mode</p>
          <p className="mt-1 text-[11px] leading-5 text-[var(--color-text-muted)]">
            {preference === 'system'
              ? `Following system · currently ${resolvedTheme}`
              : `${preference[0].toUpperCase()}${preference.slice(1)} mode`}
          </p>
        </div>
        <div className="w-full sm:w-[19rem]">
          <ContextSelect<ThemePreference>
            ariaLabel="Color mode"
            value={preference}
            options={[...THEME_OPTIONS]}
            onChange={setPreference}
            contentWidth="w-[19rem]"
            side="bottom"
          />
        </div>
      </Surface>
    </div>
  )
}
