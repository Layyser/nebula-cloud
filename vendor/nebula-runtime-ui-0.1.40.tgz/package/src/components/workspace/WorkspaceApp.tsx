import { useState, useCallback, useEffect, useMemo, useRef, type ReactNode } from 'react'
import { AnimatePresence, LayoutGroup, motion, useReducedMotion } from 'framer-motion'
import { Bot, Cpu, Palette, PlugZap, Settings2 } from 'lucide-react'
import { Sidebar } from '#nebula/components/layout/Sidebar'
import { ChatPanel } from '#nebula/components/layout/ChatPanel'
import { AgentsView } from '#nebula/components/layout/AgentsView'
import { ConnectionsView } from '#nebula/components/layout/ConnectionsView'
import { ProviderSettings } from '#nebula/components/workspace/ProviderSettings'
import { AppearanceSettings } from '#nebula/components/workspace/AppearanceSettings'
import { SettingsShell, type SettingsSection } from '#nebula/components/workspace/SettingsShell'
import { useChats } from '#nebula/hooks/useChats'
import { useChat } from '#nebula/hooks/useChat'
import { configureRuntimeTransport, fetchAgents, fetchMcps, fetchModels, fetchSession, setSessionAgent, setSessionCwd, setSessionModel, setSessionReasoningEffort, setSessionSecurityMode, type AgentInfo, type McpInfo, type ModelInfo, type ReasoningEffort, type ReasoningEffortChoice, type SecurityMode, type SessionInfo } from '#nebula/lib/api'
import { createHttpRuntimeTransport, type RuntimeTransport } from '#nebula/runtime/transport'

function generateChatName() {
  const suffix = typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID().slice(0, 8)
    : Math.random().toString(16).slice(2, 10)
  return `chat-${Date.now()}-${suffix}`
}

function inheritedEffort(agents: AgentInfo[], agentName: string | null): ReasoningEffort {
  const selected = agents.find(agent => agent.name === (agentName ?? 'Default'))
  const globalDefault = agents.find(agent => agent.name === 'Default')
  return selected?.reasoning_effort ?? globalDefault?.reasoning_effort ?? 'medium'
}

function inheritedModel(agents: AgentInfo[], agentName: string | null): string {
  const selected = agents.find(agent => agent.name === (agentName ?? 'Default'))
  const globalDefault = agents.find(agent => agent.name === 'Default')
  return selected?.model ?? globalDefault?.model ?? ''
}

export interface RuntimeNavigationItem {
  id: string
  label: string
  icon: ReactNode
  active?: boolean
  /** Whether this host-owned view exposes the shared Nebula shader. */
  background?: 'shader' | 'plain'
  /** Keep host-owned content mounted while another workspace view is active. */
  keepMounted?: boolean
  onSelect: () => void
  /**
   * Optional host-owned view rendered inside the shared runtime shell.
   * Runtime navigation and sessions remain owned by RuntimeWorkspace.
   */
  content?: ReactNode | ((controls: { close: () => void }) => ReactNode)
}

export interface RuntimeIdentityMenuItem {
  label: string
  icon: ReactNode
  onSelect: () => void
  disabled?: boolean
  tone?: 'default' | 'danger'
}

export type RuntimeWorkspaceView = 'sessions' | 'agents' | 'connections'

export interface RuntimeWorkspaceProps {
  transport?: RuntimeTransport
  /** @deprecated Prefer an explicit transport. Kept for standalone embedders. */
  runtimeBaseUrl?: string
  /** Increment after host-managed credentials or catalogs change. */
  catalogRevision?: number
  brandLabel?: string
  identityLabel?: string
  identityInitial?: string
  identityMenuItems?: RuntimeIdentityMenuItem[]
  onBrandSelect?: () => void
  externalNavigation?: RuntimeNavigationItem[]
  /** Initial view used by deterministic previews and controlled embedders. */
  initialView?: RuntimeWorkspaceView
  /** Initial session used by deterministic previews and controlled embedders. */
  initialChat?: string | null
  /** Open the agent configuration surface on first render. */
  initialAgentBuilder?: boolean
  /** Open the delete confirmation for this session on first render. */
  initialDeleteChat?: string | null
}

export default function WorkspaceApp({
  transport,
  runtimeBaseUrl,
  catalogRevision = 0,
  brandLabel = 'Nebula',
  identityLabel = 'Local workspace',
  identityInitial = 'L',
  identityMenuItems = [],
  onBrandSelect,
  externalNavigation = [],
  initialView = 'sessions',
  initialChat = null,
  initialAgentBuilder = false,
  initialDeleteChat = null,
}: RuntimeWorkspaceProps) {
  const activeTransport = useMemo(
    () => transport ?? createHttpRuntimeTransport(runtimeBaseUrl ?? '/api'),
    [transport, runtimeBaseUrl],
  )
  configureRuntimeTransport(activeTransport)

  const { chats, refresh: refreshChats, remove, removeMany, add, toggleHooks } = useChats()
  const [activeChat, setActiveChat]       = useState<string | null>(initialChat)
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null)
  const [securityMode, setSecurityMode]   = useState<SecurityMode>('default')
  const [sessionInfo, setSessionInfo]     = useState<SessionInfo | null>(null)
  const [pendingCwd, setPendingCwd]       = useState('.')
  const [reasoningEffort, setReasoningEffort] = useState<ReasoningEffort>('medium')
  const [reasoningEffortOverride, setReasoningEffortOverride] = useState<ReasoningEffort | null>(null)
  const [model, setModel]                   = useState('')
  const [modelOverride, setModelOverride]   = useState<string | null>(null)
  const [models, setModels]                 = useState<ModelInfo[]>([])
  const [agents, setAgents]               = useState<AgentInfo[]>([])
  const [mcps, setMcps]                   = useState<McpInfo[]>([])
  const [activeView, setActiveView]       = useState<RuntimeWorkspaceView>(initialView)
  const [activeExternalView, setActiveExternalView] = useState<string | null>(null)
  const [mountedExternalViews, setMountedExternalViews] = useState<Set<string>>(
    () => new Set(),
  )
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [settingsSection, setSettingsSection] = useState('providers')
  const [workspaceEntered, setWorkspaceEntered] = useState(false)
  const newChatRef = useRef<string | null>(null)

  const activeRun = chats.find(chat => chat.name === activeChat)?.run ?? null
  const { messages, loading, streaming, pendingInput, send, abort, respond } = useChat(activeChat, activeRun)

  const refreshAgents = useCallback(async () => {
    try { setAgents(await fetchAgents()) } catch { /* keep the last known catalog */ }
  }, [])

  const refreshMcps = useCallback(async () => {
    try { setMcps(await fetchMcps()) } catch { /* keep the last known catalog */ }
  }, [])

  const refreshModels = useCallback(async () => {
    try {
      const catalog = await fetchModels()
      setModels(catalog.models)
      setAgents(current => current.map(agent => agent.name === 'Default' && !agent.model
        ? { ...agent, model: catalog.default_model }
        : agent))
    } catch { /* keep the last known catalog */ }
  }, [])

  useEffect(() => {
    void refreshAgents()
    void refreshMcps()
    void refreshModels()
  }, [catalogRevision, refreshAgents, refreshMcps, refreshModels])

  useEffect(() => {
    if (!activeChat && reasoningEffortOverride === null)
      setReasoningEffort(inheritedEffort(agents, selectedAgent))
  }, [activeChat, agents, selectedAgent, reasoningEffortOverride])

  useEffect(() => {
    if (!activeChat && modelOverride === null)
      setModel(inheritedModel(agents, selectedAgent))
  }, [activeChat, agents, selectedAgent, modelOverride])

  useEffect(() => {
    if (!activeChat) return
    if (newChatRef.current === activeChat) {
      newChatRef.current = null
      return
    }
    let active = true
    void fetchSession(activeChat)
      .then(session => {
        if (!active) return
        setSessionInfo(session)
        setSelectedAgent(session.agent ?? null)
        setPendingCwd(session.cwd ?? session.workspace_root ?? '.')
        setSecurityMode(session.security_mode ?? 'default')
        setReasoningEffort(session.reasoning_effort ?? 'medium')
        setReasoningEffortOverride(session.reasoning_effort_override ?? null)
        setModel(session.model)
        setModelOverride(session.model_override ?? null)
      })
      .catch(() => { /* keep the last selected mode while offline */ })
    return () => { active = false }
  }, [activeChat])

  // ── Navigation ────────────────────────────────────────────────────────────────

  const handleNew = useCallback(() => {
    setActiveExternalView(null)
    setActiveView('sessions')
    setActiveChat(null)
    setSelectedAgent(null)
    setSecurityMode('default')
    setSessionInfo(null)
    setPendingCwd('.')
    setReasoningEffortOverride(null)
    setReasoningEffort(inheritedEffort(agents, null))
    setModelOverride(null)
    setModel(inheritedModel(agents, null))
  }, [agents])

  const handleSelect = useCallback((name: string) => {
    setActiveExternalView(null)
    newChatRef.current = null
    const selected = chats.find(chat => chat.name === name)
    setActiveView('sessions')
    setActiveChat(name)
    setSelectedAgent(selected?.agent ?? null)
    setSessionInfo(null)
    setPendingCwd(selected?.cwd ?? selected?.workspace_root ?? '.')
  }, [chats])

  const handleNewInProject = useCallback((path: string) => {
    handleNew()
    setPendingCwd(path)
  }, [handleNew])

  const handleDelete = useCallback(async (name: string) => {
    await remove(name)
    if (activeChat === name) {
      setActiveChat(null)
      setSelectedAgent(null)
    }
  }, [remove, activeChat])

  const handleDeleteProject = useCallback(async (names: string[]) => {
    await removeMany(names)
    if (activeChat && names.includes(activeChat)) {
      setActiveChat(null)
      setSelectedAgent(null)
      setSessionInfo(null)
      setPendingCwd('.')
    }
  }, [removeMany, activeChat])

  // ── Agent selector ────────────────────────────────────────────────────────────

  const handleSwitchAgent = useCallback(async (agentName: string | null) => {
    setSelectedAgent(agentName)
    if (activeChat) {
      await setSessionAgent(activeChat, agentName)
      add(activeChat, agentName ?? undefined)
      if (reasoningEffortOverride === null) {
        const session = await fetchSession(activeChat)
        setReasoningEffort(session.reasoning_effort ?? inheritedEffort(agents, agentName))
      }
      if (modelOverride === null) {
        const session = await fetchSession(activeChat)
        setModel(session.model ?? inheritedModel(agents, agentName))
      }
    } else if (reasoningEffortOverride === null) {
      setReasoningEffort(inheritedEffort(agents, agentName))
    }
    if (!activeChat && modelOverride === null)
      setModel(inheritedModel(agents, agentName))
  }, [activeChat, add, agents, reasoningEffortOverride, modelOverride])

  const handleSwitchSecurityMode = useCallback((mode: SecurityMode) => {
    const previous = securityMode
    setSecurityMode(mode)
    if (activeChat) {
      void setSessionSecurityMode(activeChat, mode).catch(() => setSecurityMode(previous))
    }
  }, [activeChat, securityMode])

  const handleSwitchCwd = useCallback(async (path: string) => {
    const normalized = path.trim() || '.'
    if (!activeChat) {
      setPendingCwd(normalized)
      return
    }
    const session = await setSessionCwd(activeChat, normalized)
    setSessionInfo(session)
    setPendingCwd(session.cwd ?? normalized)
    await refreshChats()
  }, [activeChat, refreshChats])

  const handleSwitchReasoningEffort = useCallback((choice: ReasoningEffortChoice) => {
    const previousEffort = reasoningEffort
    const previousOverride = reasoningEffortOverride
    const nextOverride = choice === 'default' ? null : choice
    setReasoningEffortOverride(nextOverride)
    setReasoningEffort(nextOverride ?? inheritedEffort(agents, selectedAgent))
    if (activeChat) {
      void setSessionReasoningEffort(activeChat, choice)
        .then(session => {
          setReasoningEffort(session.reasoning_effort)
          setReasoningEffortOverride(session.reasoning_effort_override ?? null)
        })
        .catch(() => {
          setReasoningEffort(previousEffort)
          setReasoningEffortOverride(previousOverride)
        })
    }
  }, [activeChat, agents, reasoningEffort, reasoningEffortOverride, selectedAgent])

  const handleSwitchModel = useCallback((choice: string | 'default') => {
    const previousModel = model
    const previousOverride = modelOverride
    const nextOverride = choice === 'default' ? null : choice
    const nextSlug = nextOverride ?? inheritedModel(agents, selectedAgent)
    setModelOverride(nextOverride)
    setModel(nextSlug)

    // Clamp the reasoning effort to the new model's supported set so a value
    // like "max" is not sent to a model that only accepts low/medium/high.
    if (reasoningEffortOverride !== null) {
      const nextEfforts = models.find(m => m.slug === nextSlug)?.reasoning_efforts
      if (nextEfforts && !nextEfforts.includes(reasoningEffortOverride)) {
        setReasoningEffortOverride(null)
        setReasoningEffort(inheritedEffort(agents, selectedAgent))
        if (activeChat) {
          void setSessionReasoningEffort(activeChat, 'default').catch(() => {})
        }
      }
    }

    if (activeChat) {
      void setSessionModel(activeChat, choice)
        .then(session => {
          setModel(session.model)
          setModelOverride(session.model_override ?? null)
        })
        .catch(() => {
          setModel(previousModel)
          setModelOverride(previousOverride)
        })
    }
  }, [activeChat, agents, model, modelOverride, models, reasoningEffortOverride, selectedAgent])

  const handleShowAgents = useCallback(() => {
    setActiveExternalView(null)
    setActiveView('agents')
    setActiveChat(null)
    setSelectedAgent(null)
  }, [])

  const handleShowConnections = useCallback(() => {
    setActiveExternalView(null)
    setActiveView('connections')
    setActiveChat(null)
    setSelectedAgent(null)
  }, [])

  const handleShowSettings = useCallback(() => {
    setSettingsSection('providers')
    setSettingsOpen(true)
  }, [])

  const settingsSections: SettingsSection[] = [
    { id: 'general', label: 'General', group: 'Runtime', icon: <Settings2 size={15} /> },
    { id: 'providers', label: 'Providers', group: 'Runtime', icon: <PlugZap size={15} /> },
    { id: 'models', label: 'Models', group: 'Runtime', icon: <Bot size={15} /> },
    { id: 'workspace', label: 'Workspace', group: 'Workspace', icon: <Cpu size={15} /> },
    { id: 'appearance', label: 'Appearance', group: 'Personalize', icon: <Palette size={15} /> },
  ]

  // ── Send ──────────────────────────────────────────────────────────────────────

  const handleSend = useCallback(async (text: string, _files?: File[]) => {
    if (!activeChat) {
      const name = generateChatName()
      let initialSession: SessionInfo | undefined
      if (pendingCwd !== '.') {
        initialSession = await setSessionCwd(name, pendingCwd)
        setSessionInfo(initialSession)
      }
      newChatRef.current = name
      add(name, selectedAgent ?? undefined, initialSession && {
        cwd: initialSession.cwd,
        workspace_root: initialSession.workspace_root,
        cwd_updated_at_ms: initialSession.cwd_updated_at_ms,
      })
      setActiveChat(name)
      send(text, name, selectedAgent ?? undefined, securityMode,
        reasoningEffortOverride ?? undefined, modelOverride ?? undefined)
    } else {
      send(text)
    }
  }, [activeChat, add, send, selectedAgent, securityMode, reasoningEffortOverride, modelOverride, pendingCwd])

  const handleConfigurerSend = useCallback((text: string, files?: File[]) => {
    if (!activeChat) {
      const name = generateChatName()
      newChatRef.current = name
      add(name, 'configurer')
      setActiveChat(name)
      setSelectedAgent('configurer')
      send(text, name, 'configurer', securityMode,
        reasoningEffortOverride ?? undefined, modelOverride ?? undefined)
    } else {
      send(text, undefined, 'configurer')
    }
    void files
  }, [activeChat, add, send, securityMode, reasoningEffortOverride, modelOverride])

  const selectedExternalView = externalNavigation.find(
    item => item.id === activeExternalView && item.content !== undefined,
  )
  const reduceMotion = useReducedMotion()
  const externalViews = externalNavigation.filter(
    item => item.content !== undefined,
  )
  const runtimeNavigation = externalNavigation.map(item => ({
    ...item,
    active: item.id === activeExternalView
      || (activeExternalView === null && item.active),
    onSelect: () => {
      if (item.content !== undefined) {
        setActiveExternalView(item.id)
        if (item.keepMounted) {
          setMountedExternalViews(current => {
            if (current.has(item.id)) return current
            const next = new Set(current)
            next.add(item.id)
            return next
          })
        }
      }
      item.onSelect()
    },
  }))
  const closeExternalView = useCallback(() => {
    setActiveExternalView(null)
  }, [])
  const sidebarOverShader = selectedExternalView
    ? selectedExternalView.background === 'shader'
    : activeView !== 'sessions' || activeChat === null

  return (
    <div className="relative z-[2] flex h-screen w-full overflow-hidden bg-transparent">
      <div className="relative flex w-full h-full" style={{ zIndex: 1 }}>
        <Sidebar
          chats={chats}
          activeChat={activeExternalView === null ? activeChat : null}
          onSelect={handleSelect}
          onNew={handleNew}
          onNewInProject={handleNewInProject}
          onDelete={handleDelete}
          onDeleteProject={handleDeleteProject}
          onToggleHooks={toggleHooks}
          activeView={activeExternalView === null ? activeView : null}
          onAgents={handleShowAgents}
          onConnections={handleShowConnections}
          onSettings={handleShowSettings}
          brandLabel={brandLabel}
          identityLabel={identityLabel}
          identityInitial={identityInitial}
          identityMenuItems={identityMenuItems}
          onBrandSelect={onBrandSelect}
          externalNavigation={runtimeNavigation}
          initialDeleteChat={initialDeleteChat}
          overShader={sidebarOverShader}
        />

        <LayoutGroup id="workspace-chat-input">
          {externalViews.map(item => {
            const active = item.id === activeExternalView
            if (!active && !mountedExternalViews.has(item.id)) return null
            return (
              <div
                key={item.id}
                className={active ? 'contents' : 'hidden'}
                aria-hidden={!active}
              >
                {typeof item.content === 'function'
                  ? item.content({ close: closeExternalView })
                  : item.content}
              </div>
            )
          })}
          {!selectedExternalView && (activeView === 'agents' ? (
            <AgentsView
              initialCreating={initialAgentBuilder}
              agents={agents}
              mcps={mcps}
              chatName={activeChat}
              messages={messages}
              loading={loading}
              streaming={streaming}
              pendingInput={pendingInput}
              onSend={handleConfigurerSend}
              onAbort={abort}
              onRespond={(choice, always) => respond(choice, always)}
              onRefreshAgents={refreshAgents}
              reasoningEffort={reasoningEffort}
              reasoningEffortOverride={reasoningEffortOverride}
              inheritedReasoningEffort={inheritedEffort(agents, 'configurer')}
              onSwitchReasoningEffort={handleSwitchReasoningEffort}
              models={models}
              model={model}
              modelOverride={modelOverride}
              inheritedModel={inheritedModel(agents, 'configurer')}
              onSwitchModel={handleSwitchModel}
            />
          ) : activeView === 'connections' ? (
            <ConnectionsView mcps={mcps} onRefresh={refreshMcps} />
          ) : (
            <ChatPanel
              chatName={activeChat}
              messages={messages}
              loading={loading}
              streaming={streaming}
              pendingInput={pendingInput}
              session={sessionInfo}
              agents={agents}
              pendingAgent={selectedAgent}
              onSend={handleSend}
              onAbort={abort}
              onRespond={(choice, always) => respond(choice, always)}
              onSwitchAgent={handleSwitchAgent}
              securityMode={securityMode}
              onSwitchSecurityMode={handleSwitchSecurityMode}
              cwd={pendingCwd}
              workspaceRoot={sessionInfo?.workspace_root}
              onSwitchCwd={handleSwitchCwd}
              reasoningEffort={reasoningEffort}
              reasoningEffortOverride={reasoningEffortOverride}
              inheritedReasoningEffort={inheritedEffort(agents, selectedAgent)}
              onSwitchReasoningEffort={handleSwitchReasoningEffort}
              models={models}
              model={model}
              modelOverride={modelOverride}
              inheritedModel={inheritedModel(agents, selectedAgent)}
              onSwitchModel={handleSwitchModel}
              initialEntrance={!workspaceEntered}
              onEntranceComplete={() => setWorkspaceEntered(true)}
            />
          ))}
        </LayoutGroup>
      </div>

      <AnimatePresence>
        {settingsOpen && (
          <motion.div
            className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 p-5 backdrop-blur-sm"
            initial={reduceMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.18 }}
            onMouseDown={event => {
              if (event.target === event.currentTarget) setSettingsOpen(false)
            }}
          >
            <motion.div
              initial={reduceMotion ? false : { opacity: 0, y: 10, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.985 }}
              transition={{ duration: reduceMotion ? 0 : 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="w-full max-w-5xl"
            >
              <SettingsShell
                sections={settingsSections}
                activeSection={settingsSection}
                onSectionChange={setSettingsSection}
                onClose={() => setSettingsOpen(false)}
              >
                {settingsSection === 'providers' ? (
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[var(--color-text-muted)]">
                      Model providers
                    </p>
                    <h3 className="mt-2 text-xl font-semibold tracking-[-0.02em] text-[var(--color-text-primary)]">
                      Connect the models Nebula can use.
                    </h3>
                    <p className="mt-2 max-w-xl text-sm leading-6 text-[var(--color-text-muted)]">
                      Provider credentials stay inside this runtime. The workspace only exposes whether a provider is connected.
                    </p>
                    <div className="mt-8">
                      <ProviderSettings
                        transport={activeTransport}
                        onProviderConnected={() => { void refreshModels() }}
                      />
                    </div>
                  </div>
                ) : settingsSection === 'appearance' ? (
                  <AppearanceSettings />
                ) : (
                  <div className="flex min-h-[420px] items-center justify-center text-center">
                    <div>
                      <p className="text-sm font-medium text-[var(--color-text-secondary)]">{settingsSections.find(section => section.id === settingsSection)?.label}</p>
                      <p className="mt-2 text-xs text-[var(--color-text-disabled)]">This section will be available as the runtime settings grow.</p>
                    </div>
                  </div>
                )}
              </SettingsShell>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  )
}
