import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { ChevronDown, ChevronRight, Loader2, Redo2, Undo2 } from 'lucide-react'
import { AnimatePresence, motion } from 'framer-motion'
import { cn } from '#nebula/lib/utils'
import { StatusDot } from '#nebula/components/ui/badge'
import { type ToolCallBlock as ToolCallBlockType } from '#nebula/hooks/useChat'
import { fetchWorkspaceChange, mutateWorkspaceChange, type WorkspaceChange } from '#nebula/lib/api'
import {
  changeFromResult,
  fallbackToolDisplay,
  legacyEditDiff,
  parseUnifiedDiff,
  type DiffLine,
} from '#nebula/lib/toolPresentation'

function toolResultFailed(result: unknown): boolean {
  if (!result || typeof result !== 'object') return false
  const value = result as Record<string, unknown>
  if (typeof value.error === 'string' && value.error.trim().length > 0) return true
  if (typeof value.exit_code === 'number' && value.exit_code !== 0) return true
  if (typeof value.exitCode === 'number' && value.exitCode !== 0) return true
  return typeof value.status === 'string' && ['error', 'failed', 'failure'].includes(value.status.toLowerCase())
}

export function ToolCallCard({ toolCall }: { toolCall: ToolCallBlockType }) {
  const [open, setOpen] = useState(false)
  const [view, setView] = useState<'tool' | 'raw'>('tool')
  const initialChange = changeFromResult(toolCall.result)
  const [change, setChange] = useState<WorkspaceChange | null>(null)
  const [changeError, setChangeError] = useState('')
  const [changing, setChanging] = useState(false)
  const pending = toolCall.result === undefined
  const display = toolCall.display ?? fallbackToolDisplay(toolCall.name, toolCall.args)
  const changeId = initialChange?.id
  const effectiveChange = change?.id === changeId ? change : initialChange

  useEffect(() => {
    if (!changeId) return
    let active = true
    fetchWorkspaceChange(changeId)
      .then(current => { if (active) setChange(current) })
      .catch(() => { /* the immutable result still renders if the backend is offline */ })
    return () => { active = false }
  }, [changeId])

  const mutate = async () => {
    if (!effectiveChange || changing) return
    const action = effectiveChange.status === 'reverted' ? 'unrevert' : 'revert'
    setChanging(true)
    setChangeError('')
    try {
      setChange(await mutateWorkspaceChange(effectiveChange.id, action))
    } catch (error) {
      setChangeError(error instanceof Error ? error.message : String(error))
    } finally {
      setChanging(false)
    }
  }

  const rawPayload: Record<string, unknown> = {
    id: toolCall.id,
    item_id: toolCall.itemId,
    name: toolCall.name,
    args: toolCall.args,
  }
  if (toolCall.result !== undefined) rawPayload.result = toolCall.result

  const toolView = (
    <div className="min-w-0">
      {pending
        ? <div className="px-3 py-2 font-mono text-[var(--color-text-disabled)]">
            {toolCall.name === 'bash' || toolCall.name === 'Bash'
              ? 'Waiting for permission or output…'
              : 'Waiting for output…'}
          </div>
        : <ToolOutput toolCall={toolCall} displayKind={display.kind} change={effectiveChange} />}
      {effectiveChange && (
        <div className="flex items-center gap-2 border-t border-[var(--color-border-subtle)] p-2">
          <button
            onClick={mutate}
            disabled={changing}
            className="inline-flex h-7 items-center justify-center gap-1.5 rounded-lg bg-[var(--color-surface-recessed)] pl-1.5 pr-2.5 text-[11px] font-medium leading-none text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)] disabled:opacity-40"
          >
            {changing
              ? <Loader2 size={10} className="animate-spin" />
              : effectiveChange.status === 'reverted' ? <Redo2 size={10} /> : <Undo2 size={10} />}
            {effectiveChange.status === 'reverted' ? 'Unrevert' : 'Revert'}
          </button>
          <span className={cn(
            'text-[10px] font-semibold uppercase tracking-widest select-none',
            effectiveChange.status === 'reverted' ? 'text-[var(--color-status-warning)]' : 'text-[var(--color-status-success)]',
          )}>{effectiveChange.status}</span>
          {changeError && <span className="text-[10px] text-[var(--color-status-danger)]">{changeError}</span>}
        </div>
      )}
    </div>
  )
  const rawView = (
    <pre className="max-h-96 overflow-auto bg-transparent px-3 py-2 font-mono text-[11px] leading-5 text-[var(--color-text-muted)] whitespace-pre-wrap break-all">
      {JSON.stringify(rawPayload, null, 2)}
    </pre>
  )

  return (
    <div className="my-1 w-full min-w-0 overflow-hidden rounded-xl bg-[var(--color-surface-panel)] text-[12px] leading-5">
      <div className="flex min-w-0 items-center bg-[var(--color-surface-hover)] transition-colors duration-200 hover:bg-[var(--color-surface-raised)]">
        <button
          type="button"
          onClick={() => setOpen(current => !current)}
          aria-expanded={open}
          className={cn(
            'relative flex min-w-0 flex-1 cursor-pointer items-center gap-2 py-2 pl-2 text-left',
            'focus:outline-none focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-[var(--focus-ring-color-subtle)]',
            open ? 'pr-3' : 'pr-7',
          )}
        >
          {open
            ? <ChevronDown size={13} className="flex-shrink-0 text-[var(--color-text-subtle)]" />
            : <ChevronRight size={13} className="flex-shrink-0 text-[var(--color-text-subtle)]" />}
          <span className="min-w-0 truncate font-mono text-[var(--color-text-secondary)]">
            <span className="text-[var(--color-text-primary)]">{display.label}</span>
            <span className="text-[var(--color-text-subtle)]">(</span>
            <span className="text-[var(--color-text-secondary)]">{display.primary}</span>
            <span className="text-[var(--color-text-subtle)]">)</span>
          </span>
          <span
            aria-hidden={open}
            className={cn(
              'absolute right-3 top-1/2 flex h-3 w-3 -translate-y-1/2 items-center justify-center',
              open
                ? 'opacity-0 transition-none'
                : 'opacity-100 transition-opacity delay-200 duration-150',
            )}
          >
            {pending
              ? <Loader2 size={11} className="animate-spin text-[var(--color-text-subtle)]" />
              : <StatusDot tone={toolResultFailed(toolCall.result) ? 'danger' : 'success'} />}
          </span>
        </button>

        <AnimatePresence initial={false}>
          {open && (
            <motion.div
              initial={{ opacity: 0, x: 4 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 4 }}
              transition={{ duration: 0.16, ease: 'easeOut' }}
              className="flex flex-shrink-0 items-center gap-2 pr-2"
            >
              <div className="relative grid h-7 grid-cols-2 overflow-hidden rounded-lg bg-[var(--color-surface-recessed)]">
                <span
                  aria-hidden="true"
                  className={cn(
                    'pointer-events-none absolute inset-y-0 left-0 w-1/2 bg-[var(--color-surface-selected)] shadow-sm',
                    'transition-transform duration-[var(--motion-duration-deliberate)] ease-[var(--motion-ease-emphasized)]',
                    view === 'tool' ? 'rounded-l-md rounded-r-none' : 'translate-x-full rounded-l-none rounded-r-md',
                  )}
                />
                {(['tool', 'raw'] as const).map(option => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setView(option)}
                    className={cn(
                      'relative z-10 h-full px-2.5 text-[11px] font-medium leading-none transition-colors duration-200 focus:outline-none',
                      option === 'tool' ? 'rounded-l-md rounded-r-none' : 'rounded-l-none rounded-r-md',
                      view === option
                        ? 'text-[var(--color-text-primary)]'
                        : 'text-[var(--color-text-subtle)] hover:text-[var(--color-text-secondary)]',
                    )}
                  >
                    {option === 'tool' ? 'Tool' : 'Raw'}
                  </button>
                ))}
              </div>
              <span className="mr-1 text-[10px] font-semibold uppercase tracking-widest text-[var(--color-text-muted)] select-none">
                {pending ? 'Running' : 'Complete'}
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="tool-content"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ height: { duration: 0.24, ease: [0.22, 1, 0.36, 1] }, opacity: { duration: 0.16 } }}
            className="overflow-hidden"
          >
            <AnimatedViewHeight view={view} tool={toolView} raw={rawView} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function AnimatedViewHeight({
  view,
  tool,
  raw,
}: {
  view: 'tool' | 'raw'
  tool: ReactNode
  raw: ReactNode
}) {
  const toolRef = useRef<HTMLDivElement>(null)
  const rawRef = useRef<HTMLDivElement>(null)
  const [heights, setHeights] = useState({ tool: 0, raw: 0 })

  useLayoutEffect(() => {
    const updateHeights = () => setHeights({
      tool: toolRef.current?.getBoundingClientRect().height ?? 0,
      raw: rawRef.current?.getBoundingClientRect().height ?? 0,
    })
    updateHeights()
    const observer = new ResizeObserver(updateHeights)
    if (toolRef.current) observer.observe(toolRef.current)
    if (rawRef.current) observer.observe(rawRef.current)
    return () => observer.disconnect()
  }, [])

  const height = heights[view]

  return (
    <div
      style={height > 0 ? { height } : undefined}
      className="relative overflow-hidden bg-[var(--color-surface-panel)] transition-[height] duration-[var(--motion-duration-deliberate)] ease-[var(--motion-ease-emphasized)]"
    >
      <motion.div
        ref={toolRef}
        animate={{ opacity: view === 'tool' ? 1 : 0 }}
        transition={{ duration: view === 'tool' ? 0.12 : 0, ease: 'easeOut' }}
        style={{ visibility: view === 'tool' ? 'visible' : 'hidden' }}
        className={cn(view !== 'tool' && 'pointer-events-none absolute inset-x-0 top-0')}
        aria-hidden={view !== 'tool'}
      >
        {tool}
      </motion.div>
      <motion.div
        ref={rawRef}
        animate={{ opacity: view === 'raw' ? 1 : 0 }}
        transition={{ duration: view === 'raw' ? 0.12 : 0, ease: 'easeOut' }}
        style={{ visibility: view === 'raw' ? 'visible' : 'hidden' }}
        className={cn(view !== 'raw' && 'pointer-events-none absolute inset-x-0 top-0')}
        aria-hidden={view !== 'raw'}
      >
        {raw}
      </motion.div>
    </div>
  )
}

function ToolOutput({
  toolCall,
  displayKind,
  change,
}: {
  toolCall: ToolCallBlockType
  displayKind: string
  change: WorkspaceChange | null
}) {
  const result = toolCall.result
  if (!result) return <EmptyToolOutput />
  if (typeof result.error === 'string') {
    return <div className="bg-[var(--color-status-danger-surface)] px-3 py-2 font-mono text-[var(--color-status-danger)] whitespace-pre-wrap">error: {result.error}</div>
  }
  if ((toolCall.name === 'read_file' || toolCall.name === 'ReadFile') && typeof result.content === 'string') {
    return <ReadFileOutput result={result} />
  }
  if ((toolCall.name === 'load_skill' || toolCall.name === 'LoadSkill') && typeof result.content === 'string') {
    return <SkillOutput content={result.content} />
  }
  if (displayKind === 'silent') return <EmptyToolOutput />

  if (displayKind === 'edit') {
    const lines = change?.patch ? parseUnifiedDiff(change.patch) : legacyEditDiff(toolCall.args)
    return <DiffOutput lines={lines} />
  }

  if (displayKind === 'list' && Array.isArray(result.entries)) {
    return (
      <div className="max-h-80 overflow-auto bg-transparent px-3 py-2 font-mono text-[var(--color-text-muted)]">
        {result.entries.map((entry, index) => {
          const path = entry && typeof entry === 'object' && 'path' in entry
            ? String((entry as { path: unknown }).path)
            : JSON.stringify(entry)
          return <div key={index} className="truncate">{path}</div>
        })}
        {result.truncated === true && <div>…</div>}
      </div>
    )
  }

  const output = formatResult(result)
  if (!output) return <EmptyToolOutput />
  return (
    <pre className="max-h-96 overflow-auto bg-transparent px-3 py-2 font-mono text-[var(--color-text-muted)] whitespace-pre-wrap break-words">
      {output}
    </pre>
  )
}

function SkillOutput({ content }: { content: string }) {
  return (
    <pre className="max-h-[28rem] overflow-auto bg-transparent px-3 py-2 font-mono text-[11px] leading-5 text-[var(--color-text-muted)] whitespace-pre-wrap break-words">
      {content}
    </pre>
  )
}

function ReadFileOutput({ result }: { result: Record<string, unknown> }) {
  const start = typeof result.line_start === 'number' ? result.line_start : 1
  const lines = String(result.content).split(/\r?\n/)
  if (lines.length > 1 && lines.at(-1) === '') lines.pop()
  const numberWidth = Math.max(1, String(start + Math.max(0, lines.length - 1)).length)
  return (
    <div className="max-h-[28rem] overflow-auto bg-transparent py-2 font-mono text-[11px] leading-5">
      {lines.map((line, index) => (
        <div key={index} className="flex min-w-0 items-start">
          <span
            className="flex-shrink-0 border-r border-[var(--color-border-subtle)] px-2 text-right text-[var(--color-text-subtle)] select-none"
            style={{ width: `calc(${numberWidth}ch + 1rem)` }}
          >
            {start + index}
          </span>
          <span className="min-w-0 flex-1 px-3 text-[var(--color-text-muted)] whitespace-pre-wrap break-words">
            {line || ' '}
          </span>
        </div>
      ))}
      {result.truncated === true && (
        <div className="flex">
          <span style={{ width: `calc(${numberWidth}ch + 1rem)` }} className="flex-shrink-0 border-r border-[var(--color-border-subtle)]" />
          <span className="px-3 text-[var(--color-status-warning)]">… truncated</span>
        </div>
      )}
      </div>
  )
}

function EmptyToolOutput() {
  return <div className="px-3 py-2 text-[11px] italic text-[var(--color-text-disabled)]">No output</div>
}

function DiffOutput({ lines }: { lines: DiffLine[] }) {
  if (lines.length === 0) return <EmptyToolOutput />
  const added = lines.filter(line => line.kind === 'add').length
  const removed = lines.filter(line => line.kind === 'remove').length
  return (
    <div className="bg-transparent font-mono text-[11px] leading-5">
      <div className="flex items-center gap-2 border-b border-[var(--color-border-subtle)] px-3 py-1.5 text-[11px]">
        <span className="text-[var(--color-text-subtle)]">Git diff</span>
        <span className="ml-auto text-[var(--color-status-success)]">+{added}</span>
        <span className="text-[var(--color-status-danger)]">−{removed}</span>
      </div>
      <div className="max-h-[28rem] overflow-auto">
        {lines.map((line, index) => {
          if (line.kind === 'meta') {
            return <div key={index} className="border-y border-[var(--color-border-subtle)] bg-[var(--color-status-info-surface)] px-3 py-0.5 text-[var(--color-status-info)]">{line.text}</div>
          }
          const oldNumber = line.kind === 'add' ? '' : line.oldLine
          const newNumber = line.kind === 'remove' ? '' : line.newLine
          const marker = line.kind === 'remove' ? '−' : line.kind === 'add' ? '+' : ' '
          return (
            <div key={index} className={cn(
              'flex min-w-max',
              line.kind === 'remove' && 'bg-[var(--color-status-danger-surface)]',
              line.kind === 'add' && 'bg-[var(--color-status-success-surface)]',
            )}>
              <span className="w-10 flex-shrink-0 border-r border-[var(--color-border-subtle)] pr-2 text-right text-[var(--color-text-disabled)] select-none">{oldNumber}</span>
              <span className="w-10 flex-shrink-0 border-r border-[var(--color-border-subtle)] pr-2 text-right text-[var(--color-text-disabled)] select-none">{newNumber}</span>
              <span className={cn(
                'w-7 flex-shrink-0 text-center select-none',
                line.kind === 'remove' && 'text-[var(--color-status-danger)]',
                line.kind === 'add' && 'text-[var(--color-status-success)]',
                line.kind === 'context' && 'text-[var(--color-text-disabled)]',
              )}>{marker}</span>
              <span className={cn(
                'pr-4 whitespace-pre',
                line.kind === 'remove' && 'text-[var(--color-status-danger)]',
                line.kind === 'add' && 'text-[var(--color-status-success)]',
                line.kind === 'context' && 'text-[var(--color-text-muted)]',
              )}>{line.text}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function formatResult(result: Record<string, unknown>): string {
  if ('output' in result && typeof result.output === 'string') {
    const code = 'exit_code' in result ? Number(result.exit_code) : 0
    return (code !== 0 ? `exit ${code}\n` : '') + result.output
  }
  if ('error' in result && typeof result.error === 'string') return result.error
  return JSON.stringify(result, null, 2)
}
