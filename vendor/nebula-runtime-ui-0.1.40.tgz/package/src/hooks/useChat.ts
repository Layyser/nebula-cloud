import { useState, useCallback, useRef, useEffect } from 'react'
import { fetchChat, streamMessage, streamHookEvents, respondInput, reconnectStream, cancelChat, type ReasoningEffort, type RunInfo, type SecurityMode, type SSEEvent, type ToolDisplay } from '#nebula/lib/api'

const ALWAYS_ALLOW_KEY = 'agentic:always-allow'

function loadAlwaysAllow(): Set<string> {
  try { return new Set(JSON.parse(localStorage.getItem(ALWAYS_ALLOW_KEY) ?? '[]')) }
  catch { return new Set() }
}
function saveAlwaysAllow(s: Set<string>) {
  localStorage.setItem(ALWAYS_ALLOW_KEY, JSON.stringify([...s]))
}

// ── Content block types ───────────────────────────────────────────────────────

export interface TextBlock {
  type: 'text'
  content: string
}

export interface ThinkingBlock {
  type: 'thinking'
  content: string
}

export interface ToolCallBlock {
  type: 'tool_call'
  id?: string
  itemId?: string
  name: string
  args: Record<string, unknown>
  result?: Record<string, unknown>
  display?: ToolDisplay
}

export type ContentBlock = TextBlock | ThinkingBlock | ToolCallBlock

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'event'
  hook?: string
  trigger?: string
  blocks: ContentBlock[]
  streaming?: boolean
  stopped?: boolean
  createdAtMs?: number
  completedAtMs?: number
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function uid() { return Math.random().toString(36).slice(2) }

function appendToLastOfType<T extends ContentBlock>(
  blocks: ContentBlock[],
  type: T['type'],
  extra: string,
  make: () => T,
): ContentBlock[] {
  const copy = [...blocks]
  const last = copy[copy.length - 1]
  if (last?.type === type) {
    copy[copy.length - 1] = { ...last, content: (last as TextBlock | ThinkingBlock).content + extra } as T
  } else {
    copy.push(make())
  }
  return copy
}

function applyContentEvent(blocks: ContentBlock[], event: SSEEvent): ContentBlock[] {
  switch (event.type) {
    case 'text':
      return appendToLastOfType<TextBlock>(blocks, 'text', event.content, () => ({ type: 'text', content: event.content }))
    case 'thinking':
      return appendToLastOfType<ThinkingBlock>(blocks, 'thinking', event.content, () => ({ type: 'thinking', content: event.content }))
    case 'tool_call':
      return [...blocks, {
        type: 'tool_call', id: event.id, itemId: event.item_id,
        name: event.name, args: event.args, display: event.display,
      }]
    case 'tool_result': {
      const copy = [...blocks]
      const idx = [...copy].reverse().findIndex(
        b => b.type === 'tool_call' && !(b as ToolCallBlock).result &&
          (event.id ? (b as ToolCallBlock).id === event.id : (b as ToolCallBlock).name === event.name)
      )
      if (idx !== -1) {
        const ri = copy.length - 1 - idx
        copy[ri] = { ...copy[ri], result: event.result, display: event.display ?? (copy[ri] as ToolCallBlock).display } as ToolCallBlock
      }
      return copy
    }
    default: return blocks
  }
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export interface PendingInput {
  id: string
  prompt: string
  options: string[]
}

function hasInputDetails(run: RunInfo | null | undefined): boolean {
  return Boolean(run && run.status === 'needs_input' &&
    (run.input_prompt || run.input_options.length > 0))
}

export function useChat(chatName: string | null, activeRun: RunInfo | null = null) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [loading, setLoading]   = useState(false)
  const [streaming, setStreaming] = useState(false)
  const [pendingInput, setPendingInput] = useState<PendingInput | null>(null)
  const abortRef        = useRef<(() => void) | null>(null)
  const chatNameRef     = useRef<string | null>(chatName)
  const hookMsgRef      = useRef<string | null>(null)
  const streamingForRef = useRef<string | null>(null)
  const activeAssistantIdRef = useRef<string | null>(null)
  const activeRunRef = useRef<RunInfo | null>(activeRun)

  // Keep ref in sync on every render — synchronous assignment so the guard
  // `chatNameRef.current !== name` in stream callbacks is always up to date,
  // even for chunks that arrive between React's commit and useEffect execution.
  chatNameRef.current = chatName
  activeRunRef.current = activeRun

  useEffect(() => {
    if (!chatName || !activeRun) {
      setPendingInput(null)
      if (!activeRun && streamingForRef.current !== chatName) setStreaming(false)
      return
    }

    setStreaming(true)
    if (!hasInputDetails(activeRun)) {
      setPendingInput(null)
      return
    }

    setPendingInput(prev => {
      if (prev && prev.prompt === activeRun.input_prompt &&
          prev.options.join('\u0000') === activeRun.input_options.join('\u0000'))
        return prev
      return {
        id: activeRun.id,
        prompt: activeRun.input_prompt,
        options: activeRun.input_options,
      }
    })
  }, [chatName, activeRun?.id, activeRun?.status, activeRun?.input_prompt, activeRun?.input_options])

  const handleUserInput = useCallback((name: string, event: Extract<SSEEvent, { type: 'user_input' }>) => {
    const always = loadAlwaysAllow()
    if (always.has(event.prompt)) {
      void respondInput(name, event.id, 0).catch(() => {})
    } else {
      setPendingInput({
        id: event.id,
        prompt: event.prompt,
        options: event.options,
      })
    }
  }, [])

  // Abort any in-flight stream when the user switches to a different chat.
  // Exception: new-chat creation calls send(text, name) and setActiveChat(name)
  // together, so streamingForRef === chatName by the time this effect runs.
  useEffect(() => {
    if (abortRef.current && streamingForRef.current !== chatName) {
      abortRef.current()
      abortRef.current        = null
      streamingForRef.current = null
      setStreaming(false)
      setPendingInput(null)
      // Clear the streaming flag from the stale assistant message so the
      // fetch effect's `prev.some(m => m.streaming)` guard doesn't block
      // loading the new chat's history.
      setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false } : m))
    }
  }, [chatName])

  useEffect(() => {
    // Don't wipe messages if a stream is already in flight (new-chat creation
    // sends the first message before the chatName effect fires).
    setMessages(prev => prev.some(m => m.streaming) ? prev : [])
    if (!chatName) return
    setLoading(true)

    let cancelled = false

    fetchChat(chatName)
      .then(msgs => {
        if (cancelled) return
        setMessages(prev => {
          if (prev.some(m => m.streaming)) return prev
          // Merge standalone {role:"thinking"} entries into the following assistant message.
          const merged: typeof msgs = []
          for (let i = 0; i < msgs.length; i++) {
            if (msgs[i].role === 'thinking' && i + 1 < msgs.length && msgs[i + 1].role === 'assistant') {
              merged.push({ ...msgs[i + 1], thinking: msgs[i].content })
              i++
            } else if (msgs[i].role !== 'thinking') {
              merged.push(msgs[i])
            }
          }
          return merged.map(m => {
            const blocks: ContentBlock[] = []
            if (m.role === 'event') {
              const stripped = m.content?.replace(/^\[Event:[^\]]*\]\s*/, '').trim()
              if (stripped) blocks.push({ type: 'text', content: stripped })
            } else {
              if (m.thinking) blocks.push({ type: 'thinking', content: m.thinking })
              if (m.content)  blocks.push({ type: 'text',     content: m.content })
            }
            m.tool_calls?.forEach(tc => blocks.push({
              type:   'tool_call',
              id:     tc.id,
              itemId: tc.item_id,
              name:   tc.name,
              args:   tc.args,
              result: tc.result,
              display: tc.display,
            }))
            const role = m.role === 'assistant' ? 'assistant' : m.role === 'event' ? 'event' : 'user'
            return {
              id: uid(), role, hook: m.hook, stopped: m.stopped, blocks,
              createdAtMs: m.created_at_ms,
              completedAtMs: m.completed_at_ms,
            }
          })
        })

        // send() already owns the stream for this chat (new-chat creation calls
        // setActiveChat + send together, so streamingForRef is set before this
        // .then fires). Opening a second reader would duplicate events.
        if (streamingForRef.current === chatName) return

        // Attempt to reconnect to a still-running turn for this chat.
        // The backend replays all events from the beginning so we can rebuild
        // the assistant message even if we switched away mid-stream.
        const assistantId = uid()
        let gotFirstEvent = false

        const abort = reconnectStream(
          chatName,
          (event) => {
            if (chatNameRef.current !== chatName) return
            if (event.type === 'user_input') {
              if (hasInputDetails(activeRunRef.current))
                handleUserInput(chatName, event)
              return
            }
            if (!gotFirstEvent) {
              gotFirstEvent = true
              streamingForRef.current = chatName
              setStreaming(true)
              setMessages(prev => [...prev, {
                id: assistantId,
                role: 'assistant',
                blocks: [],
                streaming: true,
                createdAtMs: activeRunRef.current?.started_at_ms ?? Date.now(),
              }])
              activeAssistantIdRef.current = assistantId
            }
            if (event.type === 'status' && event.status === 'stopped') {
              setMessages(prev => prev.map(m => m.id === assistantId
                ? { ...m, streaming: false, stopped: true, completedAtMs: Date.now() }
                : m))
              setStreaming(false)
              return
            }
            setMessages(prev => prev.map(m =>
              m.id !== assistantId ? m : { ...m, blocks: applyContentEvent(m.blocks, event) }
            ))
          },
          () => { // onDone
            if (chatNameRef.current !== chatName) return
            setMessages(prev => prev.map(m => m.id === assistantId
              ? { ...m, streaming: false, completedAtMs: Date.now() }
              : m))
            setStreaming(false)
            streamingForRef.current = null
            abortRef.current = null
          },
          () => { // onNotFound — no active turn
            if (chatNameRef.current !== chatName) return
            // reconnectStream also uses this callback when its SSE request
            // drops. If it had already replayed an event, leaving these refs
            // intact permanently disables the composer: the active-run effect
            // deliberately refuses to clear a stream owned by this chat.
            if (gotFirstEvent) {
              setMessages(prev => prev.map(m => m.id === assistantId
                ? { ...m, streaming: false, completedAtMs: Date.now() }
                : m))
            }
            streamingForRef.current = null
            setPendingInput(null)
            setStreaming(Boolean(activeRunRef.current))
            abortRef.current = null
          },
        )

        if (cancelled) {
          abort()
        } else {
          abortRef.current = abort
        }
      })
      .catch(() => { if (!cancelled) setMessages(prev => prev.some(m => m.streaming) ? prev : []) })
      .finally(() => { if (!cancelled) setLoading(false) })

    return () => { cancelled = true }
  }, [chatName, handleUserInput])

  useEffect(() => {
    if (!chatName) return
    hookMsgRef.current = null
    const abort = streamHookEvents(chatName, (event) => {
      if (chatNameRef.current !== chatName) return
      if (event.type === 'hook_start') {
        const existingId = hookMsgRef.current
        if (existingId) {
          // SSE reconnected mid-hook: content arrived before hook_start, so the
          // fallback message has no hook name yet — backfill it now.
          setMessages(prev => prev.map(m => m.id === existingId ? { ...m, hook: event.hook, trigger: event.trigger } : m))
        } else {
          const id = uid()
          hookMsgRef.current = id
          setMessages(prev => [...prev, { id, role: 'event', hook: event.hook, trigger: event.trigger, blocks: [], streaming: true }])
        }
        return
      }
      if (event.type === 'hook_end') {
        const id = hookMsgRef.current
        hookMsgRef.current = null
        if (id) setMessages(prev => prev.map(m => m.id === id ? { ...m, streaming: false } : m))
        return
      }
      if (!hookMsgRef.current) {
        const id = uid()
        hookMsgRef.current = id
        setMessages(prev => [...prev, { id, role: 'event', blocks: [], streaming: true }])
      }
      const id = hookMsgRef.current
      setMessages(prev => prev.map(m => m.id !== id ? m : { ...m, blocks: applyContentEvent(m.blocks, event as SSEEvent) }))
    }, () => {})
    return () => { hookMsgRef.current = null; abort() }
  }, [chatName])

  const send = useCallback(async (text: string, targetName?: string, targetAgent?: string, securityMode?: SecurityMode, reasoningEffort?: ReasoningEffort, model?: string) => {
    const name = targetName ?? chatName
    if (!name || streaming) return

    const startedAtMs = Date.now()
    const userMsg: ChatMessage = {
      id: uid(), role: 'user', blocks: [{ type: 'text', content: text }],
      createdAtMs: startedAtMs,
    }
    const assistantId = uid()
    const assistantMsg: ChatMessage = {
      id: assistantId, role: 'assistant', blocks: [], streaming: true,
      createdAtMs: startedAtMs,
    }

    setMessages(prev => [...prev, userMsg, assistantMsg])
    setStreaming(true)
    streamingForRef.current = name
    activeAssistantIdRef.current = assistantId

    abortRef.current = streamMessage(
      name,
      text,
      (event: SSEEvent) => {
        if (chatNameRef.current !== name) return  // switched away — drop stale event
        // user_input doesn't touch message state — handled separately.
        if (event.type === 'user_input') {
          handleUserInput(name, event)
          return
        }

        if (event.type === 'status' && event.status === 'stopped') {
          setMessages(prev => prev.map(m => m.id === assistantId
            ? { ...m, streaming: false, stopped: true, completedAtMs: Date.now() }
            : m))
          setPendingInput(null)
          setStreaming(false)
          streamingForRef.current = null
          abortRef.current = null
          return
        }

        setMessages(prev => prev.map(m => {
          if (m.id !== assistantId) return m
          return { ...m, blocks: applyContentEvent(m.blocks, event) }
        }))
      },
      () => {
        if (chatNameRef.current !== name) return  // switched away — don't touch state
        streamingForRef.current = null
        setMessages(prev => prev.map(m => m.id === assistantId
          ? { ...m, streaming: false, completedAtMs: Date.now() }
          : m))
        setPendingInput(null)
        setStreaming(false)
        abortRef.current = null
      },
      () => {
        if (chatNameRef.current !== name) return  // switched away — don't touch state
        streamingForRef.current = null
        setMessages(prev => prev.map(m => {
          if (m.id !== assistantId) return m
          const hasText = m.blocks.some(b => b.type === 'text' && (b as TextBlock).content)
          return {
            ...m,
            streaming: false,
            completedAtMs: Date.now(),
            blocks: hasText ? m.blocks : [...m.blocks, { type: 'text', content: '[Error]' }],
          }
        }))
        setPendingInput(null)
        setStreaming(false)
        abortRef.current = null
      },
      targetAgent,
      securityMode,
      reasoningEffort,
      model,
    )
  }, [chatName, streaming, handleUserInput])

  const abort = useCallback(() => {
    const name = chatNameRef.current
    if (!name || !streamingForRef.current) return
    void cancelChat(name).catch(() => {})
    abortRef.current?.()
    abortRef.current = null
    streamingForRef.current = null
    setPendingInput(null)
    setStreaming(false)
    const assistantId = activeAssistantIdRef.current
    if (assistantId) {
      setMessages(prev => prev.map(m => m.id === assistantId
        ? {
            ...m,
            streaming: false,
            stopped: true,
            completedAtMs: Date.now(),
            blocks: m.blocks.map(block =>
              block.type === 'tool_call' && block.result === undefined
                ? { ...block, result: { error: 'Stopped by user' } }
                : block,
            ),
          }
        : m))
    }
  }, [])

  // respond(choice) — 0-based option index, -1 to cancel.
  // always=true saves the prompt to localStorage for auto-approval next time.
  const respond = useCallback(async (choice: number, always = false) => {
    const name = chatNameRef.current
    const pending = pendingInput
    if (!name || !pending) return
    if (always && choice === 0) {
      const s = loadAlwaysAllow()
      s.add(pending.prompt)
      saveAlwaysAllow(s)
    }
    setPendingInput(null)
    await respondInput(name, pending.id, choice)
  }, [pendingInput])

  return { messages, loading, streaming, pendingInput, send, abort, respond }
}
