import { useState, useEffect, useCallback, useRef } from 'react'
import {
  fetchChats,
  deleteChat,
  setChatHooksPaused,
  streamRunStatus,
  type ChatSession,
} from '#nebula/lib/api'

export function useChats() {
  const [chats, setChats] = useState<ChatSession[]>([])
  const [loading, setLoading] = useState(true)
  const deletedChats = useRef(new Set<string>())

  const refresh = useCallback(async () => {
    try {
      const list = await fetchChats()
      setChats(previous => {
        const previousByName = new Map(previous.map(chat => [chat.name, chat]))
        return list
          .filter(chat => !deletedChats.current.has(chat.name))
          .map(chat => {
            const current = previousByName.get(chat.name)
            // A refresh can have started before a streamed title event was
            // persisted. Keep an optimistic "New chat" label or a streamed
            // title instead of replacing either with the generated chat ID.
            const fetchedHasFallbackTitle = !chat.display_name || chat.display_name === chat.name
            const currentHasPreferredTitle = current && current.display_name !== current.name
            return fetchedHasFallbackTitle && currentHasPreferredTitle
              ? { ...chat, display_name: current.display_name }
              : chat
          })
      })
    } catch {
      // Keep the last known sidebar on transient backend/network failures.
      // Clearing it makes sessions appear to move or disappear unexpectedly.
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { refresh() }, [refresh])

  useEffect(() => {
    const stop = streamRunStatus((event) => {
      if (event.type === 'run_snapshot') {
        const runs = new Map(event.runs.map(run => [run.chat, run]))
        setChats(prev => prev.map(chat => ({
          ...chat,
          run: runs.get(chat.name) ?? null,
        })))
        return
      }

      if (event.type === 'chat_title') {
        setChats(prev => prev.map(chat =>
          chat.name === event.chat
            ? { ...chat, display_name: event.display_name }
            : chat,
        ))
        return
      }

      const { action, run } = event
      setChats(prev => prev.map(chat =>
        chat.name === run.chat
          ? { ...chat, run: action === 'finished' ? null : run }
          : chat,
      ))

      // A subagent can be created while the sidebar is open. Refresh only for
      // lifecycle events so the new tree node and updated metadata appear,
      // while ordinary status transitions remain entirely push-driven.
      if (action === 'started' || action === 'finished') void refresh()
    }, () => {})
    return stop
  }, [refresh])

  const remove = useCallback(async (name: string) => {
    deletedChats.current.add(name)
    setChats(prev => prev.filter(c => c.name !== name))
    try {
      await deleteChat(name)
      // Recompute sibling/tree metadata so a new last child gets the └ marker.
      await refresh()
    } catch (error) {
      deletedChats.current.delete(name)
      await refresh()
      throw error
    }
  }, [refresh])

  const removeMany = useCallback(async (names: string[]) => {
    if (names.length === 0) return
    names.forEach(name => deletedChats.current.add(name))
    const deleting = new Set(names)
    setChats(prev => prev.filter(chat => !deleting.has(chat.name)))
    try {
      await Promise.all(names.map(deleteChat))
      await refresh()
    } catch (error) {
      names.forEach(name => deletedChats.current.delete(name))
      await refresh()
      throw error
    }
  }, [refresh])

  const add = useCallback((
    name: string,
    agent?: string,
    session?: Pick<ChatSession, 'cwd' | 'workspace_root' | 'cwd_updated_at_ms'>,
  ) => {
    deletedChats.current.delete(name)
    setChats(prev => {
      const idx = prev.findIndex(c => c.name === name)
      if (idx !== -1) {
        const updated = [...prev]
        updated[idx] = {
          ...updated[idx],
          ...(agent ? { agent } : {}),
          ...session,
        }
        return updated
      }
      return [{ name, ...(agent ? { agent } : {}), ...session }, ...prev]
    })
  }, [])

  const toggleHooks = useCallback(async (name: string, paused: boolean) => {
    await setChatHooksPaused(name, paused)
    setChats(prev => prev.map(chat =>
      chat.name === name ? { ...chat, hooks_paused: paused } : chat,
    ))
  }, [])

  return { chats, loading, refresh, remove, removeMany, add, toggleHooks }
}
