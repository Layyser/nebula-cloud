import { invoke, isTauri } from '@tauri-apps/api/core'
import { createLocalRuntimeTransport, type RuntimeTransport } from './transport'

interface DesktopRuntimeConfig {
  origin: string
  token: string
  workspace: string
}

let devtoolsShortcutConfigured = false

function installDevtoolsShortcut() {
  if (devtoolsShortcutConfigured) return
  devtoolsShortcutConfigured = true
  window.addEventListener('keydown', event => {
    const toggle = event.key === 'F12' ||
      (event.ctrlKey && event.shiftKey && event.key.toLowerCase() === 'i')
    if (!toggle) return
    event.preventDefault()
    void invoke('toggle_devtools')
  })
}

export async function configureDesktopRuntime(): Promise<RuntimeTransport | null> {
  const hasTauriInternals = '__TAURI_INTERNALS__' in globalThis
  if (!isTauri() && !hasTauriInternals) return null
  installDevtoolsShortcut()

  try {
    const config = await invoke<DesktopRuntimeConfig>('runtime_config')
    return createLocalRuntimeTransport({ origin: config.origin, token: config.token })
  } catch (error) {
    console.error('[nebula] desktop runtime failed to start', error)
    return null
  }
}
