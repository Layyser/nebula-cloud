/// <reference types="vite/client" />

export { default as RuntimeWorkspace } from '#nebula/components/workspace/WorkspaceApp'
export type { RuntimeNavigationItem, RuntimeWorkspaceProps, RuntimeWorkspaceView } from '#nebula/components/workspace/WorkspaceApp'
export { ProviderSettings } from '#nebula/components/workspace/ProviderSettings'
export type { ProviderSettingsProps } from '#nebula/components/workspace/ProviderSettings'
export { AppearanceSettings } from '#nebula/components/workspace/AppearanceSettings'
export { SettingsShell } from '#nebula/components/workspace/SettingsShell'
export type { SettingsSection, SettingsShellProps } from '#nebula/components/workspace/SettingsShell'
export { NebulaMark } from '#nebula/components/ui/NebulaMark'
export { NebulaBackground } from '#nebula/components/shader/NebulaBackground'
export { Button, IconButton, LinkButton } from '#nebula/components/ui/button'
export { Badge, StatusBadge, StatusDot } from '#nebula/components/ui/badge'
export type { BadgeProps, StatusBadgeProps, StatusDotProps } from '#nebula/components/ui/badge'
export { Checkbox, Field, FormMessage, Input, Textarea } from '#nebula/components/ui/form'
export type { CheckboxProps, FieldProps, FormMessageProps, InputProps, TextareaProps } from '#nebula/components/ui/form'
export { EmptyState, LoadingState, Spinner } from '#nebula/components/ui/state'
export type { EmptyStateProps, LoadingStateProps, SpinnerProps } from '#nebula/components/ui/state'
export { CapabilityCountChip, MetadataChip } from '#nebula/components/ui/metadata-chip'
export type { CapabilityCountChipProps, MetadataChipProps } from '#nebula/components/ui/metadata-chip'
export { ContentContainer, PageHeader } from '#nebula/components/ui/layout'
export { ScrollArea } from '#nebula/components/ui/scroll-area'
export type { ScrollAreaProps } from '#nebula/components/ui/scroll-area'
export { Card, Surface } from '#nebula/components/ui/surface'
export { WorkspaceCard } from '#nebula/components/ui/workspace-card'
export type { WorkspaceCardProps } from '#nebula/components/ui/workspace-card'
export { Tabs, TabsContent, TabsList, TabsTrigger } from '#nebula/components/ui/tabs'
export { SegmentedControl } from '#nebula/components/ui/segmented-control'
export type { SegmentedControlProps, SegmentedOption } from '#nebula/components/ui/segmented-control'
export { ContextSelect } from '#nebula/components/ui/context-select'
export type { ContextSelectOption } from '#nebula/components/ui/context-select'
export { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '#nebula/components/ui/tooltip'
export {
  applyTheme,
  getThemePreference,
  initializeTheme,
  resolveTheme,
  setThemePreference,
  useThemePreference,
} from '#nebula/theme/theme'
export type { ResolvedTheme, ThemePreference } from '#nebula/theme/theme'
export { createHttpRuntimeTransport, createLocalRuntimeTransport } from '#nebula/runtime/transport'
export type {
  HttpRuntimeTransportOptions,
  LocalRuntimeTransportOptions,
  RuntimeReconnectOptions,
  RuntimeStreamCallbacks,
  RuntimeStreamOptions,
  RuntimeSubscription,
  RuntimeTransport,
} from '#nebula/runtime/transport'

export type {
  AgentInfo,
  CapabilityCatalog,
  ChatSession,
  McpInfo,
  ModelInfo,
  ReasoningEffort,
  ReasoningEffortChoice,
  SecurityMode,
  SessionInfo,
} from '#nebula/lib/api'
