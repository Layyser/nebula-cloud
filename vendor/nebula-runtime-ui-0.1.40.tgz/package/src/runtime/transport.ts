export interface RuntimeStreamCallbacks<T> {
  onEvent: (event: T) => void
  onDone?: () => void
  onError: (error: Error) => void
}

export interface RuntimeStreamOptions<T> extends RuntimeStreamCallbacks<T> {
  init?: RequestInit
  /** Treat these statuses as a completed stream without trying to read a body. */
  completeStatuses?: readonly number[]
  onCompleteStatus?: (status: number) => void
}

export interface RuntimeReconnectOptions<T> extends RuntimeStreamCallbacks<T> {
  init?: RequestInit
  retryDelayMs?: number
  maxRetryDelayMs?: number
  retryBackoffFactor?: number
}

export interface RuntimeSubscription {
  cancel(): void
}

/**
 * Organization-neutral boundary between the shared runtime UI and Nebula.
 *
 * Implementations may talk directly to a local daemon, proxy through a cloud
 * gateway, or use an in-memory test double. Runtime components never need to
 * know the runtime's host, credentials, or routing scheme.
 */
export interface RuntimeTransport {
  request(path: string, init?: RequestInit): Promise<Response>
  stream<T>(path: string, options: RuntimeStreamOptions<T>): RuntimeSubscription
  reconnectingStream<T>(path: string, options: RuntimeReconnectOptions<T>): RuntimeSubscription
}

export interface HttpRuntimeTransportOptions {
  headers?: HeadersInit
  credentials?: RequestCredentials
  fetch?: typeof globalThis.fetch
}

export interface LocalRuntimeTransportOptions {
  origin?: string
  token?: string
  fetch?: typeof globalThis.fetch
}

function runtimeError(error: unknown): Error {
  return error instanceof Error ? error : new Error(String(error))
}

function joinUrl(baseUrl: string, path: string): string {
  const base = baseUrl.replace(/\/$/, '')
  const suffix = path.startsWith('/') ? path : `/${path}`
  return `${base}${suffix}`
}

async function consumeSse<T>(
  response: Response,
  onEvent: (event: T) => void,
): Promise<void> {
  if (!response.ok || !response.body) throw new Error(`HTTP ${response.status}`)

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  const consumeLine = (line: string): boolean => {
    if (!line.startsWith('data: ')) return false
    const payload = line.slice(6).trim()
    if (payload === '[DONE]') return true
    if (!payload) return false
    try { onEvent(JSON.parse(payload) as T) } catch { /* ignore malformed events */ }
    return false
  }

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() ?? ''
    for (const line of lines) {
      if (consumeLine(line)) {
        await reader.cancel()
        return
      }
    }
  }

  buffer += decoder.decode()
  if (buffer) consumeLine(buffer)
}

export function createHttpRuntimeTransport(
  baseUrl = '/api',
  defaults: HttpRuntimeTransportOptions = {},
): RuntimeTransport {
  const request = (path: string, init?: RequestInit) => {
    const headers = new Headers(defaults.headers)
    new Headers(init?.headers).forEach((value, key) => headers.set(key, value))
    return (defaults.fetch ?? globalThis.fetch)(joinUrl(baseUrl, path), {
      credentials: defaults.credentials,
      ...init,
      headers,
    })
  }

  const stream = <T>(path: string, options: RuntimeStreamOptions<T>): RuntimeSubscription => {
    const controller = new AbortController()
    request(path, { ...options.init, signal: controller.signal })
      .then(async response => {
        if (options.completeStatuses?.includes(response.status)) {
          options.onCompleteStatus?.(response.status)
          return
        }
        await consumeSse(response, options.onEvent)
        options.onDone?.()
      })
      .catch(error => {
        if (!controller.signal.aborted) options.onError(runtimeError(error))
      })
    return { cancel: () => controller.abort() }
  }

  const reconnectingStream = <T>(
    path: string,
    options: RuntimeReconnectOptions<T>,
  ): RuntimeSubscription => {
    let cancelled = false
    let active: RuntimeSubscription | null = null
    let retryTimer: ReturnType<typeof setTimeout> | null = null
    let failedAttempts = 0

    const scheduleReconnect = (failed: boolean) => {
      if (cancelled || retryTimer !== null) return
      if (failed) failedAttempts += 1
      const initialDelay = options.retryDelayMs ?? 1000
      const maximumDelay = options.maxRetryDelayMs ?? 30000
      const backoffFactor = options.retryBackoffFactor ?? 2
      const retryDelay = failed
        ? Math.min(
            maximumDelay,
            initialDelay * Math.pow(backoffFactor, Math.max(0, failedAttempts - 1)),
          )
        : initialDelay
      retryTimer = setTimeout(() => {
        retryTimer = null
        connect()
      }, retryDelay)
    }

    const connect = () => {
      if (cancelled) return
      active = stream<T>(path, {
        init: options.init,
        onEvent: event => {
          failedAttempts = 0
          options.onEvent(event)
        },
        onDone: () => {
          options.onDone?.()
          scheduleReconnect(false)
        },
        onError: error => {
          options.onError(error)
          scheduleReconnect(true)
        },
      })
    }

    connect()
    return {
      cancel: () => {
        cancelled = true
        active?.cancel()
        if (retryTimer !== null) clearTimeout(retryTimer)
      },
    }
  }

  return { request, stream, reconnectingStream }
}

/** Transport used by standalone browser and desktop shells. */
export function createLocalRuntimeTransport(
  options: LocalRuntimeTransportOptions = {},
): RuntimeTransport {
  return createHttpRuntimeTransport(options.origin ?? '/api', {
    headers: options.token
      ? { Authorization: `Bearer ${options.token}` }
      : undefined,
    fetch: options.fetch,
  })
}
