import type {
  AgentInfo,
  CapabilityCatalog,
  ChatSession,
  McpInfo,
  Message,
  ModelCatalog,
  RunStatusEvent,
  SSEEvent,
  SessionInfo,
} from '#nebula/lib/api'
import type {
  RuntimeReconnectOptions,
  RuntimeStreamOptions,
  RuntimeSubscription,
  RuntimeTransport,
} from '#nebula/runtime/transport'

const previewChat = 'preview-design-system'

export const mockRuntimePreviewModes = [
  'workspace',
  'session',
  'empty',
  'unavailable',
  'agents',
  'capabilities',
  'settings',
  'dialog',
] as const

export type MockRuntimePreviewMode = typeof mockRuntimePreviewModes[number]

export interface MockRuntimePreview {
  transport: RuntimeTransport
  workspaceProps: {
    initialView?: 'sessions' | 'agents' | 'connections'
    initialChat?: string | null
    initialAgentBuilder?: boolean
    initialDeleteChat?: string | null
  }
}

export const mockRuntimePreviewViewports = {
  mobile: { width: 375, height: 812 },
  narrow: { width: 768, height: 1024 },
  desktop: { width: 1280, height: 800 },
} as const

export const mockRuntimeBaselineScenarios = [
  { id: 'default-workspace', mode: 'workspace', viewport: 'desktop' },
  { id: 'populated-session', mode: 'session', viewport: 'desktop' },
  { id: 'empty-workspace', mode: 'empty', viewport: 'desktop' },
  { id: 'runtime-unavailable', mode: 'unavailable', viewport: 'desktop' },
  { id: 'agent-settings', mode: 'settings', viewport: 'desktop' },
  { id: 'delete-dialog', mode: 'dialog', viewport: 'desktop' },
  { id: 'narrow-workspace', mode: 'workspace', viewport: 'narrow' },
  { id: 'mobile-workspace', mode: 'workspace', viewport: 'mobile' },
] as const satisfies ReadonlyArray<{
  id: string
  mode: MockRuntimePreviewMode
  viewport: keyof typeof mockRuntimePreviewViewports
}>

export function isMockRuntimePreviewMode(value: string | null): value is MockRuntimePreviewMode {
  return value !== null && mockRuntimePreviewModes.includes(value as MockRuntimePreviewMode)
}

const chats: ChatSession[] = [
  {
    name: previewChat,
    display_name: 'Refine the design system',
    agent: 'Frontend',
    cwd: '/workspace/nebula-frontend',
    workspace_root: '/workspace',
    has_hooks: true,
  },
  {
    name: 'preview-runtime-api',
    display_name: 'Document the Runtime API',
    agent: 'Default',
    cwd: '/workspace/nebula-agent',
    workspace_root: '/workspace',
  },
]

const agents: AgentInfo[] = [
  {
    name: 'Frontend',
    description: 'Builds and reviews Nebula product interfaces.',
    model: 'gpt-5.2-codex',
    reasoning_effort: 'medium',
    skills: ['frontend-design'],
    mcp: ['github'],
  },
  {
    name: 'Runtime',
    description: 'Works on the local C++ runtime and HTTP API.',
    model: 'gpt-5.2-codex',
    reasoning_effort: 'high',
  },
]

const mcps: McpInfo[] = [
  {
    name: 'github',
    description: 'Repository issues, pull requests, and source context.',
    transport: 'http',
    url: 'https://api.githubcopilot.com/mcp',
    excluded_by_default: false,
    loaded: true,
    tools: 12,
  },
]

const models: ModelCatalog = {
  default_model: 'gpt-5.2-codex',
  models: [
    { slug: 'gpt-5.2-codex', display_name: 'GPT-5.2 Codex' },
    { slug: 'gpt-5.1-codex-mini', display_name: 'GPT-5.1 Codex mini' },
  ],
}

const capabilities: CapabilityCatalog = {
  mcps,
  skills: [
    {
      name: 'frontend-design',
      description: 'Product UI implementation and review guidance.',
      content: '# Frontend design',
      scope: 'workspace',
    },
  ],
  commands: [],
  hooks: [
    {
      name: 'design-review',
      event: 'webhook',
      prompt: 'Review the latest interface change.',
    },
  ],
  rules: [],
  tools: [
    { name: 'shell', description: 'Run commands in the operator workspace.' },
  ],
}

const session: SessionInfo = {
  chat: previewChat,
  agent: 'Frontend',
  model: models.default_model,
  reasoning_effort: 'medium',
  security_mode: 'default',
  workspace_root: '/workspace',
  cwd: '/workspace/nebula-frontend',
  mcp: ['github'],
  skills: ['frontend-design'],
}

const messages: Message[] = [
  {
    role: 'user',
    content: 'Audit the workspace controls and propose the first production patch.',
    created_at_ms: 1_770_000_000_000,
  },
  {
    role: 'assistant',
    content: 'I mapped the duplicated controls and prepared a token-first migration order.',
    tool_calls: [
      {
        id: 'preview-tool-call',
        name: 'shell',
        args: { command: 'bun test' },
        result: { exit_code: 0, output: '42 pass\n0 fail' },
        display: {
          label: 'Run tests',
          primary: 'bun test',
          kind: 'command',
        },
      },
    ],
    created_at_ms: 1_770_000_002_000,
    completed_at_ms: 1_770_000_006_000,
  },
]

function json(data: unknown, init?: ResponseInit): Response {
  return Response.json(data, init)
}

function normalizedPath(path: string): string {
  return new URL(path, 'https://preview.nebula.local').pathname
}

function createSubscription(run: () => void): RuntimeSubscription {
  let cancelled = false
  queueMicrotask(() => {
    if (!cancelled) run()
  })
  return { cancel: () => { cancelled = true } }
}

function sessionFor(chat: string): SessionInfo {
  return { ...session, chat }
}

/**
 * Deterministic, backend-free transport for development previews and visual tests.
 * It mounts the real RuntimeWorkspace; it is not a parallel demo application.
 */
export function createMockRuntimeTransport(mode: MockRuntimePreviewMode = 'workspace'): RuntimeTransport {
  const request = async (path: string, init?: RequestInit): Promise<Response> => {
    const route = normalizedPath(path)
    const method = init?.method?.toUpperCase() ?? 'GET'

    if (route === '/health' || route === '/health/ready') {
      return mode === 'unavailable'
        ? json({ ok: false }, { status: 503 })
        : json({ ok: true })
    }
    if (route === '/chats') return json({ chats: mode === 'empty' ? [] : chats })
    if (route === '/agents') return json({
      default: {
        name: 'Default',
        description: 'General-purpose local operator.',
        model: models.default_model,
        reasoning_effort: 'medium',
        is_default: true,
      },
      agents,
    })
    if (route === '/mcps') return json({ mcps })
    if (route === '/models') return json(models)
    if (route === '/capabilities') return json(capabilities)

    const sessionMatch = route.match(/^\/chat\/([^/]+)\/session$/)
    if (sessionMatch) return json(sessionFor(decodeURIComponent(sessionMatch[1])))

    const chatMatch = route.match(/^\/chat\/([^/]+)$/)
    if (chatMatch && method === 'GET') {
      return json({
        messages: decodeURIComponent(chatMatch[1]) === previewChat ? messages : [],
      })
    }

    if (route.startsWith('/chat/') && method !== 'GET') {
      const chat = decodeURIComponent(route.split('/')[2] ?? previewChat)
      return json(sessionFor(chat))
    }

    if (method === 'DELETE' || method === 'PUT' || method === 'POST') {
      return json({ ok: true })
    }

    return json({ error: `No preview fixture for ${method} ${route}` }, { status: 404 })
  }

  const stream = <T>(path: string, options: RuntimeStreamOptions<T>): RuntimeSubscription => {
    const route = normalizedPath(path)

    if (route.endsWith('/stream')) {
      return createSubscription(() => {
        options.onCompleteStatus?.(204)
        options.onDone?.()
      })
    }

    if (route.endsWith('/events')) {
      return createSubscription(() => {})
    }

    return createSubscription(() => {
      const events: SSEEvent[] = [
        { type: 'text', content: 'Preview mode uses the real workspace with deterministic runtime data.' },
      ]
      events.forEach(event => options.onEvent(event as T))
      options.onDone?.()
    })
  }

  const reconnectingStream = <T>(
    path: string,
    options: RuntimeReconnectOptions<T>,
  ): RuntimeSubscription => {
    const route = normalizedPath(path)
    return createSubscription(() => {
      if (route === '/runs/events') {
        const snapshot: RunStatusEvent = { type: 'run_snapshot', runs: [] }
        options.onEvent(snapshot as T)
      }
    })
  }

  return { request, stream, reconnectingStream }
}

export function createMockRuntimePreview(mode: MockRuntimePreviewMode): MockRuntimePreview {
  return {
    transport: createMockRuntimeTransport(mode),
    workspaceProps: {
      initialView: mode === 'agents'
        ? 'agents'
        : mode === 'settings'
          ? 'agents'
          : mode === 'capabilities' ? 'connections' : 'sessions',
      initialChat: mode === 'session' ? previewChat : null,
      initialAgentBuilder: mode === 'settings',
      initialDeleteChat: mode === 'dialog' ? previewChat : null,
    },
  }
}

export const mockRuntimePreviewChat = previewChat
