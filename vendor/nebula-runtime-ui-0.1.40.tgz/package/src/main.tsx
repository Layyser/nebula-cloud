import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { configureDesktopRuntime } from './runtime/desktopRuntime'
import { initializeTheme } from './theme/theme'

initializeTheme()

async function start() {
  const previewMode = import.meta.env.DEV
    ? new URLSearchParams(window.location.search).get('preview')
    : null
  let preview = null
  if (previewMode) {
    const previews = await import('./runtime/mockRuntime')
    if (previews.isMockRuntimePreviewMode(previewMode)) {
      preview = previews.createMockRuntimePreview(previewMode)
    }
  }
  const transport = preview?.transport ?? await configureDesktopRuntime()
  const { default: App } = await import('./App.tsx')

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App
        transport={transport ?? undefined}
        workspaceProps={preview?.workspaceProps}
      />
    </StrictMode>,
  )
}

void start()
