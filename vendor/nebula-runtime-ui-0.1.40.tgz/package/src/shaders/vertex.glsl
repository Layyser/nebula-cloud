#version 300 es
precision highp float;

in vec3 position;
in vec3 normal;

out vec3 vNormal;
out vec3 vFragPos;

void main() {
    vNormal = normal;
    vFragPos = position;
    gl_Position = vec4(position.x, position.y, 0.0, 1.0);
}
