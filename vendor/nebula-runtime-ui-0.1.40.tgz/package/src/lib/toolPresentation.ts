import type { ToolDisplay, WorkspaceChange } from './api'

export interface DiffLine {
  kind: 'context' | 'add' | 'remove' | 'meta'
  text: string
  oldLine?: number
  newLine?: number
}

function labelFor(name: string): string {
  if (name === 'load_mcp') return 'LoadMCP'
  return name.split(/[_\-\s]+/).filter(Boolean)
    .map(part => part.charAt(0).toUpperCase() + part.slice(1)).join('') || 'Tool'
}

function stringArg(args: Record<string, unknown>, key: string): string {
  const value = args[key]
  if (value === undefined || value === null) return ''
  const rendered = typeof value === 'string' ? value : JSON.stringify(value)
  return rendered.split(/[\r\n]/, 1)[0].slice(0, 96)
}

function listTarget(args: Record<string, unknown>): string {
  const path = stringArg(args, 'path') || '.'
  const glob = stringArg(args, 'glob')
  if (!glob || glob === '*') return path
  if (path === '.') return glob
  return `${path.replace(/[\\/]$/, '')}/${glob}`
}

export function fallbackToolDisplay(
  name: string,
  args: Record<string, unknown>,
): ToolDisplay {
  let primary = ''
  if (name === 'list_files') primary = listTarget(args)
  else if (name === 'workspace_changes') {
    primary = stringArg(args, 'action')
    const id = stringArg(args, 'change_id')
    if (id) primary += `:${id}`
  }
  else if (name === 'bash') primary = stringArg(args, 'cmd')
  else if (name === 'read_file' || name === 'edit_file') primary = stringArg(args, 'path')
  else if (name === 'load_skill' || name === 'load_mcp') primary = stringArg(args, 'name')
  else {
    for (const key of ['path', 'query', 'url', 'name', 'cmd', 'pattern']) {
      primary = stringArg(args, key)
      if (primary) break
    }
  }

  let kind: ToolDisplay['kind'] = 'json'
  if (name === 'bash') kind = 'command'
  else if (name === 'edit_file') kind = 'edit'
  else if (name === 'list_files') kind = 'list'
  else if (['read_file', 'load_skill', 'load_mcp'].includes(name)) kind = 'silent'
  return { label: labelFor(name), primary, kind }
}

export function changeFromResult(result?: Record<string, unknown>): WorkspaceChange | null {
  const value = result?.change
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null
  const change = value as WorkspaceChange
  return typeof change.id === 'string' ? change : null
}

export function parseUnifiedDiff(patch: string): DiffLine[] {
  const output: DiffLine[] = []
  let oldLine = 0
  let newLine = 0
  let inHunk = false

  for (const line of patch.split('\n')) {
    const header = /^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/.exec(line)
    if (header) {
      oldLine = Number(header[1])
      newLine = Number(header[2])
      inHunk = true
      if (output.length > 0) output.push({ kind: 'meta', text: '…' })
      continue
    }
    if (!inHunk || line.startsWith('\\ No newline at end of file')) continue
    if (line.startsWith('+')) {
      output.push({ kind: 'add', text: line.slice(1), newLine: newLine++ })
    } else if (line.startsWith('-')) {
      output.push({ kind: 'remove', text: line.slice(1), oldLine: oldLine++ })
    } else if (line.startsWith(' ')) {
      output.push({ kind: 'context', text: line.slice(1), oldLine: oldLine++, newLine: newLine++ })
    }
  }
  return output
}

// Compatibility for edits saved before the backend change ledger existed.
export function legacyEditDiff(args: Record<string, unknown>): DiffLine[] {
  const oldLines = typeof args.old_text === 'string' ? args.old_text.split(/\r?\n/) : []
  const newLines = typeof args.new_text === 'string' ? args.new_text.split(/\r?\n/) : []
  if (oldLines.at(-1) === '') oldLines.pop()
  if (newLines.at(-1) === '') newLines.pop()
  const table = Array.from({ length: oldLines.length + 1 }, () =>
    Array<number>(newLines.length + 1).fill(0))
  for (let i = oldLines.length - 1; i >= 0; i--)
    for (let j = newLines.length - 1; j >= 0; j--)
      table[i][j] = oldLines[i] === newLines[j]
        ? table[i + 1][j + 1] + 1
        : Math.max(table[i + 1][j], table[i][j + 1])

  const output: DiffLine[] = []
  let i = 0, j = 0, oldLine = 1, newLine = 1
  while (i < oldLines.length || j < newLines.length) {
    if (i < oldLines.length && j < newLines.length && oldLines[i] === newLines[j]) {
      output.push({ kind: 'context', text: oldLines[i], oldLine: oldLine++, newLine: newLine++ })
      i++; j++
    } else if (j < newLines.length && (i === oldLines.length || table[i][j + 1] > table[i + 1][j])) {
      output.push({ kind: 'add', text: newLines[j++], newLine: newLine++ })
    } else {
      output.push({ kind: 'remove', text: oldLines[i++], oldLine: oldLine++ })
    }
  }
  return output
}
