import { useEffect, useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { Bot, Check, ChevronDown, ChevronsUpDown, Plus, Save, X } from 'lucide-react'
import { ScrollArea } from '#nebula/components/ui/scroll-area'
import { MultiSelect } from '#nebula/components/ui/multi-select'
import { ContextSelect } from '#nebula/components/ui/context-select'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '#nebula/components/ui/tooltip'
import { Button, IconButton } from '#nebula/components/ui/button'
import { ContentContainer, PageHeader } from '#nebula/components/ui/layout'
import { WorkspaceCard } from '#nebula/components/ui/workspace-card'
import { type CapabilityKind } from '../ui/capability-metadata'
import { CapabilityCountChip, MetadataChip } from '../ui/metadata-chip'
import { Checkbox } from '../ui/form'
import { ChatPanel } from '#nebula/components/layout/ChatPanel'
import { fetchCapabilities, type AgentInfo, type CapabilityCatalog, type McpInfo, type ModelInfo, type ReasoningEffort, type ReasoningEffortChoice, type SecurityMode, saveAgent } from '#nebula/lib/api'
import { type ChatMessage, type PendingInput } from '#nebula/hooks/useChat'
import { cn } from '#nebula/lib/utils'

interface Props {
  initialCreating?: boolean
  agents: AgentInfo[]
  mcps: McpInfo[]
  chatName: string | null
  messages: ChatMessage[]
  loading: boolean
  streaming: boolean
  pendingInput: PendingInput | null
  onSend: (text: string, files?: File[]) => void
  onAbort: () => void
  onRespond: (choice: number, always?: boolean) => void
  onRefreshAgents: () => Promise<void>
  reasoningEffort: ReasoningEffort
  reasoningEffortOverride: ReasoningEffort | null
  inheritedReasoningEffort: ReasoningEffort
  onSwitchReasoningEffort: (effort: ReasoningEffortChoice) => void
  models: ModelInfo[]
  model: string
  modelOverride: string | null
  inheritedModel: string
  onSwitchModel: (model: string | 'default') => void
}

const FALLBACK_TOOL_NAMES = [
  'bash', 'control_subagent', 'create_subagent', 'edit_file', 'list_files',
  'list_subagents', 'load_mcp', 'load_skill', 'read_file', 'search_files',
  'update_subagent', 'web_fetch', 'web_search', 'workspace_changes',
]
const surfaceShadow = { boxShadow: 'var(--shadow-surface)' }

function formatName(name: string) {
  return name.replace(/[-_]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
}

function toMarkdown(draft: AgentDraft) {
  const lines = ['---']
  if (draft.description.trim()) lines.push(`description: ${draft.description.trim().replace(/\n/g, ' ')}`)
  if (draft.model.trim()) lines.push(`model: ${draft.model.trim()}`)
  if (draft.reasoningEffort !== 'default') lines.push(`reasoning_effort: ${draft.reasoningEffort}`)
  if (draft.thinking) lines.push('thinking: true')
  if (draft.securityMode !== 'default') lines.push(`security_mode: ${draft.securityMode}`)
  if (draft.contextLimit.trim()) lines.push(`context_limit: ${draft.contextLimit.trim()}`)
  if (draft.autoSummarize) lines.push('auto_summarize: true')
  if (draft.temperature.trim()) lines.push(`temperature: ${draft.temperature.trim()}`)
  if (draft.maxTokens.trim()) lines.push(`max_tokens: ${draft.maxTokens.trim()}`)
  if (draft.mcps.length) {
    lines.push('mcp:')
    draft.mcps.forEach(name => lines.push(`  - ${name}`))
  }
  const addList = (key: string, values: string[], includeEmpty = false) => {
    if (!values.length) { if (includeEmpty) lines.push(`${key}: []`); return }
    lines.push(`${key}:`)
    values.forEach(value => lines.push(`  - ${value}`))
  }
  if (!draft.inheritSkills) addList('skills', draft.skills, true)
  addList('hooks', draft.hooks)
  addList('instructions', draft.rules)
  addList('commands', draft.commands)
  const tools = Object.entries(draft.tools).filter(([, policy]) => policy)
  if (tools.length) {
    lines.push('tools:')
    tools.forEach(([name, policy]) => lines.push(`  ${name}: ${policy}`))
  }
  lines.push('---', '', draft.prompt.trim())
  return lines.join('\n') + '\n'
}

interface AgentDraft {
  name: string
  description: string
  prompt: string
  model: string
  reasoningEffort: string
  thinking: boolean
  mcps: string[]
  tools: Record<string, '' | 'allow' | 'ask'>
  skills: string[]
  hooks: string[]
  rules: string[]
  commands: string[]
  securityMode: SecurityMode
  contextLimit: string
  autoSummarize: boolean
  temperature: string
  maxTokens: string
  inheritSkills: boolean
}

function emptyDraft(): AgentDraft {
  return { name: '', description: '', prompt: '', model: '', reasoningEffort: 'default', thinking: false, mcps: [], tools: {}, skills: [], hooks: [], rules: [], commands: [], securityMode: 'default', contextLimit: '', autoSummarize: false, temperature: '', maxTokens: '', inheritSkills: false }
}

function draftFromAgent(agent: AgentInfo): AgentDraft {
  const defaultProfile = agent.name === 'Default' ? agent.profile : undefined
  const source: AgentInfo = agent.name === 'Default' && agent.profile
    ? { name: agent.name, ...agent.profile }
    : agent
  return {
    name: source.name,
    description: source.description ?? '',
    prompt: source.prompt ?? '',
    model: source.model ?? '',
    reasoningEffort: source.reasoning_effort ?? (source.thinking ? 'medium' : 'default'),
    thinking: source.thinking ?? false,
    mcps: [...(source.mcp ?? [])],
    tools: { ...(source.tools ?? {}) } as AgentDraft['tools'],
    skills: [...(defaultProfile && !Object.prototype.hasOwnProperty.call(defaultProfile, 'skills') ? (agent.skills ?? []) : (source.skills ?? []))],
    hooks: [...(source.hooks ?? [])],
    rules: [...(source.instructions ?? [])],
    commands: [...(source.commands ?? [])],
    securityMode: source.security_mode ?? 'default',
    contextLimit: source.context_limit?.toString() ?? '',
    autoSummarize: source.auto_summarize ?? false,
    temperature: source.temperature?.toString() ?? '',
    maxTokens: source.max_tokens?.toString() ?? '',
    inheritSkills: Boolean(defaultProfile && !Object.prototype.hasOwnProperty.call(defaultProfile, 'skills')),
  }
}

export function AgentsView({
  initialCreating = false,
  agents, mcps, chatName, messages, loading, streaming, pendingInput,
  onSend, onAbort, onRespond, onRefreshAgents, reasoningEffort,
  reasoningEffortOverride, inheritedReasoningEffort, onSwitchReasoningEffort,
  models, model, modelOverride, inheritedModel, onSwitchModel,
}: Props) {
  const [creating, setCreating] = useState(initialCreating)
  const [editingName, setEditingName] = useState<string | null>(null)
  const [draft, setDraft] = useState<AgentDraft>(emptyDraft)
  const [originalDraft, setOriginalDraft] = useState<AgentDraft | null>(null)
  const [saving, setSaving] = useState(false)
  const [feedback, setFeedback] = useState<string | null>(null)
  const reduceMotion = useReducedMotion()
  const [capabilities, setCapabilities] = useState<CapabilityCatalog | null>(null)
  useEffect(() => { void fetchCapabilities().then(setCapabilities).catch(() => {}) }, [])

  const hasChanges = editingName !== null && originalDraft !== null
    ? JSON.stringify(draft) !== JSON.stringify(originalDraft)
    : true
  const availableToolNames = Array.from(new Set([
    ...FALLBACK_TOOL_NAMES,
    ...agents.flatMap(agent => Object.keys(agent.tools ?? {})),
    ...Object.keys(draft.tools),
  ])).sort()

  const update = <K extends keyof AgentDraft>(key: K, value: AgentDraft[K]) =>
    setDraft(prev => ({ ...prev, [key]: value }))

  const setTool = (name: string, policy: '' | 'allow' | 'ask') => {
    update('tools', { ...draft.tools, [name]: policy })
  }

  const submit = async () => {
    const name = draft.name.trim().toLowerCase().replace(/[^a-z0-9._-]+/g, '-')
    if (!name || (!draft.prompt.trim() && name !== 'default')) {
      setFeedback('Add an agent name and instructions before saving.')
      return
    }
    setSaving(true)
    setFeedback(null)
    try {
      await saveAgent(name, toMarkdown({ ...draft, name }))
      await onRefreshAgents()
      setFeedback(`${editingName ? 'Saved changes to' : 'Saved'} ${formatName(name)}.`)
      setDraft(emptyDraft())
      setOriginalDraft(null)
      setCreating(false)
      setEditingName(null)
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : 'Failed to save agent.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="relative flex flex-1 flex-col h-full w-full min-w-0 overflow-hidden">
      <div className="relative flex flex-col h-full min-h-0">
      <ScrollArea className="h-full" scrollbarClassName="nebula-page-scrollbar">
        <div className="w-full flex justify-center">
        <ContentContainer asChild gutter="workspace" spacing="pageWithFooter" width="workspace">
        <main>
          <PageHeader
            title="Agents"
            description="Reusable configurations for focused sessions."
            spacing="comfortable"
            action={creating ? (
              <TooltipProvider delayDuration={250}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <IconButton
                      onClick={() => { setCreating(false); setEditingName(null); setDraft(emptyDraft()); setOriginalDraft(null); setFeedback(null) }}
                      label="Close agent builder"
                      variant="primary"
                    >
                      <X size={16} />
                    </IconButton>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">Close & Discard changes</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ) : (
              <Button
                onClick={() => { setCreating(true); setEditingName(null); setDraft(emptyDraft()); setOriginalDraft(null); setFeedback(null) }}
                variant="primary"
                className="gap-1.5 pl-2"
              >
                <Plus size={14} /> New Agent
              </Button>
            )}
          />

          {creating ? (
            <AgentBuilder
              key={editingName ?? 'new-agent'}
              draft={draft}
              mcps={mcps}
              saving={saving}
              feedback={feedback}
              toolNames={availableToolNames}
              capabilities={capabilities}
              onUpdate={update}
              onSetTool={setTool}
              onSave={submit}
              editingName={editingName}
              hasChanges={hasChanges}
              onCancel={() => { setCreating(false); setEditingName(null); setDraft(emptyDraft()); setOriginalDraft(null); setFeedback(null) }}
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
              {agents.map((agent, index) => <AgentCard key={agent.name} agent={agent} index={index} reduceMotion={Boolean(reduceMotion)} onClick={() => {
                setCreating(true)
                setEditingName(agent.name)
                const nextDraft = draftFromAgent(agent)
                setDraft(nextDraft)
                setOriginalDraft(nextDraft)
                setFeedback(null)
              }} />)}
              {agents.length === 0 && (
                <div className="col-span-full flex min-h-[170px] items-center justify-center rounded-[var(--radius-surface)] bg-black/20 p-10 text-center text-xs font-medium text-[var(--color-text-secondary)] backdrop-blur-md">
                  No agents are configured yet.
                </div>
              )}
            </div>
          )}
        </main>
        </ContentContainer>
        </div>
      </ScrollArea>

      <div className="absolute inset-x-0 bottom-0 h-[42%] min-h-[280px] pointer-events-none z-20">
        <div className="h-full pointer-events-none">
          <ChatPanel
            chatName={chatName}
            messages={messages}
            loading={loading}
            streaming={streaming}
            pendingInput={pendingInput}
            session={null}
            agents={agents}
            pendingAgent="configurer"
            onSend={onSend}
            onAbort={onAbort}
            onRespond={onRespond}
            onSwitchAgent={() => {}}
            lockedAgent="configurer"
            reasoningEffort={reasoningEffort}
            reasoningEffortOverride={reasoningEffortOverride}
            inheritedReasoningEffort={inheritedReasoningEffort}
            onSwitchReasoningEffort={onSwitchReasoningEffort}
            models={models}
            model={model}
            modelOverride={modelOverride}
            inheritedModel={inheritedModel}
            onSwitchModel={onSwitchModel}
            compactEmpty
            inputPlaceholder="Describe to create a new agent"
          />
        </div>
      </div>
      </div>
    </div>
  )
}

function AgentCard({ agent, onClick, index, reduceMotion }: { agent: AgentInfo; onClick: () => void; index: number; reduceMotion: boolean }) {
  const isDefault = agent.name === 'Default'
  const toolCount = Object.keys(agent.tools ?? {}).length
  const capabilityCounts: Array<{ kind: CapabilityKind; count: number }> = [
    { kind: 'mcps', count: agent.mcp?.length ?? 0 },
    { kind: 'skills', count: agent.skills?.length ?? 0 },
    { kind: 'commands', count: agent.commands?.length ?? 0 },
    { kind: 'hooks', count: agent.hooks?.length ?? 0 },
    { kind: 'rules', count: agent.instructions?.length ?? 0 },
  ]
  return (
    <WorkspaceCard asChild>
      <motion.article
        initial={reduceMotion ? false : { opacity: 0, y: 8, scale: 0.985, filter: 'blur(3px)' }}
        animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
        transition={reduceMotion
          ? { duration: 0 }
          : { duration: 0.42, delay: Math.min(index, 8) * 0.045, ease: [0.22, 1, 0.36, 1] }}
        role="button"
        tabIndex={0}
        onClick={onClick}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick() }
        }}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--radius-control)] bg-white/[0.07]">
            <Bot size={15} className="text-white/60" />
          </div>
          <h2 className="text-[14px] font-semibold text-white/85 truncate">{formatName(agent.name)}</h2>
        </div>
        {isDefault && <span className="rounded-[var(--radius-pill)] bg-white/[0.08] px-2 py-0.5 text-[10px] text-white/45">Default</span>}
      </div>
      <p className="text-[12px] leading-relaxed text-white/48 mt-4 line-clamp-3 min-h-[54px]">
        {agent.description || 'No description provided.'}
      </p>
      <div className="flex flex-wrap gap-1.5 mt-4">
        {agent.model && <MetadataChip>{agent.model}</MetadataChip>}
        {toolCount > 0 && <CapabilityCountChip kind="tools" count={toolCount} />}
        {capabilityCounts.map(({ kind, count }) => {
          if (count === 0) return null
          return <CapabilityCountChip key={kind} kind={kind} count={count} />
        })}
      </div>
      </motion.article>
    </WorkspaceCard>
  )
}

function AgentBuilder({
  draft, mcps, capabilities, saving, feedback, editingName, hasChanges, toolNames, onUpdate, onSetTool, onSave, onCancel,
}: {
  draft: AgentDraft
  mcps: McpInfo[]
  capabilities: CapabilityCatalog | null
  saving: boolean
  feedback: string | null
  editingName: string | null
  hasChanges: boolean
  toolNames: string[]
  onUpdate: <K extends keyof AgentDraft>(key: K, value: AgentDraft[K]) => void
  onSetTool: (name: string, policy: '' | 'allow' | 'ask') => void
  onSave: () => void
  onCancel: () => void
}) {
  const [advancedOpen, setAdvancedOpen] = useState(false)

  return (
    <section style={surfaceShadow} className="rounded-[var(--radius-surface)] border border-transparent bg-[var(--color-surface-panel)] p-5">
      <div className="mb-5">
        <div>
          <h2 className="text-[15px] font-semibold text-white/85">{editingName ? 'Edit agent' : 'Configure agent'}</h2>
          <p className="text-[12px] text-white/40 mt-1">{editingName ? 'Review local changes, then save them to agent.md.' : 'Define the same fields that will be written to agent.md.'}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 items-stretch lg:grid-cols-2 gap-5">
        <div className="flex flex-col space-y-3">
          <Field label="Name">
            <input value={draft.name} disabled={Boolean(editingName)} onChange={e => onUpdate('name', e.target.value)} placeholder="e.g. code-reviewer" className={cn(inputClass, editingName && 'opacity-50 cursor-not-allowed')} />
          </Field>
          <Field label="Description">
            <input value={draft.description} onChange={e => onUpdate('description', e.target.value)} placeholder="What is this agent for?" className={inputClass} />
          </Field>
          <label className="flex min-h-0 flex-col lg:flex-1">
            <span className="block text-[10px] uppercase tracking-widest font-semibold text-white/35 mb-1.5">Instructions</span>
            <textarea value={draft.prompt} onChange={e => onUpdate('prompt', e.target.value)} placeholder="Describe the agent's role and boundaries..." className={cn(inputClass, 'h-40 min-h-[130px] resize-none overflow-y-auto lg:h-auto lg:flex-1')} />
          </label>
        </div>

        <div className="flex flex-col space-y-3">
          <ConfigSection title="MCPs" bare>
            <MultiSelect
              options={mcps.map(mcp => ({ value: mcp.name, label: formatName(mcp.name), description: mcp.transport }))}
              value={draft.mcps}
              onChange={value => onUpdate('mcps', value)}
              placeholder="Select connections"
              disabled={mcps.length === 0}
            />
            {mcps.length === 0 && <p className="mt-2 text-[12px] text-white/35">No connections configured yet.</p>}
          </ConfigSection>
          <ConfigSection title="Skills" bare>
            {editingName === 'Default' && <Checkbox appearance="field" className="mb-2" checked={draft.inheritSkills} onChange={e => onUpdate('inheritSkills', e.target.checked)} label="Use all workspace skills automatically" />}
            <MultiSelect options={(capabilities?.skills ?? []).map(item => ({ value: item.name, label: formatName(item.name), description: item.description }))} value={draft.skills} onChange={value => onUpdate('skills', value)} placeholder="Select skills" disabled={draft.inheritSkills} />
          </ConfigSection>
          <ConfigSection title="Hooks" bare><MultiSelect options={(capabilities?.hooks ?? []).map(item => ({ value: item.name, label: formatName(item.name), description: item.event }))} value={draft.hooks} onChange={value => onUpdate('hooks', value)} placeholder="Select hooks" /></ConfigSection>
          <ConfigSection title="Rules" bare><MultiSelect options={(capabilities?.rules ?? []).map(item => ({ value: item.name, label: formatName(item.name), description: 'Reusable workspace rule' }))} value={draft.rules} onChange={value => onUpdate('rules', value)} placeholder="Select rules" /></ConfigSection>
          <ConfigSection title="Tools" bare><ToolPolicyPicker names={toolNames} tools={draft.tools} onSetTool={onSetTool} /></ConfigSection>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mt-5">
        <Field label="Model">
          <input value={draft.model} onChange={e => onUpdate('model', e.target.value)} placeholder="Use default" className={inputClass} />
        </Field>
        <Field label="Reasoning effort">
          <ReasoningSelect
            value={draft.reasoningEffort}
            onChange={value => {
              onUpdate('reasoningEffort', value)
              onUpdate('thinking', value !== 'default')
            }}
          />
        </Field>
        <Field label="Security mode">
          <ContextSelect value={draft.securityMode} onChange={value => onUpdate('securityMode', value)} ariaLabel="Security mode" options={[
            { value: 'default', label: 'Default permissions' },
            { value: 'sandbox', label: 'Sandbox workspace writes' },
            { value: 'full', label: 'Full access' },
          ]} contentWidth="w-56" />
        </Field>
      </div>

      <div className="mt-5 rounded-[var(--radius-surface)] bg-[var(--color-surface-recessed)]">
        <button
          type="button"
          aria-expanded={advancedOpen}
          aria-controls="advanced-runtime-settings"
          onClick={() => setAdvancedOpen(open => !open)}
          className={cn(
            'flex h-[var(--control-height-field)] w-full items-center justify-between rounded-[var(--radius-surface)] px-3 text-left text-[12px] outline-none transition-colors duration-[var(--motion-duration-fast)] focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1',
            advancedOpen
              ? 'text-[var(--color-text-primary)]'
              : 'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)]',
          )}
        >
          <span>Advanced runtime settings</span>
          <ChevronDown size={13} className={cn('text-[var(--color-text-disabled)] transition-transform duration-[var(--motion-duration-deliberate)] ease-[var(--motion-ease-emphasized)]', advancedOpen && 'rotate-180')} />
        </button>
        <div
          id="advanced-runtime-settings"
          aria-hidden={!advancedOpen}
          inert={!advancedOpen}
          className={cn(
            'grid transition-[grid-template-rows,opacity] duration-[var(--motion-duration-slow)] ease-[var(--motion-ease-emphasized)] motion-reduce:transition-none',
            advancedOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
          )}
        >
          <div className="overflow-hidden">
            <div className="grid gap-4 px-4 pb-4 pt-1 lg:grid-cols-2">
              <Field label="Temperature"><input value={draft.temperature} onChange={e => onUpdate('temperature', e.target.value)} placeholder="Use model default" className={inputClass} /></Field>
              <Field label="Maximum output tokens"><input value={draft.maxTokens} onChange={e => onUpdate('maxTokens', e.target.value.replace(/\D/g, ''))} placeholder="Use configured default" className={inputClass} /></Field>
              <Field label="Context limit"><input value={draft.contextLimit} onChange={e => onUpdate('contextLimit', e.target.value.replace(/\D/g, ''))} placeholder="Use configured default" className={inputClass} /></Field>
              <Checkbox appearance="field" className="self-end" checked={draft.autoSummarize} onChange={e => onUpdate('autoSummarize', e.target.checked)} label="Automatically summarize long sessions" />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <p className="min-w-0 flex-1 text-[12px] text-[var(--color-status-danger)]">{feedback}</p>
        <div className="flex h-[var(--control-height-md)] shrink-0 items-stretch gap-2">
          <Button
            onClick={onCancel}
            variant="recessed"
            disabled={saving}
            className="h-full"
          >
            Cancel
          </Button>
          <Button
            onClick={onSave}
            variant="primary"
            disabled={saving || (editingName !== null && !hasChanges)}
            className="h-full gap-1.5"
          >
            {saving ? <span className="animate-pulse">Saving...</span> : <><Save size={13} /> {editingName ? 'Save changes' : 'Save agent'}</>}
          </Button>
        </div>
      </div>
    </section>
  )
}

function ConfigSection({ title, children, bare = false }: { title: string; children: React.ReactNode; bare?: boolean }) {
  return <div><p className="text-[10px] uppercase tracking-widest font-semibold text-white/35 mb-1.5">{title}</p><div className={bare ? undefined : 'rounded-xl bg-[var(--color-surface-recessed)] p-3 pl-4'}>{children}</div></div>
}

function ToolPolicyPicker({ names, tools, onSetTool }: { names: string[]; tools: AgentDraft['tools']; onSetTool: (name: string, policy: '' | 'allow' | 'ask') => void }) {
  const [open, setOpen] = useState(false)
  const selected = Object.values(tools).filter(Boolean).length
  return <Popover open={open} onOpenChange={setOpen}>
    <PopoverTrigger asChild><button type="button" className="flex h-[var(--control-height-field)] w-full items-center justify-between gap-2 rounded-[var(--radius-control)] bg-[var(--color-surface-field)] px-3 text-[12px] font-medium text-[var(--color-text-secondary)] outline-none transition-colors duration-[var(--motion-duration-fast)] hover:bg-[var(--color-surface-field-focus)] hover:text-[var(--color-text-primary)] focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1">
      <span>{selected ? `${selected} tools configured` : 'Configure tool access'}</span><ChevronsUpDown size={13} className="shrink-0 text-[var(--color-text-disabled)]" />
    </button></PopoverTrigger>
    <PopoverContent side="bottom" align="end" className="w-[360px] p-2">
      <div className="mb-2 flex items-center justify-between px-1"><div><p className="text-[12px] font-medium text-white/80">Native tools</p><p className="text-[10px] text-white/35">Unavailable tools are hidden from the model.</p></div><button onClick={() => names.forEach(name => onSetTool(name, ''))} className="pr-1 text-[10px] text-white/40 hover:text-white/70">Clear</button></div>
      <div className="max-h-72 space-y-1 overflow-y-auto pr-1">{names.map(name => <div key={name} className="flex items-center justify-between gap-3 rounded-lg px-2 py-1.5 hover:bg-white/[0.04]"><span className="min-w-0 truncate text-[11px] text-white/60">{formatName(name)}</span><PolicySelect value={tools[name] ?? ''} onChange={policy => onSetTool(name, policy)} /></div>)}</div>
    </PopoverContent>
  </Popover>
}

function PolicySelect({ value, onChange }: { value: '' | 'allow' | 'ask'; onChange: (value: '' | 'allow' | 'ask') => void }) {
  const [open, setOpen] = useState(false)
  const options: Array<{ value: '' | 'allow' | 'ask'; label: string }> = [
    { value: '', label: 'Unavailable' },
    { value: 'allow', label: 'Allow' },
    { value: 'ask', label: 'Ask' },
  ]
  const selected = options.find(option => option.value === value) ?? options[0]

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-haspopup="listbox"
          aria-expanded={open}
          className="flex h-7 min-w-[104px] items-center justify-between gap-2 rounded-lg border border-transparent bg-[var(--color-surface-input)] px-2.5 text-[11px] text-white/65 outline-none transition-colors hover:bg-[var(--color-surface-raised)] hover:text-white/90 focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1"
        >
          <span>{selected.label}</span>
          <ChevronDown size={12} className={cn('text-white/35 transition-transform', open && 'rotate-180')} />
        </button>
      </PopoverTrigger>
      <PopoverContent side="top" align="end" className="w-32 p-1">
        <div role="listbox" aria-label="Tool policy">
          {options.map(option => (
            <button
              key={option.value || 'unavailable'}
              type="button"
              role="option"
              aria-selected={option.value === value}
              onClick={() => { onChange(option.value); setOpen(false) }}
              className="flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-[11px] text-white/65 hover:bg-white/[0.08] hover:text-white/90 transition-colors"
            >
              {option.label}
              <Check size={12} className={cn('text-white/80', option.value === value ? 'opacity-100' : 'opacity-0')} />
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  )
}

function ReasoningSelect({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return <ContextSelect value={value} onChange={onChange} ariaLabel="Reasoning effort" contentWidth="w-36" options={[
    { value: 'default', label: 'Default' },
    { value: 'low', label: 'Low' },
    { value: 'medium', label: 'Medium' },
    { value: 'high', label: 'High' },
    { value: 'xhigh', label: 'XHigh' },
  ]} />
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="block text-[10px] uppercase tracking-widest font-semibold text-white/35 mb-1.5">{label}</span>{children}</label>
}

const inputClass = 'h-[var(--control-height-field)] w-full rounded-[var(--radius-control)] border border-transparent bg-[var(--color-surface-input)] px-3 py-2 text-[12px] text-white/80 placeholder:text-[var(--color-text-disabled)] outline-none focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1'
