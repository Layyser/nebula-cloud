import { useMemo, useState, type ReactNode } from 'react'
import { Search, X } from 'lucide-react'
import { cn } from '#nebula/lib/utils'
import { Button, IconButton } from '#nebula/components/ui/button'
import { ScrollArea } from '#nebula/components/ui/scroll-area'

export interface SettingsSection {
  id: string
  label: string
  group: string
  icon: ReactNode
}

export interface SettingsShellProps {
  title?: string
  sections: SettingsSection[]
  activeSection: string
  onSectionChange: (section: string) => void
  onClose: () => void
  children: ReactNode
}

/**
 * Shared settings frame for the standalone runtime and Cloud host.
 *
 * The shell owns navigation, sizing, scrolling, and focus-friendly controls;
 * each host owns the actual settings content and persistence. Keeping those
 * responsibilities separate lets Cloud add account/org settings without
 * duplicating the runtime settings layout.
 */
export function SettingsShell({
  title = 'Settings',
  sections,
  activeSection,
  onSectionChange,
  onClose,
  children,
}: SettingsShellProps) {
  const [query, setQuery] = useState('')
  const normalizedQuery = query.trim().toLowerCase()
  const groups = useMemo(() => {
    const visible = normalizedQuery
      ? sections.filter(section => section.label.toLowerCase().includes(normalizedQuery))
      : sections
    return visible.reduce<Record<string, SettingsSection[]>>((result, section) => {
      ;(result[section.group] ??= []).push(section)
      return result
    }, {})
  }, [normalizedQuery, sections])

  return (
    <section
      role="dialog"
      aria-modal="true"
      aria-label={title}
      className="relative flex h-[min(720px,calc(100vh-2rem))] w-full max-w-5xl overflow-hidden rounded-[var(--radius-large)] bg-[var(--color-surface-overlay)] text-[var(--color-text-primary)] shadow-[var(--shadow-surface)]"
    >
      <aside className="flex w-56 shrink-0 flex-col bg-[var(--color-surface-sidebar)] p-2">
        <label className="flex h-[var(--control-height-field)] items-center gap-2 rounded-[var(--radius-control)] bg-[var(--color-surface-input)] px-2.5 text-[var(--color-text-muted)] focus-within:bg-[var(--color-surface-overlay-field-focus)]">
          <Search size={15} aria-hidden="true" />
          <span className="sr-only">Search settings</span>
          <input
            value={query}
            onChange={event => setQuery(event.target.value)}
            placeholder="Search"
            className="min-w-0 flex-1 bg-transparent text-[12px] text-[var(--color-text-primary)] outline-none placeholder:text-[var(--color-text-disabled)]"
          />
        </label>

        <ScrollArea className="mt-4 min-h-0 flex-1">
          <nav aria-label="Settings sections" className="pr-1">
            {Object.entries(groups).map(([group, items]) => (
              <div key={group} className="mb-5 last:mb-0">
                <p className="mb-1 px-3 text-[10px] font-medium uppercase tracking-[0.14em] text-[var(--color-text-disabled)]">
                  {group}
                </p>
                <div className="space-y-0.5">
                  {items.map(section => (
                    <Button
                      key={section.id}
                      variant="ghost"
                      aria-current={activeSection === section.id ? 'page' : undefined}
                      onClick={() => onSectionChange(section.id)}
                      className={cn(
                        'ml-0.5 h-9 w-[calc(100%-0.125rem)] justify-start gap-0 px-0 text-left text-[12px]',
                        activeSection === section.id
                          ? 'bg-[var(--color-surface-selected)] text-[var(--color-text-primary)]'
                          : 'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)]',
                      )}
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center" aria-hidden="true">
                        {section.icon}
                      </span>
                      <span className="truncate pr-2">{section.label}</span>
                    </Button>
                  ))}
                </div>
              </div>
            ))}
            {Object.keys(groups).length === 0 && (
              <p className="px-2 py-3 text-[12px] text-[var(--color-text-disabled)]">No settings found.</p>
            )}
          </nav>
        </ScrollArea>
      </aside>

      <IconButton
        onClick={onClose}
        label="Close settings"
        variant="ghost"
        className="absolute right-2 top-2 z-10 flex h-[var(--control-height-field)] w-[var(--control-height-field)] cursor-pointer items-center justify-center rounded-[var(--radius-control)] text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)]"
      >
        <X size={16} />
      </IconButton>

      <div className="relative min-w-0 flex-1 overflow-y-auto [scrollbar-gutter:stable] bg-[var(--color-surface-overlay)]">
        <div className="w-full p-6 sm:p-8">
          {children}
        </div>
      </div>
    </section>
  )
}
