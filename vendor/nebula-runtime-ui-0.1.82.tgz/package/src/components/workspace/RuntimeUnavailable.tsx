import { RefreshCw } from 'lucide-react'
import { Button } from '#nebula/components/ui/button'

export function RuntimeUnavailable({ checking, onRetry }: { checking: boolean; onRetry: () => void }) {
  return (
    <div className="relative z-[2] flex h-[100dvh] w-full items-center justify-center px-6">
      <div className="w-full max-w-[var(--content-width-narrow)] rounded-[var(--radius-surface)] bg-[var(--color-surface-glass)] p-4 shadow-xl shadow-black/50 backdrop-blur-[var(--blur-overlay)]">
        <h1 className="text-lg font-medium text-white/90">Nebula runtime unavailable</h1>
        <p className="mt-2 text-[13px] leading-6 text-white/45">
          Start the local runtime, then reconnect this interface.
        </p>
        <code className="mt-4 block rounded-xl bg-black/30 px-4 py-3 text-[12px] text-white/65">nebula --serve</code>
        <Button variant="primary" onClick={onRetry} disabled={checking} className="mt-5">
          <RefreshCw size={13} className={checking ? 'animate-spin' : ''} />
          {checking ? 'Connecting…' : 'Try again'}
        </Button>
      </div>
    </div>
  )
}
