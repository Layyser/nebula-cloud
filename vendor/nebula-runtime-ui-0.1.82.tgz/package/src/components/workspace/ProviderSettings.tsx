import { useCallback, useEffect, useState } from 'react'
import { CheckCircle2, Copy, ExternalLink, KeyRound, LogOut } from 'lucide-react'
import { Button } from '#nebula/components/ui/button'
import { Surface } from '#nebula/components/ui/surface'
import { ModelSourceIcon } from '#nebula/components/ui/model-icon'
import { fieldControlVariants } from '../ui/form-variants'
import { cn } from '#nebula/lib/utils'
import type { RuntimeTransport } from '#nebula/runtime/transport'

export interface ProviderSettingsProps {
  transport: RuntimeTransport
  /** Called after a provider transitions to connected (e.g. to refresh models). */
  onProviderConnected?: () => void
}

interface DeviceFlow {
  flowId: string
  verificationUrl: string
  userCode: string
  intervalSeconds: number
}

type CodexState =
  | 'checking'
  | 'disconnected'
  | 'starting'
  | 'pending'
  | 'connected'
  | 'error'

type OpenCodeState =
  | 'checking'
  | 'disconnected'
  | 'saving'
  | 'connected'
  | 'error'

function ProviderActionSkeleton({ wide = false }: { wide?: boolean }) {
  return (
    <div
      role="status"
      aria-label="Loading provider status"
      className="flex h-8 shrink-0 items-center gap-2"
    >
      <span className={cn('h-8 animate-pulse rounded-[var(--radius-control)] bg-[var(--color-surface-raised)]', wide ? 'w-44' : 'w-20')} />
      {wide && <span className="h-8 w-8 animate-pulse rounded-[var(--radius-control)] bg-[var(--color-surface-raised)]" />}
    </div>
  )
}

/**
 * Organization-neutral provider connection panel. Talks to the runtime through
 * the neutral /auth/codex and /auth/opencode endpoints, which a local
 * standalone shell or the authenticated cloud gateway can both serve.
 * Provider credentials are persisted by the runtime (NEBULA_DIR/oauth) and
 * never reach the browser or the cloud database.
 */
export function ProviderSettings({
  transport,
  onProviderConnected,
}: ProviderSettingsProps) {
  // ── Codex (OAuth device flow) ────────────────────────────────────────────────
  const [codexState, setCodexState] = useState<CodexState>('checking')
  const [codexError, setCodexError] = useState('')
  const [deviceFlow, setDeviceFlow] = useState<DeviceFlow | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const controller = new AbortController()
    void transport.request('/auth/codex', { signal: controller.signal })
      .then(async response => {
        if (!response.ok) throw new Error('Could not read Codex connection status')
        const payload = await response.json() as { authenticated?: boolean }
        setCodexState(payload.authenticated ? 'connected' : 'disconnected')
      })
      .catch(error => {
        if (controller.signal.aborted) return
        setCodexError(error instanceof Error ? error.message : 'Codex status failed')
        setCodexState('error')
      })
    return () => controller.abort()
  }, [transport])

  useEffect(() => {
    if (!deviceFlow || codexState !== 'pending') return
    let cancelled = false
    let timeout = 0
    const poll = async () => {
      try {
        const response = await transport.request(
          `/auth/codex/device/${encodeURIComponent(deviceFlow.flowId)}`,
        )
        const payload = await response.json() as {
          status?: string
          message?: string | null
        }
        if (cancelled) return
        if (payload.status === 'complete') {
          setCodexState('connected')
          setDeviceFlow(null)
          onProviderConnected?.()
          return
        }
        if (payload.status !== 'pending') {
          setCodexError(payload.message || 'Codex sign-in failed')
          setCodexState('error')
          setDeviceFlow(null)
          return
        }
      } catch {
        if (cancelled) return
        setCodexError('Could not check Codex sign-in')
        setCodexState('error')
        setDeviceFlow(null)
        return
      }
      timeout = window.setTimeout(
        () => { void poll() },
        Math.max(1000, deviceFlow.intervalSeconds * 1000),
      )
    }
    timeout = window.setTimeout(
      () => { void poll() },
      Math.max(1000, deviceFlow.intervalSeconds * 1000),
    )
    return () => {
      cancelled = true
      window.clearTimeout(timeout)
    }
  }, [codexState, deviceFlow, onProviderConnected, transport])

  const startCodexLogin = useCallback(async () => {
    setCodexError('')
    setCopied(false)
    setCodexState('starting')
    try {
      const response = await transport.request('/auth/codex/device', {
        method: 'POST',
      })
      const payload = await response.json() as {
        flow_id?: string
        verification_url?: string
        user_code?: string
        interval_seconds?: number
        error?: string
      }
      if (
        !response.ok
        || !payload.flow_id
        || !payload.verification_url
        || !payload.user_code
      ) {
        throw new Error(payload.error || 'Could not start Codex sign-in')
      }
      setDeviceFlow({
        flowId: payload.flow_id,
        verificationUrl: payload.verification_url,
        userCode: payload.user_code,
        intervalSeconds: payload.interval_seconds || 5,
      })
      setCodexState('pending')
    } catch (error) {
      setCodexError(error instanceof Error ? error.message : 'Codex sign-in failed')
      setCodexState('error')
    }
  }, [transport])

  const copyDeviceCode = useCallback(async () => {
    if (!deviceFlow) return
    try {
      await navigator.clipboard.writeText(deviceFlow.userCode)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1600)
    } catch {
      setCodexError('Could not copy the one-time code')
    }
  }, [deviceFlow])

  // ── OpenCode Go (API key) ────────────────────────────────────────────────────
  const [opencodeState, setOpenCodeState] = useState<OpenCodeState>('checking')
  const [opencodeError, setOpenCodeError] = useState('')
  const [opencodeKey, setOpenCodeKey] = useState('')
  const [opencodeShowKey, setOpenCodeShowKey] = useState(false)

  useEffect(() => {
    const controller = new AbortController()
    void transport.request('/auth/opencode', { signal: controller.signal })
      .then(async response => {
        if (!response.ok) throw new Error('Could not read OpenCode Go status')
        const payload = await response.json() as { authenticated?: boolean }
        setOpenCodeState(payload.authenticated ? 'connected' : 'disconnected')
      })
      .catch(error => {
        if (controller.signal.aborted) return
        setOpenCodeError(error instanceof Error ? error.message : 'OpenCode Go status failed')
        setOpenCodeState('error')
      })
    return () => controller.abort()
  }, [transport])

  const saveOpenCodeKey = useCallback(async () => {
    const apiKey = opencodeKey.trim()
    if (!apiKey) return
    setOpenCodeError('')
    setOpenCodeState('saving')
    try {
      const response = await transport.request('/auth/opencode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ api_key: apiKey }),
      })
      if (!response.ok) {
        const payload = await response.json().catch(() => null) as
          | { error?: string }
          | null
        throw new Error(payload?.error || `OpenCode Go save failed (${response.status})`)
      }
      setOpenCodeKey('')
      setOpenCodeState('connected')
      onProviderConnected?.()
    } catch (error) {
      setOpenCodeError(error instanceof Error ? error.message : 'OpenCode Go save failed')
      setOpenCodeState('error')
    }
  }, [opencodeKey, onProviderConnected, transport])

  const disconnectOpenCode = useCallback(async () => {
    setOpenCodeError('')
    try {
      await transport.request('/auth/opencode', { method: 'DELETE' })
      setOpenCodeState('disconnected')
    } catch (error) {
      setOpenCodeError(error instanceof Error ? error.message : 'OpenCode Go disconnect failed')
    }
  }, [transport])

  return (
    <div className="space-y-3">
      {/* Codex */}
      <Surface bordered variant="panel" density="compact" radius="surface">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="flex items-center gap-1.5 text-[12px] font-medium text-[var(--color-text-primary)]">
              <ModelSourceIcon model="codex" provider="codex" />
              Codex
            </p>
            <p className="mt-0.5 text-[10px] leading-4 text-[var(--color-text-muted)]">
              Use your ChatGPT subscription inside this operator.
            </p>
          </div>
          {codexState === 'checking' ? <ProviderActionSkeleton /> : codexState === 'connected' ? (
            <span className="flex h-8 items-center gap-1.5 rounded-[var(--radius-control)] bg-[var(--color-status-success-surface)] px-2.5 text-[11px] text-[var(--color-status-success)]">
              <CheckCircle2 size={13} />
              Connected
            </span>
          ) : codexState !== 'pending' ? (
            <Button
              variant="primary"
              disabled={codexState === 'starting'}
              onClick={() => { void startCodexLogin() }}
              className="h-8 shrink-0"
            >
              {codexState === 'starting' ? 'Starting…' : 'Connect'}
            </Button>
          ) : null}
        </div>
        {codexState === 'pending' && deviceFlow && (
            <div className="mt-3 border-t border-[var(--color-border-subtle)] pt-3">
            <p className="text-[11px] leading-5 text-[var(--color-text-muted)]">
              Open OpenAI and enter this one-time code:
            </p>
            <div className="mt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={() => { void copyDeviceCode() }}
                className={cn(fieldControlVariants({ size: 'default' }), 'flex h-9 flex-1 items-center justify-between font-mono tracking-[0.12em] transition hover:bg-[var(--color-surface-field-focus)]')}
              >
                {deviceFlow.userCode}
                <span className="flex items-center gap-1 font-sans text-[10px] tracking-normal text-[var(--color-text-disabled)]">
                  <Copy size={12} />
                  {copied ? 'Copied' : 'Copy'}
                </span>
              </button>
              <a
                href={deviceFlow.verificationUrl}
                target="_blank"
                rel="noreferrer"
                className="flex h-9 items-center gap-1.5 rounded-[var(--radius-control)] bg-[var(--color-control-primary)] px-3 text-[11px] font-medium text-[var(--color-control-on-primary)] transition hover:bg-[var(--color-control-primary-hover)]"
              >
                Open OpenAI
                <ExternalLink size={12} />
              </a>
            </div>
            <p className="mt-2 text-[10px] text-[var(--color-text-disabled)]">
              Waiting for authorization. This code expires in 15 minutes.
            </p>
          </div>
        )}
        {codexState === 'error' && codexError && (
          <p className="mt-2 text-[10px] leading-4 text-[var(--color-status-danger)]">{codexError}</p>
        )}
      </Surface>

      {/* OpenCode Go */}
      <Surface bordered variant="panel" density="compact" radius="surface">
        <div className="flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
          <div>
            <p className="flex items-center gap-1.5 text-[12px] font-medium text-[var(--color-text-primary)]">
              <ModelSourceIcon model="opencode" provider="opencode" />
              OpenCode Go
            </p>
            <p className="mt-0.5 text-[10px] leading-4 text-[var(--color-text-muted)]">
              Low-cost subscription for open coding models. Get a key at{' '}
              <a
                href="https://opencode.ai/auth"
                target="_blank"
                rel="noreferrer"
                className="text-[var(--color-text-secondary)] underline decoration-[var(--color-border-subtle)] underline-offset-2 hover:text-[var(--color-text-primary)]"
              >
                opencode.ai/auth
              </a>
              .
            </p>
          </div>
          {opencodeState === 'checking' ? <ProviderActionSkeleton wide /> : opencodeState === 'connected' ? (
            <div className="flex flex-wrap items-center gap-2 sm:flex-nowrap">
              <span className="flex h-8 items-center gap-1.5 rounded-[var(--radius-control)] bg-[var(--color-status-success-surface)] px-2.5 text-[11px] text-[var(--color-status-success)]">
                <CheckCircle2 size={13} />
                Connected
              </span>
              <Button
                variant="ghost"
                onClick={() => { void disconnectOpenCode() }}
                className="h-8 shrink-0 text-[var(--color-text-muted)]"
              >
                <LogOut size={13} />
                Disconnect
              </Button>
            </div>
          ) : (
            <form
              className="flex w-full min-w-0 items-center gap-2 sm:w-auto"
              onSubmit={event => {
                event.preventDefault()
                void saveOpenCodeKey()
              }}
            >
              <input
                type={opencodeShowKey ? 'text' : 'password'}
                value={opencodeKey}
                onChange={event => setOpenCodeKey(event.target.value)}
                placeholder="oc-go-…"
                spellCheck={false}
                autoComplete="off"
                className={cn(fieldControlVariants({ size: 'default' }), 'h-8 min-w-0 flex-1 font-mono text-[11px] sm:w-44 sm:flex-none')}
              />
              <button
                type="button"
                onClick={() => setOpenCodeShowKey(show => !show)}
                aria-label={opencodeShowKey ? 'Hide API key' : 'Show API key'}
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--radius-control)] bg-[var(--color-surface-field)] text-[var(--color-text-muted)] transition hover:bg-[var(--color-surface-field-focus)] hover:text-[var(--color-text-primary)]',
                  opencodeKey && 'text-[var(--color-text-primary)]',
                )}
              >
                <KeyRound size={13} />
              </button>
              <Button
                type="submit"
                variant="primary"
                disabled={opencodeState === 'saving' || !opencodeKey.trim()}
                className="h-8 shrink-0"
              >
                {opencodeState === 'saving' ? 'Saving…' : 'Save'}
              </Button>
            </form>
          )}
        </div>
        {opencodeState === 'error' && opencodeError && (
          <p className="mt-2 text-[10px] leading-4 text-[var(--color-status-danger)]">{opencodeError}</p>
        )}
      </Surface>
    </div>
  )
}
