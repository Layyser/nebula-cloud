import { useEffect, useRef } from 'react'
import staticNebulaMobile from '../../assets/nebula-static-mobile.webp'
import staticNebulaMobileLight from '../../assets/nebula-static-mobile-light.webp'
import staticNebulaDesktopSmall from '../../assets/nebula-static-desktop-sm.webp'
import staticNebulaDesktopSmallLight from '../../assets/nebula-static-desktop-sm-light.webp'
import staticNebulaDesktopMedium from '../../assets/nebula-static-desktop-md.webp'
import staticNebulaDesktopMediumLight from '../../assets/nebula-static-desktop-md-light.webp'
import staticNebulaDesktopLarge from '../../assets/nebula-static-desktop-lg.webp'
import staticNebulaDesktopLargeLight from '../../assets/nebula-static-desktop-lg-light.webp'
import vertexSrc from '../../shaders/vertex.glsl?raw'
import {
  getNebulaPalette,
  getNebulaVariant,
  type NebulaPaletteId,
  type NebulaVariantId,
} from '#nebula/components/shader/nebulaOptions'

interface Props {
  /** 0 = fully visible, 1 = fully faded to black */
  fade: number
  variant?: NebulaVariantId
  palette?: NebulaPaletteId
  resolutionScale?: number
  /** Subtly transform and fade the animated shader through the first viewport. */
  scrollReactive?: boolean
}

function detectSoftwareRenderer(): boolean {
  if (typeof document === 'undefined') return false
  const probe = document.createElement('canvas')
  const gl = probe.getContext('webgl2', { failIfMajorPerformanceCaveat: true })
  if (!gl) return true
  const ext = gl.getExtension('WEBGL_debug_renderer_info')
  if (!ext) return false
  const renderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) as string
  return /swiftshader|software|llvmpipe|mesa offscreen|microsoft basic/i.test(renderer)
}

const IS_SOFTWARE = detectSoftwareRenderer()
const IS_MOBILE = typeof window !== 'undefined'
  && window.matchMedia('(max-width: 767px)').matches
const MOBILE_FRAME_INTERVAL = 1000 / 24
const MOBILE_RENDER_SCALE = 0.4
const MOBILE_SPEED_FACTOR = 0.55
const SHOULD_ANIMATE = typeof window !== 'undefined'
  && !IS_SOFTWARE
  && !window.matchMedia('(prefers-reduced-motion: reduce)').matches

interface StaticNebulaPictureProps {
  className: string
  mobile: string
  desktopSmall: string
  desktopMedium: string
  desktopLarge: string
}

function StaticNebulaPicture({ className, mobile, desktopSmall, desktopMedium, desktopLarge }: StaticNebulaPictureProps) {
  return (
    <picture className={`nebula-static-image-picture ${className}`}>
      <source media="(min-width: 2200px)" srcSet={desktopLarge} />
      <source media="(min-width: 1440px)" srcSet={desktopMedium} />
      <source media="(min-width: 1024px)" srcSet={desktopSmall} />
      <img src={mobile} alt="" aria-hidden="true" className="nebula-static-image" decoding="async" />
    </picture>
  )
}

export function NebulaBackground({ fade: _fade, variant = 'classic', palette = 'graphite', resolutionScale, scrollReactive = false }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fadeRef = useRef(_fade)
  const scrollProgressRef = useRef(0)
  const variantConfig = getNebulaVariant(variant)
  const paletteConfig = getNebulaPalette(palette)

  useEffect(() => {
    fadeRef.current = _fade
  }, [_fade])

  useEffect(() => {
    if (!scrollReactive || !SHOULD_ANIMATE) {
      scrollProgressRef.current = 0
      return
    }

    let raf = 0
    let range = Math.max(window.innerHeight * 0.8, 1)

    const update = () => {
      raf = 0
      scrollProgressRef.current = Math.min(1, Math.max(0, window.scrollY / range))
    }
    const schedule = () => {
      if (window.scrollY >= range && scrollProgressRef.current >= 1) return
      if (!raf) raf = window.requestAnimationFrame(update)
    }
    const resize = () => {
      range = Math.max(window.innerHeight * 0.8, 1)
      schedule()
    }

    update()
    window.addEventListener('scroll', schedule, { passive: true })
    window.addEventListener('resize', resize, { passive: true })
    return () => {
      window.cancelAnimationFrame(raf)
      window.removeEventListener('scroll', schedule)
      window.removeEventListener('resize', resize)
    }
  }, [scrollReactive])

  useEffect(() => {
    if (IS_SOFTWARE) return

    const canvas = canvasRef.current!
    const gl = canvas.getContext('webgl2', { antialias: false })
    if (!gl) return

    const compile = (type: number, src: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, src)
      gl.compileShader(s)
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
        console.error('Shader:', gl.getShaderInfoLog(s))
      return s
    }

    const vertexShader = compile(gl.VERTEX_SHADER, vertexSrc)
    const fragmentShader = compile(gl.FRAGMENT_SHADER, variantConfig.fragmentSource)
    const prog = gl.createProgram()!
    gl.attachShader(prog, vertexShader)
    gl.attachShader(prog, fragmentShader)
    gl.linkProgram(prog)
    gl.useProgram(prog)

    const verts = new Float32Array([
      -1, -1, 0,  0, 0, 1,  1, 1, 1,
       1, -1, 0,  0, 0, 1,  1, 1, 1,
      -1,  1, 0,  0, 0, 1,  1, 1, 1,
      -1,  1, 0,  0, 0, 1,  1, 1, 1,
       1, -1, 0,  0, 0, 1,  1, 1, 1,
       1,  1, 0,  0, 0, 1,  1, 1, 1,
    ])
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, verts, gl.STATIC_DRAW)

    const stride = 9 * 4
    const pos = gl.getAttribLocation(prog, 'position')
    if (pos >= 0) {
      gl.enableVertexAttribArray(pos)
      gl.vertexAttribPointer(pos, 3, gl.FLOAT, false, stride, 0)
    }

    const nor = gl.getAttribLocation(prog, 'normal')
    if (nor >= 0) {
      gl.enableVertexAttribArray(nor)
      gl.vertexAttribPointer(nor, 3, gl.FLOAT, false, stride, 3 * 4)
    }

    const uTime    = gl.getUniformLocation(prog, 'time')
    const uAspect  = gl.getUniformLocation(prog, 'aspect')
    const uColor1  = gl.getUniformLocation(prog, 'uColor1')
    const uColor2  = gl.getUniformLocation(prog, 'uColor2')
    const uColor3  = gl.getUniformLocation(prog, 'uColor3')
    const uSpeed   = gl.getUniformLocation(prog, 'uSpeed')
    const uDensity = gl.getUniformLocation(prog, 'uDensity')
    const uFade    = gl.getUniformLocation(prog, 'uFade')
    const uScroll  = gl.getUniformLocation(prog, 'uScrollProgress')

    gl.uniform3fv(uColor1, new Float32Array(paletteConfig.uniforms[0]))
    gl.uniform3fv(uColor2, new Float32Array(paletteConfig.uniforms[1]))
    gl.uniform3fv(uColor3, new Float32Array(paletteConfig.uniforms[2]))
    gl.uniform1f(uSpeed, variantConfig.speed * (IS_MOBILE ? MOBILE_SPEED_FACTOR : 1))
    gl.uniform1f(uDensity, variantConfig.density)

    const draw = (now: number) => {
      gl.uniform1f(uTime, now * 0.001)
      gl.uniform1f(uFade, 1.0 - fadeRef.current)
      gl.uniform1f(uScroll, scrollProgressRef.current)
      gl.clearColor(0, 0, 0, 1)
      gl.clear(gl.COLOR_BUFFER_BIT)
      gl.drawArrays(gl.TRIANGLES, 0, 6)
    }

    const resize = () => {
      const requestedScale = resolutionScale ?? variantConfig.renderScale
      const scale = IS_MOBILE
        ? Math.min(requestedScale, MOBILE_RENDER_SCALE)
        : requestedScale
      const w = Math.max(1, Math.floor(canvas.clientWidth * scale))
      const h = Math.max(1, Math.floor(canvas.clientHeight * scale))
      canvas.width = w
      canvas.height = h
      gl.viewport(0, 0, w, h)
      gl.uniform1f(uAspect, w / h)
      draw(performance.now())
    }
    resize()
    const ro = SHOULD_ANIMATE ? new ResizeObserver(resize) : null
    ro?.observe(canvas)

    let raf = 0
    let mobileTimeout = 0
    const render = (now: number) => {
      draw(now)
      raf = requestAnimationFrame(render)
    }
    const renderMobile = () => {
      mobileTimeout = 0
      if (document.hidden) return
      draw(performance.now())
      mobileTimeout = window.setTimeout(renderMobile, MOBILE_FRAME_INTERVAL)
    }
    const handleVisibility = () => {
      if (document.hidden) {
        window.clearTimeout(mobileTimeout)
        mobileTimeout = 0
      } else if (!mobileTimeout) {
        renderMobile()
      }
    }

    if (SHOULD_ANIMATE) {
      if (IS_MOBILE) {
        document.addEventListener('visibilitychange', handleVisibility)
        mobileTimeout = window.setTimeout(renderMobile, MOBILE_FRAME_INTERVAL)
      } else {
        raf = requestAnimationFrame(render)
      }
    }

    return () => {
      cancelAnimationFrame(raf)
      window.clearTimeout(mobileTimeout)
      document.removeEventListener('visibilitychange', handleVisibility)
      ro?.disconnect()
      gl.deleteBuffer(buf)
      gl.deleteProgram(prog)
      gl.deleteShader(vertexShader)
      gl.deleteShader(fragmentShader)
    }
  }, [paletteConfig, resolutionScale, variantConfig])

  if (IS_SOFTWARE) {
    return (
      <div
        aria-hidden="true"
        data-shader-mode="static"
        data-shader-variant="none"
        className="nebula-static-image-stack pointer-events-none"
        style={{ zIndex: 0 }}
      >
        <div className="nebula-static-image-backdrop" />
        <div className="nebula-static-image-shell">
          <StaticNebulaPicture
            className="nebula-static-image-dark"
            mobile={staticNebulaMobile}
            desktopSmall={staticNebulaDesktopSmall}
            desktopMedium={staticNebulaDesktopMedium}
            desktopLarge={staticNebulaDesktopLarge}
          />
          <StaticNebulaPicture
            className="nebula-static-image-light"
            mobile={staticNebulaMobileLight}
            desktopSmall={staticNebulaDesktopSmallLight}
            desktopMedium={staticNebulaDesktopMediumLight}
            desktopLarge={staticNebulaDesktopLargeLight}
          />
        </div>
        <div className="nebula-static-image-bottom-fade" />
      </div>
    )
  }

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      data-shader-mode={SHOULD_ANIMATE ? 'animated' : 'static'}
      data-shader-variant={variantConfig.id}
      className="nebula-scroll-canvas pointer-events-none absolute inset-x-0 top-0 block h-[100dvh] w-full"
      style={{ zIndex: 0, imageRendering: 'auto' }}
    />
  )
}
