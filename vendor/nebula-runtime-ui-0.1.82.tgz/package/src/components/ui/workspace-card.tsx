import type { ReactNode } from 'react'
import { Surface, type SurfaceProps } from './surface'
import { cn } from '#nebula/lib/utils'

export type WorkspaceCardProps = Omit<SurfaceProps, 'title'> & {
  icon?: ReactNode
  title?: ReactNode
  badge?: ReactNode
  description?: ReactNode
  footer?: ReactNode
}

/**
 * Shared card shell for the top-level workspace collections (Agents,
 * Capabilities, and Cloud Dashboard). Keep collection cards on this component
 * so their size, surface, radius, and interaction states stay aligned.
 */
export function WorkspaceCard({
  icon,
  title,
  badge,
  description,
  footer,
  children,
  className,
  ...props
}: WorkspaceCardProps) {
  return (
    <Surface
      variant="panel"
      density="default"
      radius="surface"
      interaction="selectable"
      bordered
      className={cn(
        'min-h-[170px] overflow-hidden text-left shadow-[var(--shadow-surface)]',
        className,
      )}
      {...props}
    >
      {children ?? (
        <>
          <div className="flex min-w-0 items-start justify-between gap-3">
            <div className="flex min-w-0 items-center gap-2">
              {icon && (
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--radius-control)] bg-white/[0.07] text-white/60">
                  {icon}
                </div>
              )}
              {title && <div className="truncate text-[14px] font-semibold text-white/85">{title}</div>}
            </div>
            {badge}
          </div>
          {description && (
            <div className="mt-4 min-h-[54px] text-[12px] leading-relaxed text-white/48 line-clamp-3">
              {description}
            </div>
          )}
          {footer && <div className="mt-4 flex flex-wrap gap-1.5">{footer}</div>}
        </>
      )}
    </Surface>
  )
}
