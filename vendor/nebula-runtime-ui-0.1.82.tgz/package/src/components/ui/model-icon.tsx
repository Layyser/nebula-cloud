import { Globe2, Sparkles } from 'lucide-react'
import companyClaude from '#nebula/assets/model-icons/companies/claude.svg'
import companyDeepseek from '#nebula/assets/model-icons/companies/deepseek.svg'
import companyGemini from '#nebula/assets/model-icons/companies/gemini.svg'
import companyGrok from '#nebula/assets/model-icons/companies/grok.svg'
import companyHy from '#nebula/assets/model-icons/companies/hy.svg'
import companyKimi from '#nebula/assets/model-icons/companies/kimi.svg'
import companyKimiLight from '#nebula/assets/model-icons/companies/kimi-light.svg'
import companyLongcat from '#nebula/assets/model-icons/companies/longcat.svg'
import companyMeituan from '#nebula/assets/model-icons/companies/meituan.svg'
import companyMeta from '#nebula/assets/model-icons/companies/meta.svg'
import companyMinimax from '#nebula/assets/model-icons/companies/minimax.svg'
import companyMoonshot from '#nebula/assets/model-icons/companies/moonshot.svg'
import companyNvidia from '#nebula/assets/model-icons/companies/nvidia.svg'
import companyOpenai from '#nebula/assets/model-icons/companies/openai.svg'
import companyQwen from '#nebula/assets/model-icons/companies/qwen.svg'
import companyXiaomi from '#nebula/assets/model-icons/companies/xiaomi.svg'
import companyZai from '#nebula/assets/model-icons/companies/zai.svg'
import sourceCodex from '#nebula/assets/model-icons/sources/codex.svg'
import sourceOpenCode from '#nebula/assets/model-icons/sources/opencode.svg'
import sourceOpenRouter from '#nebula/assets/model-icons/sources/openrouter.svg'
import { cn } from '#nebula/lib/utils'
import { Tooltip, TooltipContent, TooltipTrigger } from './tooltip'

export interface ModelIconProps {
  model: string
  provider?: string
  className?: string
}

type IconPresentation = {
  asset?: string
  lightAsset?: string
  icon?: typeof Sparkles
  color?: string
  label: string
  themeClassName?: string
}

function AssetIcon({ presentation, size }: { presentation: IconPresentation; size: number }) {
  const dimensions = { width: size, height: size }
  if (presentation.lightAsset) {
    return (
      <>
        <img
          src={presentation.asset}
          alt=""
          aria-hidden="true"
          className="model-icon-dark-only shrink-0 object-contain"
          style={dimensions}
        />
        <img
          src={presentation.lightAsset}
          alt=""
          aria-hidden="true"
          className="model-icon-light-only shrink-0 object-contain"
          style={dimensions}
        />
      </>
    )
  }
  return (
    <img
      src={presentation.asset}
      alt=""
      aria-hidden="true"
      className={cn('block shrink-0 object-contain', presentation.themeClassName)}
      style={dimensions}
    />
  )
}

function PresentationIcon({ presentation, size }: { presentation: IconPresentation; size: number }) {
  if (presentation.asset) return <AssetIcon presentation={presentation} size={size} />
  const Icon = presentation.icon ?? Sparkles
  return (
    <Icon
      aria-hidden="true"
      size={size}
      className="block shrink-0"
      style={presentation.color ? { color: presentation.color } : undefined}
    />
  )
}

export function ModelCompanyIcon({ model, provider, className }: ModelIconProps) {
  const presentation = companyPresentation(provider, model)
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span
          aria-label={`${presentation.label} company`}
          className={cn('inline-flex size-4 shrink-0 items-center justify-center leading-none', className)}
        >
          <PresentationIcon presentation={presentation} size={15} />
        </span>
      </TooltipTrigger>
      <TooltipContent side="top">{presentation.label}</TooltipContent>
    </Tooltip>
  )
}

export function ModelSourceIcon({ model, provider, className }: ModelIconProps) {
  const presentation = sourcePresentation(provider, model)
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span
          aria-label={`${presentation.label} source`}
          className={cn('inline-flex size-4 shrink-0 items-center justify-center leading-none text-white/35', className)}
        >
          <PresentationIcon presentation={presentation} size={14} />
        </span>
      </TooltipTrigger>
      <TooltipContent side="top">{presentation.label}</TooltipContent>
    </Tooltip>
  )
}

function sourcePresentation(provider: string | undefined, model: string): IconPresentation {
  const providerIdentity = provider?.trim().toLowerCase() ?? ''
  const modelIdentity = model.trim().toLowerCase()
  const identity = `${providerIdentity} ${modelIdentity}`
  if (providerIdentity.includes('opencode') || identity.includes('opencode')) {
    return { asset: sourceOpenCode, label: 'OpenCode Go', themeClassName: 'model-icon-invert-light' }
  }
  if (
    providerIdentity === 'codex'
    || identity.includes('codex')
    || (!providerIdentity && /^(?:gpt-\d|o[134](?:-|$))/.test(modelIdentity))
    || (providerIdentity === 'openai' && /^gpt-5\.6(?:-|$)/.test(modelIdentity))
  ) {
    return { asset: sourceCodex, label: 'Codex' }
  }
  if (identity.includes('anthropic') || identity.includes('claude')) {
    return { icon: Sparkles, color: '#d97757', label: 'Anthropic' }
  }
  if (identity.includes('google') || identity.includes('gemini')) {
    return { icon: Globe2, color: '#4285f4', label: 'Google' }
  }
  if (identity.includes('xai') || identity.includes('grok')) {
    return { icon: Sparkles, label: 'xAI' }
  }
  if (providerIdentity.includes('tokenrouter')) {
    return { icon: Globe2, label: 'TokenRouter' }
  }
  if (providerIdentity.includes('openrouter')) {
    return { asset: sourceOpenRouter, label: 'OpenRouter' }
  }
  return { icon: Globe2, label: provider || 'Unknown source' }
}

function companyPresentation(provider: string | undefined, model: string): IconPresentation {
  const providerIdentity = provider?.trim().toLowerCase() ?? ''
  const modelIdentity = model.trim().toLowerCase()
  const identity = `${providerIdentity} ${modelIdentity}`

  if (identity.includes('glm') || identity.includes('zhipu') || identity.includes('z.ai')) {
    return { asset: companyZai, label: 'Z.ai', themeClassName: 'model-icon-invert-dark' }
  }
  if (identity.includes('deepseek')) return { asset: companyDeepseek, label: 'DeepSeek' }
  if (identity.includes('minimax')) return { asset: companyMinimax, label: 'MiniMax' }
  if (identity.includes('longcat')) return { asset: companyLongcat, label: 'LongCat' }
  if (identity.includes('meituan')) return { asset: companyMeituan, label: 'Meituan' }
  if (identity.includes('kimi')) {
    return { asset: companyKimi, lightAsset: companyKimiLight, label: 'Kimi' }
  }
  if (identity.includes('moonshot')) return { asset: companyMoonshot, label: 'Moonshot' }
  if (identity.includes('qwen')) return { asset: companyQwen, label: 'Qwen' }
  if (identity.includes('mimo')) return { asset: companyXiaomi, label: 'MiMo' }
  if (identity.includes('hy3') || identity.includes('hy4') || identity.includes('hunyuan')) {
    return { asset: companyHy, label: 'Hunyuan' }
  }
  if (identity.includes('grok') || identity.includes('xai')) {
    return { asset: companyGrok, label: 'Grok', themeClassName: 'model-icon-invert-dark' }
  }
  if (identity.includes('anthropic') || identity.includes('claude')) {
    return { asset: companyClaude, label: 'Claude' }
  }
  if (identity.includes('google') || identity.includes('gemini')) {
    return { asset: companyGemini, label: 'Gemini' }
  }
  if (identity.includes('muse-spark') || identity.includes('meta')) {
    return { asset: companyMeta, label: 'Meta' }
  }
  if (identity.includes('nemotron') || identity.includes('nvidia')) {
    return { asset: companyNvidia, label: 'NVIDIA' }
  }
  if (identity.includes('gpt-') || identity.includes('openai') || providerIdentity === 'codex') {
    return { asset: companyOpenai, label: 'OpenAI', themeClassName: 'model-icon-invert-dark' }
  }
  return { icon: Sparkles, label: provider || 'Unknown provider' }
}
