import { cva } from 'class-variance-authority'

export const floatingSurfaceVariants = cva(
  'ui-border-floating z-[100] bg-[var(--color-surface-overlay)] text-[var(--color-text-secondary)] shadow-[var(--shadow-surface)] backdrop-blur-[var(--blur-overlay)] outline-none transition-[opacity,filter] duration-[var(--motion-duration-fast)] ease-[var(--motion-ease-standard)] data-[state=closed]:opacity-0 data-[state=closed]:blur-[1px] data-[state=open]:opacity-100 data-[state=open]:blur-0 motion-reduce:transition-none',
  {
    variants: {
      kind: {
        tooltip: 'max-w-xs rounded-[var(--radius-control)] px-2.5 py-1.5 text-xs',
        popover: 'min-w-40 rounded-[var(--radius-surface)] p-1',
      },
    },
    defaultVariants: { kind: 'popover' },
  },
)

export const menuItemVariants = cva(
  'flex w-full cursor-pointer items-center rounded-[var(--radius-control)] px-2 py-1.5 text-left text-xs outline-none transition-colors duration-[var(--motion-duration-fast)] focus-visible:bg-[var(--color-surface-hover)] focus-visible:text-[var(--color-text-primary)] disabled:pointer-events-none disabled:opacity-40',
  {
    variants: {
      selected: {
        true: 'bg-[var(--color-surface-selected)] text-[var(--color-text-primary)]',
        false: 'text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)] hover:text-[var(--color-text-primary)]',
      },
    },
    defaultVariants: { selected: false },
  },
)
