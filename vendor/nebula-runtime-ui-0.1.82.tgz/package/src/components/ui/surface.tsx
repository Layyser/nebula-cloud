import { Slot } from '@radix-ui/react-slot'
import type { VariantProps } from 'class-variance-authority'
import { forwardRef, type HTMLAttributes } from 'react'
import { cn } from '#nebula/lib/utils'
import { surfaceVariants } from './surface-variants'

export interface SurfaceProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof surfaceVariants> {
  asChild?: boolean
  bordered?: boolean
}

export const Surface = forwardRef<HTMLDivElement, SurfaceProps>(function Surface(
  { asChild = false, bordered = false, className, variant, density, radius, interaction, selected, ...props },
  ref,
) {
  const Comp = asChild ? Slot : 'div'
  return (
    <Comp
      ref={ref}
      data-selected={selected || undefined}
      className={cn(surfaceVariants({ variant, density, radius, interaction, selected }), bordered && 'ui-border-surface', className)}
      {...props}
    />
  )
})

export const Card = forwardRef<HTMLDivElement, SurfaceProps>(function Card(
  { className, ...props },
  ref,
) {
  return <Surface ref={ref} className={cn('overflow-hidden', className)} {...props} />
})
