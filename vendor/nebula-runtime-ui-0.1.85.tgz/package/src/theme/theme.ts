import { useCallback, useSyncExternalStore } from 'react'

export type ThemePreference = 'dark' | 'light' | 'system'
export type ResolvedTheme = Exclude<ThemePreference, 'system'>
export type BorderPreference = 'on' | 'off'

export const THEME_STORAGE_KEY = 'nebula-color-mode'
export const BORDER_STORAGE_KEY = 'nebula-borders'
const THEME_CHANGE_EVENT = 'nebula-theme-change'
const BORDER_CHANGE_EVENT = 'nebula-border-change'
const SYSTEM_THEME_QUERY = '(prefers-color-scheme: dark)'
const BROWSER_CHROME_COLORS: Record<ResolvedTheme, string> = {
  dark: '#080808',
  light: '#f5f5f5',
}

export function setBrowserChromeColor(color: string): void {
  if (typeof document === 'undefined') return
  const themeColor = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]')
  if (themeColor) {
    themeColor.content = color
    return
  }
  const nextThemeColor = document.createElement('meta')
  nextThemeColor.name = 'theme-color'
  nextThemeColor.content = color
  document.head.appendChild(nextThemeColor)
}

function isThemePreference(value: string | null): value is ThemePreference {
  return value === 'dark' || value === 'light' || value === 'system'
}

function isBorderPreference(value: string | null): value is BorderPreference {
  return value === 'on' || value === 'off'
}

export function getThemePreference(): ThemePreference {
  if (typeof window === 'undefined') return 'dark'
  try {
    const stored = window.localStorage.getItem(THEME_STORAGE_KEY)
    return isThemePreference(stored) ? stored : 'dark'
  } catch {
    return 'dark'
  }
}

export function resolveTheme(preference: ThemePreference): ResolvedTheme {
  if (preference !== 'system') return preference
  if (typeof window === 'undefined') return 'dark'
  return window.matchMedia(SYSTEM_THEME_QUERY).matches ? 'dark' : 'light'
}

export function applyTheme(preference: ThemePreference = getThemePreference()): ResolvedTheme {
  const resolved = resolveTheme(preference)
  if (typeof document !== 'undefined') {
    document.documentElement.dataset.theme = resolved
    document.documentElement.dataset.themePreference = preference
    document.documentElement.style.colorScheme = resolved
    setBrowserChromeColor(BROWSER_CHROME_COLORS[resolved])
  }
  return resolved
}

export function initializeTheme(): ResolvedTheme {
  return applyTheme(getThemePreference())
}

export function setThemePreference(preference: ThemePreference): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(THEME_STORAGE_KEY, preference)
  } catch {
    // Private browsing and embedded runtimes may deny storage. The active
    // document should still honor the user's choice for this session.
  }
  applyTheme(preference)
  window.dispatchEvent(new CustomEvent(THEME_CHANGE_EVENT, { detail: preference }))
}

function subscribeToTheme(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => undefined
  const media = window.matchMedia(SYSTEM_THEME_QUERY)
  const handlePreferenceChange = () => {
    applyTheme(getThemePreference())
    callback()
  }
  const handleSystemChange = () => {
    if (getThemePreference() !== 'system') return
    applyTheme('system')
    callback()
  }

  window.addEventListener('storage', handlePreferenceChange)
  window.addEventListener(THEME_CHANGE_EVENT, handlePreferenceChange)
  media.addEventListener('change', handleSystemChange)
  return () => {
    window.removeEventListener('storage', handlePreferenceChange)
    window.removeEventListener(THEME_CHANGE_EVENT, handlePreferenceChange)
    media.removeEventListener('change', handleSystemChange)
  }
}

export function useThemePreference() {
  const preference = useSyncExternalStore(
    subscribeToTheme,
    getThemePreference,
    () => 'dark' as ThemePreference,
  )
  const setPreference = useCallback((nextPreference: ThemePreference) => {
    setThemePreference(nextPreference)
  }, [])

  return {
    preference,
    resolvedTheme: resolveTheme(preference),
    setPreference,
  }
}

export function getBorderPreference(): BorderPreference {
  if (typeof window === 'undefined') return 'on'
  try {
    const stored = window.localStorage.getItem(BORDER_STORAGE_KEY)
    return isBorderPreference(stored) ? stored : 'on'
  } catch {
    return 'on'
  }
}

export function applyBorderPreference(preference: BorderPreference = getBorderPreference()): BorderPreference {
  if (typeof document !== 'undefined') {
    document.documentElement.dataset.borders = preference
  }
  return preference
}

export function initializeBorders(): BorderPreference {
  return applyBorderPreference(getBorderPreference())
}

export function setBorderPreference(preference: BorderPreference): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(BORDER_STORAGE_KEY, preference)
  } catch {
    // The active document should still honor the user's choice for this session.
  }
  applyBorderPreference(preference)
  window.dispatchEvent(new CustomEvent(BORDER_CHANGE_EVENT, { detail: preference }))
}

function subscribeToBorders(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => undefined
  const handleChange = () => {
    applyBorderPreference(getBorderPreference())
    callback()
  }
  window.addEventListener('storage', handleChange)
  window.addEventListener(BORDER_CHANGE_EVENT, handleChange)
  return () => {
    window.removeEventListener('storage', handleChange)
    window.removeEventListener(BORDER_CHANGE_EVENT, handleChange)
  }
}

export function useBorderPreference() {
  const preference = useSyncExternalStore(
    subscribeToBorders,
    getBorderPreference,
    () => 'on' as BorderPreference,
  )
  const setEnabled = useCallback((enabled: boolean) => {
    setBorderPreference(enabled ? 'on' : 'off')
  }, [])

  return {
    preference,
    enabled: preference === 'on',
    setEnabled,
  }
}
