import { Check, ChevronsUpDown } from 'lucide-react'
import { Button } from '#nebula/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { cn } from '#nebula/lib/utils'
import { menuItemVariants } from './floating-variants'

export interface MultiSelectOption {
  value: string
  label: string
  description?: string
}

interface MultiSelectProps {
  options: MultiSelectOption[]
  value: string[]
  onChange: (value: string[]) => void
  placeholder?: string
  disabled?: boolean
  appearance?: 'field' | 'row'
}

export function MultiSelect({ options, value, onChange, placeholder = 'Select options', disabled, appearance = 'field' }: MultiSelectProps) {
  const selectedLabels = options.filter(option => value.includes(option.value)).map(option => option.label)
  const label = selectedLabels.length === 0
    ? placeholder
    : selectedLabels.length <= 2
      ? selectedLabels.join(', ')
      : `${selectedLabels.slice(0, 2).join(', ')} +${selectedLabels.length - 2}`

  const toggle = (option: string) => {
    onChange(value.includes(option)
      ? value.filter(item => item !== option)
      : [...value, option])
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          disabled={disabled}
          aria-haspopup="listbox"
          className={cn(
            'h-[var(--control-height-field)] min-w-0 justify-between rounded-[var(--radius-control)] px-3 text-[12px] font-medium text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]',
            appearance === 'field'
              ? 'w-full bg-[var(--color-surface-field)] hover:bg-[var(--color-surface-field-focus)]'
              : 'w-full bg-transparent sm:w-auto sm:min-w-64 sm:justify-end hover:bg-white/[0.04]',
          )}
        >
          <span className={cn('truncate', selectedLabels.length === 0 && 'text-[var(--color-text-disabled)]')}>{label}</span>
          <ChevronsUpDown size={13} className="shrink-0 text-[var(--color-text-disabled)]" />
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        className="p-1"
        style={{ width: 'var(--radix-popover-trigger-width)' }}
      >
        <div role="listbox" aria-multiselectable="true" className="max-h-52 overflow-y-auto">
          {options.length === 0 ? (
            <p className="px-2 py-2 text-[12px] text-[var(--color-text-disabled)]">No options available.</p>
          ) : options.map(option => {
            const selected = value.includes(option.value)
            return (
              <button
                key={option.value}
                type="button"
                role="option"
                aria-selected={selected}
                onClick={() => toggle(option.value)}
                className={cn(menuItemVariants({ selected }), 'gap-2 py-2')}
              >
                <span className={cn(
                  'flex h-4 w-4 shrink-0 items-center justify-center rounded border',
                  selected ? 'border-[var(--color-border-focus)] bg-[var(--color-surface-selected)] text-[var(--color-text-primary)]' : 'border-[var(--color-border-strong)] text-transparent',
                )}>
                  <Check size={11} strokeWidth={2.5} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate">{option.label}</span>
                  {option.description && <span className="block truncate text-[10px] text-[var(--color-text-disabled)]">{option.description}</span>}
                </span>
              </button>
            )
          })}
        </div>
      </PopoverContent>
    </Popover>
  )
}
