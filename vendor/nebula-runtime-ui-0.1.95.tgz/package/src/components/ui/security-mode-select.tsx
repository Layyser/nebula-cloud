import { useEffect, useState } from 'react'
import { ChevronDown } from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from './popover'
import { Tooltip, TooltipContent, TooltipTrigger } from './tooltip'
import { SecurityModeIcon } from './runtime-metadata'
import type { SecurityMode } from '#nebula/lib/api'
import { cn } from '#nebula/lib/utils'

const modes: Array<{ mode: SecurityMode; title: string; description: string }> = [
  { mode: 'default', title: 'Default', description: 'Agent permissions apply; approved tools may write anywhere.' },
  { mode: 'sandbox', title: 'Sandbox', description: 'Agent permissions apply; writes stay inside the workspace.' },
  { mode: 'full', title: 'Full access', description: 'No tool approvals; unrestricted filesystem access.' },
]

function modeLabel(mode: SecurityMode) {
  return modes.find(option => option.mode === mode)?.title ?? 'Default'
}

export function SecurityModeSelect({
  mode,
  selectedMode = mode,
  onChange,
  disabled = false,
  appearance = 'composer',
  side = appearance === 'composer' ? 'top' : 'bottom',
}: {
  mode: SecurityMode
  selectedMode?: SecurityMode
  onChange: (mode: SecurityMode) => void
  disabled?: boolean
  appearance?: 'composer' | 'field' | 'row'
  side?: 'top' | 'bottom'
}) {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (disabled) setOpen(false)
  }, [disabled])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <Tooltip open={open ? false : undefined}>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <button
              type="button"
              disabled={disabled}
              aria-label={`Security mode: ${modeLabel(mode)}`}
              className={cn(
                'flex items-center gap-1.5 text-[12px] font-medium text-white/60 outline-none transition-colors duration-150 hover:text-white/90 disabled:opacity-40',
                appearance === 'composer'
                  ? 'h-7 rounded-lg px-2.5 hover:bg-white/[0.06]'
                  : appearance === 'field'
                    ? 'ui-border-control h-[var(--control-height-field)] w-full justify-between rounded-[var(--radius-control)] bg-[var(--color-surface-input)] px-3 hover:bg-[var(--color-surface-field-focus)]'
                    : 'h-[var(--control-height-field)] w-full justify-between rounded-[var(--radius-control)] px-3 sm:w-auto sm:min-w-52 hover:bg-white/[0.04]',
                open && 'bg-white/[0.06] text-white/90',
              )}
            >
              <span className="flex min-w-0 items-center gap-1.5">
                <SecurityModeIcon mode={mode} />
                <span>{modeLabel(mode)}</span>
              </span>
              <ChevronDown size={11} className={cn('shrink-0 transition-transform duration-150', open && 'rotate-180')} />
            </button>
          </PopoverTrigger>
        </TooltipTrigger>
        <TooltipContent side={side}>Security mode</TooltipContent>
      </Tooltip>

      <PopoverContent side={side} align="start" className="w-72 max-w-[calc(100vw-1rem)]" onOpenAutoFocus={event => event.preventDefault()} onCloseAutoFocus={event => event.preventDefault()}>
        {modes.map(option => (
          <button
            key={option.mode}
            type="button"
            onClick={() => { onChange(option.mode); setOpen(false) }}
            className={cn(
              'flex w-full items-start gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors duration-100',
              selectedMode === option.mode ? 'bg-white/[0.08]' : 'hover:bg-white/[0.05]',
            )}
          >
            <span className="mt-0.5"><SecurityModeIcon mode={option.mode} /></span>
            <span className="min-w-0">
              <span className={cn('block text-[12px] font-medium', selectedMode === option.mode ? 'text-white/90' : 'text-white/65')}>{option.title}</span>
              <span className="mt-0.5 block text-[11px] leading-4 text-white/35">{option.description}</span>
            </span>
          </button>
        ))}
      </PopoverContent>
    </Popover>
  )
}
