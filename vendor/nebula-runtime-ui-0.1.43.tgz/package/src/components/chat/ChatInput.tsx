import { useState, useRef, useCallback, useEffect } from 'react'
import { ArrowUp, Square, Paperclip, ChevronDown, BrainCircuit, X, Bot, Folder, Shield, ShieldAlert, ShieldCheck } from 'lucide-react'
import { cn } from '#nebula/lib/utils'
import { Popover, PopoverContent, PopoverTrigger } from '#nebula/components/ui/popover'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '#nebula/components/ui/tooltip'
import { type AgentInfo, type ModelInfo, type ReasoningEffort, type ReasoningEffortChoice, type SecurityMode, type SessionInfo } from '#nebula/lib/api'

interface Props {
  onSend: (text: string, files?: File[]) => void | Promise<void>
  onAbort: () => void
  streaming: boolean
  disabled?: boolean
  placeholder?: string
  session: SessionInfo | null
  agents: AgentInfo[]
  pendingAgent: string | null
  onSwitchAgent: (name: string | null) => void
  lockedAgent?: string
  securityMode?: SecurityMode
  onSwitchSecurityMode?: (mode: SecurityMode) => void
  cwd?: string
  workspaceRoot?: string
  onSwitchCwd?: (path: string) => Promise<void>
  reasoningEffort?: ReasoningEffort
  reasoningEffortOverride?: ReasoningEffort | null
  inheritedReasoningEffort?: ReasoningEffort
  onSwitchReasoningEffort?: (effort: ReasoningEffortChoice) => void
  models?: ModelInfo[]
  model?: string
  modelOverride?: string | null
  inheritedModel?: string
  onSwitchModel?: (model: string | 'default') => void
}

function formatAgentName(agentName: string): string {
  return agentName
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase())
}

function projectLabel(cwd: string, workspaceRoot?: string): string {
  if (!cwd || cwd === '.' || cwd === workspaceRoot) return 'Workspace'
  const normalized = cwd.replace(/\\/g, '/').replace(/\/$/, '')
  const root = workspaceRoot?.replace(/\\/g, '/').replace(/\/$/, '')
  const relative = root && normalized.startsWith(`${root}/`)
    ? normalized.slice(root.length + 1)
    : normalized
  if (!relative) return 'Workspace'
  const label = relative.split('/').filter(Boolean).at(-1) ?? 'Workspace'
  return label.toLowerCase() === 'workspace' ? 'Workspace' : label
}

async function pickProjectDirectory(): Promise<string | null> {
  if (!("__TAURI_INTERNALS__" in window)) return null
  const { invoke } = await import('@tauri-apps/api/core')
  return invoke<string | null>('pick_project_directory')
}

export function ChatInput({ onSend, onAbort, streaming, disabled, placeholder, agents, pendingAgent, onSwitchAgent, lockedAgent, securityMode = 'default', onSwitchSecurityMode, cwd = '.', workspaceRoot, onSwitchCwd, reasoningEffort = 'medium', reasoningEffortOverride = null, inheritedReasoningEffort = 'medium', onSwitchReasoningEffort, models = [], model = '', modelOverride = null, inheritedModel = '', onSwitchModel }: Props) {
  const [value, setValue]     = useState('')
  const [files, setFiles]     = useState<File[]>([])
  const [agentOpen, setAgentOpen] = useState(false)
  const [securityOpen, setSecurityOpen] = useState(false)
  const [projectOpen, setProjectOpen] = useState(false)
  const [projectPath, setProjectPath] = useState(cwd)
  const [projectError, setProjectError] = useState('')
  const [projectPicking, setProjectPicking] = useState(false)
  const [runtimeOpen, setRuntimeOpen] = useState(false)

  // Effort options follow the selected model's reasoning_efforts when the
  // runtime advertises them; otherwise fall back to the standard levels.
  const activeModel = models.find(m => m.slug === (modelOverride ?? model))
  const effortOptions = activeModel?.reasoning_efforts?.length
    ? activeModel.reasoning_efforts
    : EFFORTS

  // The default effort must belong to the active model's supported set. A
  // hardcoded "medium" misrepresents models that omit it (for example
  // deepseek-v4-flash -> low/high/max), so fall back to the model's first
  // supported level when the inherited value is not accepted.
  const effectiveEffort: ReasoningEffort = reasoningEffortOverride !== null
    ? reasoningEffort
    : (effortOptions.includes(inheritedReasoningEffort)
        ? inheritedReasoningEffort
        : (effortOptions[0] as ReasoningEffort | undefined) ?? inheritedReasoningEffort)

  const [draftEffort, setDraftEffort] = useState<ReasoningEffort>(effectiveEffort)

  useEffect(() => setDraftEffort(effectiveEffort), [effectiveEffort])

  useEffect(() => setProjectPath(cwd), [cwd])
  useEffect(() => {
    if (!streaming) return
    setAgentOpen(false)
    setSecurityOpen(false)
    setProjectOpen(false)
    setRuntimeOpen(false)
  }, [streaming])
  useEffect(() => {
    if (draftEffort === effectiveEffort || !onSwitchReasoningEffort) return
    const timer = window.setTimeout(() => onSwitchReasoningEffort(draftEffort), 120)
    return () => window.clearTimeout(timer)
  }, [draftEffort, effectiveEffort, onSwitchReasoningEffort])

  const selectedAgent = lockedAgent ?? pendingAgent
  const defaultAgent = agents.find(agent => agent.name === 'Default')
  const configuredAgents = agents.filter(agent => agent.name !== 'Default')

  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const activeAgentRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (agentOpen) requestAnimationFrame(() => activeAgentRef.current?.focus())
  }, [agentOpen])

  const submit = useCallback(() => {
    const text = value.trim()
    if (!text || streaming) return
    setValue('')
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
    const attachments = files.length ? [...files] : undefined
    setFiles([])
    void Promise.resolve(onSend(text, attachments)).catch(error => {
      setValue(text)
      if (attachments) setFiles(attachments)
      setProjectError(error instanceof Error ? error.message : String(error))
      setProjectOpen(true)
    })
  }, [value, streaming, files, onSend])

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.altKey) { e.preventDefault(); submit() }
  }

  const onTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setValue(e.target.value)
    const ta = e.target
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 240) + 'px'
  }

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = Array.from(e.target.files ?? [])
    setFiles(prev => [...prev, ...picked])
    e.target.value = ''
  }

  const removeFile = (idx: number) =>
    setFiles(prev => prev.filter((_, i) => i !== idx))

  const canSend = value.trim().length > 0 && !streaming && !disabled

  return (
    <div className="shrink-0 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pointer-events-auto sm:px-4 sm:pb-6">
      <div className="mx-auto w-full min-w-0 max-w-[var(--content-width-reading)]">
        <div
          className={cn(
            'relative flex min-w-0 max-w-full flex-col rounded-xl outline-none transition-shadow duration-[var(--motion-duration-deliberate)]',
            'focus-within:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color)] focus-within:outline-offset-1',
          )}
          style={{
            background: 'var(--color-surface-panel)',
            boxShadow: 'var(--shadow-surface)',
          }}
        >
          {/* File chips */}
          {files.length > 0 && (
            <div className="flex flex-wrap gap-1.5 px-4 pb-2 pt-3">
              {files.map((f, i) => (
                <span
                  key={i}
                  className="flex max-w-[180px] items-center gap-1.5 rounded-lg bg-white/[0.07] px-2 py-1 text-[11px] text-white/70"
                >
                  <Paperclip size={10} className="shrink-0 text-white/40" />
                  <span className="truncate">{f.name}</span>
                  <button onClick={() => removeFile(i)} className="shrink-0 text-white/40 hover:text-white/70 transition-colors">
                    <X size={10} />
                  </button>
                </span>
              ))}
            </div>
          )}

          {/* Textarea */}
          <textarea
            ref={textareaRef}
            rows={1}
            value={value}
            onChange={onTextChange}
            onKeyDown={onKeyDown}
            disabled={disabled}
            placeholder={placeholder ?? 'Send a message…'}
            className={cn(
              'w-full resize-none bg-transparent text-[14px] text-white/90',
              'placeholder:text-white/40 focus:outline-none',
              'leading-relaxed min-h-[56px] max-h-[240px]',
              'px-4 pb-2',
              files.length > 0 ? 'pt-2' : 'pt-4',
              'disabled:opacity-50',
            )}
            style={{ scrollbarWidth: 'thin', scrollbarColor: 'rgba(255,255,255,0.15) transparent' }}
          />

          {/* Bottom toolbar */}
          <TooltipProvider delayDuration={0} disableHoverableContent>
          <div className="flex min-w-0 items-center gap-1 px-2.5 pb-2.5 pt-1 sm:gap-2 sm:px-3 sm:pb-3">

            <div className="flex w-0 min-w-0 flex-1 items-center gap-1 overflow-x-auto overscroll-x-contain [scrollbar-width:none] [&>*]:shrink-0 [&::-webkit-scrollbar]:hidden">

              {/* Attach */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    aria-label="Attach a file"
                    className="flex items-center justify-center w-7 h-7 rounded-lg text-white/60 hover:text-white/90 hover:bg-white/[0.06] transition-colors duration-150"
                  >
                    <Paperclip size={14} />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top">Attach a file</TooltipContent>
              </Tooltip>
              <input ref={fileInputRef} type="file" multiple hidden onChange={onFileChange} />

              {onSwitchCwd && <div className="mx-0.5 h-4 w-px bg-white/[0.08]" />}

              {onSwitchCwd && (
                <Popover open={projectOpen} onOpenChange={setProjectOpen}>
                  <Tooltip open={projectOpen ? false : undefined}>
                    <TooltipTrigger asChild>
                      <PopoverTrigger asChild>
                        <button
                          type="button"
                          disabled={streaming}
                          aria-label={`Session project directory: ${projectLabel(cwd, workspaceRoot)}`}
                          className={cn(
                            'flex h-7 max-w-24 items-center gap-1.5 rounded-lg px-2 text-[12px] font-medium sm:max-w-36 sm:px-2.5',
                            'text-white/60 transition-colors duration-150 hover:bg-white/[0.06] hover:text-white/90 disabled:opacity-40',
                            projectOpen && 'bg-white/[0.06] text-white/90',
                          )}
                        >
                          <Folder size={15} className="shrink-0 text-white/40" />
                          <span className="truncate">{projectLabel(cwd, workspaceRoot)}</span>
                        </button>
                      </PopoverTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="top">Session project directory</TooltipContent>
                  </Tooltip>
                  <PopoverContent side="top" align="start" sideOffset={8} className="w-72 max-w-[calc(100vw-1rem)] min-w-0" onOpenAutoFocus={e => e.preventDefault()} onCloseAutoFocus={e => e.preventDefault()}>
                    <form
                      onSubmit={event => {
                        event.preventDefault()
                        setProjectError('')
                        void onSwitchCwd(projectPath)
                          .then(() => setProjectOpen(false))
                          .catch(error => setProjectError(error instanceof Error ? error.message : String(error)))
                      }}
                      className="space-y-3 px-1 py-0.5"
                    >
                      <div>
                        <p className="text-[12px] font-semibold text-white/90">Session workspace</p>
                        <p className="mt-1 text-[11px] leading-relaxed text-white/45">Choose a folder or enter a path. Bash and file tools start here.</p>
                      </div>
                      <div className="flex gap-1.5">
                        <input
                          value={projectPath}
                          onChange={event => setProjectPath(event.target.value)}
                          placeholder=". or path/to/project"
                          className="h-8 min-w-0 flex-1 rounded-lg bg-[var(--color-surface-overlay-field)] px-2.5 font-mono text-[11px] text-white/75 outline-none placeholder:text-white/25 focus:bg-[var(--color-surface-overlay-field-focus)]"
                        />
                        {'__TAURI_INTERNALS__' in window && (
                          <button
                            type="button"
                            disabled={projectPicking}
                            onClick={() => {
                              setProjectError('')
                              setProjectPicking(true)
                              void pickProjectDirectory()
                                .then(async path => {
                                  if (!path) return
                                  setProjectPath(path)
                                  await onSwitchCwd(path)
                                  setProjectOpen(false)
                                })
                                .catch(error => setProjectError(error instanceof Error ? error.message : String(error)))
                                .finally(() => setProjectPicking(false))
                            }}
                            aria-label="Browse for project folder"
                            className="flex h-8 shrink-0 items-center justify-center gap-1.5 rounded-lg px-2 text-[11px] font-medium text-white/50 transition-colors hover:bg-white/[0.06] hover:text-white/80 disabled:opacity-40"
                          >
                            <Folder size={13} />
                            Browse
                          </button>
                        )}
                      </div>
                      {projectError && <p className="text-[11px] leading-4 text-[var(--color-status-danger)]">{projectError}</p>}
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => { setProjectPath(cwd); setProjectError(''); setProjectOpen(false) }}
                          className="flex h-7 flex-1 items-center justify-center rounded-lg pt-0.5 text-[11px] font-medium text-white/50 transition-colors hover:bg-white/[0.06] hover:text-white/80"
                        >
                          Cancel
                        </button>
                        <button type="submit" className="flex h-7 flex-1 items-center justify-center rounded-lg bg-white pt-0.5 text-[11px] font-medium text-black transition-colors hover:bg-white/90">Use folder</button>
                      </div>
                    </form>
                  </PopoverContent>
                </Popover>
              )}

              {onSwitchSecurityMode && (
                <>
                  <div className="w-px h-4 bg-white/[0.08] mx-0.5" />

                  <Popover open={securityOpen} onOpenChange={setSecurityOpen}>
                    <Tooltip open={securityOpen ? false : undefined}>
                      <TooltipTrigger asChild>
                        <PopoverTrigger asChild>
                          <button
                            type="button"
                            disabled={streaming}
                            aria-label={`Security mode: ${securityMode === 'full' ? 'Full access' : securityMode === 'sandbox' ? 'Sandbox' : 'Default'}`}
                            className={cn(
                              'flex h-7 items-center gap-1.5 rounded-lg px-2.5 text-[12px] font-medium',
                              'text-white/60 transition-colors duration-150 hover:bg-white/[0.06] hover:text-white/90 disabled:opacity-40',
                              securityOpen && 'bg-white/[0.06] text-white/90',
                            )}
                          >
                            <SecurityIcon mode={securityMode} />
                            <span className="hidden sm:inline">{securityMode === 'full' ? 'Full access' : securityMode === 'sandbox' ? 'Sandbox' : 'Default'}</span>
                            <ChevronDown size={11} className={cn('hidden transition-transform duration-150 sm:block', securityOpen && 'rotate-180')} />
                          </button>
                        </PopoverTrigger>
                      </TooltipTrigger>
                      <TooltipContent side="top">Security mode</TooltipContent>
                    </Tooltip>

                    <PopoverContent side="top" align="start" className="w-72 max-w-[calc(100vw-1rem)]" onOpenAutoFocus={e => e.preventDefault()} onCloseAutoFocus={e => e.preventDefault()}>
                      <SecurityOption
                        mode="default"
                        active={securityMode === 'default'}
                        title="Default"
                        description="Agent permissions apply; approved tools may write anywhere."
                        onClick={() => { onSwitchSecurityMode('default'); setSecurityOpen(false) }}
                      />
                      <SecurityOption
                        mode="sandbox"
                        active={securityMode === 'sandbox'}
                        title="Sandbox"
                        description="Agent permissions apply; writes stay inside the workspace."
                        onClick={() => { onSwitchSecurityMode('sandbox'); setSecurityOpen(false) }}
                      />
                      <SecurityOption
                        mode="full"
                        active={securityMode === 'full'}
                        title="Full access"
                        description="No tool approvals; unrestricted filesystem access."
                        onClick={() => { onSwitchSecurityMode('full'); setSecurityOpen(false) }}
                      />
                    </PopoverContent>
                  </Popover>
                </>
              )}

              <div className="w-px h-4 bg-white/[0.08] mx-0.5" />

              {/* Agent selector */}
              {lockedAgent ? (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center gap-1.5 h-7 px-2 sm:px-2.5 rounded-lg text-[12px] font-medium text-white/70 bg-white/[0.04] select-none">
                      <Bot size={15} className="shrink-0 text-white/45" />
                      <span className="hidden sm:inline">{formatAgentName(lockedAgent)}</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent side="top">Configurer is selected for agent creation</TooltipContent>
                </Tooltip>
              ) : (
                <Popover open={agentOpen} onOpenChange={setAgentOpen}>
                  <Tooltip open={agentOpen ? false : undefined}>
                    <TooltipTrigger asChild>
                      <PopoverTrigger asChild>
                        <button
                          type="button"
                          disabled={streaming}
                          aria-label={`Agent: ${selectedAgent ? formatAgentName(selectedAgent) : 'Default'}`}
                          className={cn(
                            'flex items-center gap-1.5 h-7 px-2 sm:px-2.5 rounded-lg text-[12px] font-medium',
                            'text-white/60 hover:text-white/90 hover:bg-white/[0.06]',
                            'transition-colors duration-150 select-none disabled:pointer-events-none disabled:opacity-40',
                            agentOpen && 'bg-white/[0.06] text-white/90',
                          )}
                        >
                          <Bot size={15} className="shrink-0 text-white/40" />
                          <span className="hidden sm:inline">{selectedAgent ? formatAgentName(selectedAgent) : 'Default'}</span>
                          <ChevronDown size={11} className={cn('hidden transition-transform duration-150 sm:block', agentOpen && 'rotate-180')} />
                        </button>
                      </PopoverTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="top">Agent selection</TooltipContent>
                  </Tooltip>

                  <PopoverContent side="top" align="start" onOpenAutoFocus={e => e.preventDefault()} onCloseAutoFocus={e => e.preventDefault()}>
                    <TooltipProvider delayDuration={400} disableHoverableContent>
                      <AgentOption
                        label="Default"
                        active={!selectedAgent}
                        activeRef={!selectedAgent ? activeAgentRef : undefined}
                        tooltipContent={defaultAgent
                          ? <AgentTooltipBody agent={defaultAgent} />
                          : (
                            <div className="space-y-1">
                              <p className="text-[11px] font-medium text-white/80">Default session</p>
                              <p className="text-[11px] text-white/45">Using default .nebula/ config</p>
                            </div>
                          )}
                        onClick={() => { onSwitchAgent(null); setAgentOpen(false) }}
                      />
                      {configuredAgents.map(a => (
                        <AgentOption
                          key={a.name}
                          label={formatAgentName(a.name)}
                          active={a.name === selectedAgent}
                          activeRef={a.name === selectedAgent ? activeAgentRef : undefined}
                          tooltipContent={<AgentTooltipBody agent={a} />}
                          onClick={() => { onSwitchAgent(a.name); setAgentOpen(false) }}
                        />
                      ))}
                    </TooltipProvider>
                  </PopoverContent>
                </Popover>
              )}

              <div className="w-px h-4 bg-white/[0.08] mx-0.5" />

              {/* Model and reasoning selector */}
              {onSwitchReasoningEffort && onSwitchModel && (
                <Popover open={runtimeOpen} onOpenChange={setRuntimeOpen}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <PopoverTrigger asChild>
                        <button
                          type="button"
                          disabled={streaming}
                          aria-label={`Model and reasoning: ${model}, ${effortLabel(effectiveEffort)}`}
                          className={cn(
                            'flex h-7 max-w-52 items-center gap-1.5 rounded-lg px-2 text-[12px] font-medium sm:px-2.5',
                            'text-white/60 transition-colors duration-150 hover:bg-white/[0.06] hover:text-white/90 disabled:opacity-40',
                            runtimeOpen && 'bg-white/[0.06] text-white/90',
                          )}
                        >
                          <BrainCircuit size={15} className="shrink-0 text-white/45" />
                          <span className="hidden min-w-0 truncate sm:inline">{shortModelName(model)}</span>
                          <span className="hidden text-white/25 sm:inline">·</span>
                          <span className="hidden sm:inline">{effortLabel(effectiveEffort)}</span>
                          <ChevronDown size={11} className={cn('hidden shrink-0 transition-transform duration-150 sm:block', runtimeOpen && 'rotate-180')} />
                        </button>
                      </PopoverTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="top">Model and reasoning</TooltipContent>
                  </Tooltip>

                  <PopoverContent side="top" align="start" className="w-72 max-w-[calc(100vw-1rem)] p-0" onOpenAutoFocus={e => e.preventDefault()} onCloseAutoFocus={e => e.preventDefault()}>
                    <div className="px-3 pt-3">
                      <div className="text-[11px] font-medium uppercase tracking-[0.12em] text-white/35">Model</div>
                      <div className="-mx-1.5 mt-1.5 max-h-52 overflow-y-auto">
                        <ModelOption
                          title={shortModelName(inheritedModel)}
                          description="Default · inherited from agent or global config"
                          active={modelOverride === null}
                          onClick={() => onSwitchModel('default')}
                        />
                        {models.map(option => (
                          <ModelOption
                            key={option.slug}
                            title={option.display_name || option.slug}
                            description={option.description}
                            active={modelOverride === option.slug}
                            onClick={() => onSwitchModel(option.slug)}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="px-3 pb-3 pt-3">
                      <div className="text-[11px] font-medium uppercase tracking-[0.12em] text-white/35">Effort</div>
                      <div className="mt-1.5 flex items-center justify-between">
                        <div className="text-[12px] font-medium text-white/75">
                          {reasoningEffortOverride === null
                            ? (effortOptions.includes(inheritedReasoningEffort)
                                ? `Default · ${effortLabel(inheritedReasoningEffort)}`
                                : effortLabel(effectiveEffort))
                            : effortLabel(reasoningEffort)}
                        </div>
                        {reasoningEffortOverride !== null && effortOptions.includes(inheritedReasoningEffort) && (
                          <button type="button" onClick={() => onSwitchReasoningEffort('default')} className="rounded-md px-1.5 py-1 text-[11px] text-white/40 transition-colors hover:bg-white/[0.05] hover:text-white/70">
                            Use default
                          </button>
                        )}
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={Math.max(0, effortOptions.length - 1)}
                        step={1}
                        value={effortIndex(draftEffort, effortOptions)}
                        aria-label="Reasoning effort"
                        aria-valuetext={effortLabel(effectiveEffort)}
                        onChange={event => setDraftEffort(effortOptions[Number(event.target.value)] as ReasoningEffort)}
                        className="reasoning-slider mt-2 block w-full"
                      />
                      <div className="mt-1.5 flex justify-between text-[10px] text-white/30">
                        {effortOptions.map(effort => <span key={effort}>{effortLabel(effort)}</span>)}
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>
              )}
            </div>

            {/* Send / abort */}
            <div className="ml-1 flex shrink-0 items-center sm:ml-2">
              <button
                onClick={streaming ? onAbort : submit}
                disabled={!streaming && !canSend}
                aria-label={streaming ? 'Stop response' : 'Send message'}
                className={cn(
                  'flex items-center justify-center w-8 h-8 rounded-lg transition-all duration-150 shrink-0',
                  streaming
                    ? 'bg-white/88 text-black hover:bg-white/95 shadow-md'
                    : canSend
                      ? 'bg-white/88 text-black hover:bg-white/95 shadow-md'
                      : 'bg-white/[0.08] text-white/35 cursor-not-allowed',
                )}
              >
                {streaming ? <Square size={12} fill="currentColor" /> : <ArrowUp size={15} strokeWidth={2.5} />}
              </button>
            </div>
          </div>
          </TooltipProvider>
        </div>
      </div>
    </div>
  )
}

function SecurityIcon({ mode }: { mode: SecurityMode }) {
  if (mode === 'sandbox') return <ShieldCheck size={15} className="shrink-0 text-[var(--color-status-success)]" />
  if (mode === 'full') return <ShieldAlert size={15} className="shrink-0 text-amber-400/75" />
  return <Shield size={15} className="shrink-0 text-white/40" />
}

function SecurityOption({ mode, active, title, description, onClick }: {
  mode: SecurityMode
  active: boolean
  title: string
  description: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex w-full items-start gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors duration-100',
        active ? 'bg-white/[0.08]' : 'hover:bg-white/[0.05]',
      )}
    >
      <span className="mt-0.5"><SecurityIcon mode={mode} /></span>
      <span className="min-w-0">
        <span className={cn('block text-[12px] font-medium', active ? 'text-white/90' : 'text-white/65')}>{title}</span>
        <span className="mt-0.5 block text-[11px] leading-4 text-white/35">{description}</span>
      </span>
    </button>
  )
}

function effortLabel(effort: string): string {
  return effort === 'xhigh' ? 'XHigh' : effort[0].toUpperCase() + effort.slice(1)
}

const EFFORTS: ReasoningEffort[] = ['low', 'medium', 'high', 'xhigh']

function effortIndex(effort: ReasoningEffort, options: readonly string[]): number {
  return Math.max(0, options.indexOf(effort))
}

function shortModelName(model: string): string {
  if (!model) return 'Default model'
  const slash = model.lastIndexOf('/')
  return slash >= 0 ? model.slice(slash + 1) : model
}

function ModelOption({ active, title, description, onClick }: {
  active: boolean
  title: string
  description?: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex w-full items-start rounded-lg px-2.5 py-2 text-left transition-colors duration-100',
        active ? 'bg-white/[0.08]' : 'hover:bg-white/[0.05]',
      )}
    >
      <span className="min-w-0">
        <span className={cn('block text-[12px] font-medium', active ? 'text-white/90' : 'text-white/65')}>{title}</span>
        {description && <span className="mt-0.5 block whitespace-normal text-[11px] leading-4 text-white/35">{description}</span>}
      </span>
    </button>
  )
}

function AgentOption({ label, active, activeRef, tooltipContent, onClick }: {
  label: string
  active: boolean
  activeRef?: React.RefObject<HTMLButtonElement | null>
  tooltipContent: React.ReactNode
  onClick: () => void
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          ref={active ? activeRef : undefined}
          onClick={onClick}
          className={cn(
            'flex w-full items-center rounded-lg px-2.5 py-1.5 text-[12px] font-medium transition-colors duration-100',
            active
              ? 'bg-white/[0.08] text-white'
              : 'text-white/60 hover:bg-white/[0.05] hover:text-white/90',
          )}
        >
          {label}
        </button>
      </TooltipTrigger>
      <TooltipContent side="right" sideOffset={8} className="max-w-[220px] pb-2.5 pt-3">
        {tooltipContent}
      </TooltipContent>
    </Tooltip>
  )
}

function AgentTooltipBody({ agent }: { agent: AgentInfo }) {
  const params = [
    agent.model       && `model: ${agent.model}`,
    agent.temperature !== undefined && `temp: ${agent.temperature}`,
    agent.max_tokens  !== undefined && `max_tokens: ${agent.max_tokens}`,
    agent.reasoning_effort && `effort: ${agent.reasoning_effort}`,
    agent.thinking    !== undefined && `thinking: ${agent.thinking}`,
  ].filter(Boolean) as string[]

  return (
    <div className="space-y-2">
      {agent.description && (
        <p className="text-[11px] text-white/70">{agent.description}</p>
      )}

      {params.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {params.map(p => (
            <span key={p} className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-white/[0.06] text-white/50">{p}</span>
          ))}
        </div>
      )}

      {agent.tools && Object.keys(agent.tools).length > 0 && (
        <div>
          <p className="text-[10px] font-semibold text-white/35 uppercase tracking-widest select-none mb-1">Tools</p>
          <div className="flex flex-wrap gap-1">
            {Object.entries(agent.tools).map(([tool, perm]) => (
              <span
                key={tool}
                className={cn(
                  'text-[10px] font-mono px-1.5 py-0.5 rounded-md',
                  perm === 'allow' && 'bg-[var(--color-status-success-surface)] text-[var(--color-status-success)]',
                  perm === 'ask'   && 'bg-[var(--color-status-warning-surface)] text-[var(--color-status-warning)]',
                  perm === 'deny'  && 'bg-[var(--color-status-danger-surface)] text-[var(--color-status-danger)]',
                )}
              >
                {tool}: {perm}
              </span>
            ))}
          </div>
        </div>
      )}

      {agent.mcp && agent.mcp.length > 0 && (
        <div>
          <p className="text-[10px] font-semibold text-white/35 uppercase tracking-widest select-none mb-1">MCP</p>
          <div className="flex flex-wrap gap-1">
            {agent.mcp.map(s => (
              <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-sky-500/10 text-sky-400/80">{s}</span>
            ))}
          </div>
        </div>
      )}

      {agent.skills && agent.skills.length > 0 && (
        <div>
          <p className="text-[10px] font-semibold text-white/35 uppercase tracking-widest select-none mb-1">Skills</p>
          <div className="flex flex-wrap gap-1">
            {agent.skills.map(s => (
              <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-violet-500/10 text-violet-400/80">{s}</span>
            ))}
          </div>
        </div>
      )}

      {agent.hooks && agent.hooks.length > 0 && (
        <div>
          <p className="text-[10px] font-semibold text-white/35 uppercase tracking-widest select-none mb-1">Hooks</p>
          <div className="flex flex-wrap gap-1">
            {agent.hooks.map(s => (
              <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-sky-400/10 text-sky-300/80">{s}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
