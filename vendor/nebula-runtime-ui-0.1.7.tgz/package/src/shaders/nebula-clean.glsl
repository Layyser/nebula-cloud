#version 300 es
precision highp float;

in vec3 vFragPos;
out vec4 fragColor;

uniform float time;
uniform float aspect;
uniform vec3 uColor1;
uniform vec3 uColor2;
uniform vec3 uColor3;
uniform float uSpeed;
uniform float uDensity;
uniform float uFade;
uniform float uScrollProgress;

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + 1.0), f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.55;
    mat2 turn = mat2(0.86, -0.51, 0.51, 0.86);
    for (int i = 0; i < 4; i++) {
        value += amplitude * noise(p);
        p = turn * p * 2.03 + vec2(1.7, 4.9);
        amplitude *= 0.46;
    }
    return value;
}

void main() {
    vec2 uv = vFragPos.xy;
    uv.x *= aspect;
    float scrollEase = smoothstep(0.0, 1.0, uScrollProgress);
    // Diagnostic: one complete rotation across the hero scroll range.
    float scrollAngle = scrollEase * 6.2831853;
    mat2 scrollRotation = mat2(cos(scrollAngle), -sin(scrollAngle), sin(scrollAngle), cos(scrollAngle));
    uv = scrollRotation * uv;
    uv /= mix(1.0, 1.11, scrollEase);
    uv += vec2(-0.07, 0.09) * scrollEase;
    float t = time * uSpeed;

    // A pair of broad, gently warped ribbons replaces the original cloud stack.
    // Large areas stay quiet while a single luminous structure carries the frame.
    vec2 p = uv * 0.72;
    float slowWarp = fbm(p * 0.72 + vec2(t * 0.08, -t * 0.05)) - 0.5;
    float fineWarp = fbm(p * 1.35 + vec2(-t * 0.04, t * 0.06)) - 0.5;

    float sweepA = p.y + 0.18 * p.x + slowWarp * 0.72;
    float sweepB = p.y - 0.12 * p.x - 0.62 + fineWarp * 0.48;
    float ribbonA = exp(-pow(abs(sweepA) * 1.62, 2.15));
    float ribbonB = exp(-pow(abs(sweepB) * 2.25, 2.0)) * 0.42;

    float bodyNoise = fbm(p * 0.92 + vec2(t * 0.025, 0.0));
    float body = smoothstep(0.16, 0.92, (ribbonA + ribbonB) * (0.68 + bodyNoise * 0.58) * uDensity);
    float core = smoothstep(0.50, 1.0, ribbonA * (0.76 + bodyNoise * 0.38) * uDensity);
    float edge = smoothstep(0.18, 0.72, body) - smoothstep(0.66, 1.0, body);

    vec3 space = uColor1 * 0.018;
    vec3 color = mix(space, uColor3 * 0.58, body);
    color = mix(color, uColor2 * 0.76, core);
    color += uColor2 * edge * 0.055;

    // Sparse pinpoints only in the negative space; deliberately quieter than classic.
    vec2 starGrid = floor((uv + 5.0) * 12.0);
    vec2 starUv = fract((uv + 5.0) * 12.0) - 0.5;
    float starSeed = hash(starGrid);
    float star = smoothstep(0.035, 0.0, length(starUv)) * step(0.982, starSeed);
    color += mix(vec3(1.0), uColor2, 0.18) * star * (1.0 - body) * 0.42;

    float vignette = smoothstep(1.65, 0.20, length(uv * vec2(0.46, 0.68)));
    color *= mix(0.58, 1.0, vignette);

    float grain = hash(gl_FragCoord.xy + fract(time) * 17.0) - 0.5;
    color += grain * 0.004;
    color *= uFade * mix(1.0, 0.12, scrollEase);

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
