import { useCallback, useEffect, useMemo, useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { CheckCircle2, Globe2, Plus, Save, Terminal, Trash2, X } from 'lucide-react'
import { ContextSelect } from '#nebula/components/ui/context-select'
import { Button, IconButton } from '#nebula/components/ui/button'
import { ContentContainer, PageHeader } from '#nebula/components/ui/layout'
import { DocumentAdvanced, DocumentBody, DocumentEditor, DocumentIdentity, DocumentSection, DocumentSettingsGroupTitle, DocumentSettingsRow } from '#nebula/components/ui/document-editor'
import { Tabs, TabsList, TabsTrigger } from '#nebula/components/ui/tabs'
import { capabilityKinds, capabilityMetadata, type CapabilityKind } from '../ui/capability-metadata'
import { MetadataChip } from '../ui/metadata-chip'
import { Checkbox } from '../ui/form'
import {
  deleteCapability, fetchCapabilities, saveFileCapability, saveHook, saveMcp,
  type CapabilityCatalog, type CapabilityFileInfo, type HookInfo, type McpInfo,
} from '#nebula/lib/api'
import { cn } from '#nebula/lib/utils'

interface Props { mcps: McpInfo[]; onRefresh: () => Promise<void> }
type Tab = CapabilityKind
const tabs: Array<{ id: Tab; label: string; icon: React.ReactNode; detail: string }> = capabilityKinds.map(id => {
  const metadata = capabilityMetadata[id]
  const Icon = metadata.icon
  return { id, label: metadata.plural, icon: <Icon size={13} />, detail: metadata.detail }
})
const emptyCatalog: CapabilityCatalog = { mcps: [], skills: [], commands: [], hooks: [], rules: [], tools: [] }
const inputClass = 'ui-border-control w-full resize-none rounded-[var(--radius-control)] bg-[var(--color-surface-input)] px-3 py-2 text-[12px] text-white/80 placeholder:text-[var(--color-text-disabled)] outline-none focus-visible:[outline:var(--focus-ring-width)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-1'
const statusClass = 'mb-4 flex min-h-[var(--control-height-field)] flex-wrap items-center gap-x-4 gap-y-2 rounded-[var(--radius-control)] bg-[var(--color-surface-recessed)] px-3 py-2 text-[11px] text-white/42'
const surfaceShadow = { boxShadow: 'var(--shadow-surface-subtle)' }
const capabilitySignature = (value: Record<string, unknown>) => JSON.stringify(value)
const blankEditor = { name: '', description: '', content: '', transport: 'http', event: 'webhook', detail: '', envJson: '', headersJson: '', includeText: '', excludeText: '', excluded: false, hookDefault: false, filterJson: '', every: '', at: '', secret: '', telegramToken: '' }
const emptySignature = capabilitySignature(blankEditor)
function parseJsonObject(text: string, label: string): Record<string, string> | undefined {
  if (!text.trim()) return undefined
  let parsed: unknown
  try { parsed = JSON.parse(text) } catch { throw new Error(`${label} must be valid JSON.`) }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error(`${label} must be a JSON object.`)
  return Object.fromEntries(Object.entries(parsed).map(([key, value]) => [key, String(value)]))
}

function parseCommandLine(value: string): string[] {
  const tokens: string[] = []
  const pattern = /"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|([^\s]+)/g
  for (const match of value.trim().matchAll(pattern)) {
    tokens.push((match[1] ?? match[2] ?? match[3]).replace(/\\([\\"'])/g, '$1'))
  }
  return tokens
}

export function ConnectionsView({ mcps, onRefresh }: Props) {
  const reduceMotion = useReducedMotion()
  const [tab, setTab] = useState<Tab>('mcps')
  const [catalog, setCatalog] = useState<CapabilityCatalog>({ ...emptyCatalog, mcps })
  const [editing, setEditing] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [content, setContent] = useState('')
  const [transport, setTransport] = useState<'http' | 'stdio'>('http')
  const [event, setEvent] = useState<HookInfo['event']>('webhook')
  const [detail, setDetail] = useState('')
  const [envJson, setEnvJson] = useState('')
  const [headersJson, setHeadersJson] = useState('')
  const [includeText, setIncludeText] = useState('')
  const [excludeText, setExcludeText] = useState('')
  const [excluded, setExcluded] = useState(false)
  const [hookDefault, setHookDefault] = useState(false)
  const [filterJson, setFilterJson] = useState('')
  const [every, setEvery] = useState('')
  const [at, setAt] = useState('')
  const [secret, setSecret] = useState('')
  const [telegramToken, setTelegramToken] = useState('')
  const [feedback, setFeedback] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [originalSignature, setOriginalSignature] = useState(emptySignature)

  const refresh = useCallback(async () => {
    const next = await fetchCapabilities()
    setCatalog(next)
  }, [])
  useEffect(() => { void refresh().catch(() => setCatalog(current => ({ ...current, mcps }))) }, [refresh, mcps])

  const resetExtended = () => { setEnvJson(''); setHeadersJson(''); setIncludeText(''); setExcludeText(''); setExcluded(false); setHookDefault(false); setFilterJson(''); setEvery(''); setAt(''); setSecret(''); setTelegramToken('') }
  const close = () => { setCreating(false); setEditing(null); setName(''); setDescription(''); setContent(''); setTransport('http'); setEvent('webhook'); setDetail(''); resetExtended(); setFeedback(null); setConfirmDelete(false); setOriginalSignature(emptySignature) }
  const beginNew = () => { close(); setCreating(true); setOriginalSignature(emptySignature) }
  const switchTab = (nextTab: Tab) => {
    if (nextTab === tab) return
    close()
    setTab(nextTab)
  }
  const items = useMemo(() => catalog[tab] ?? [], [catalog, tab])
  const activeItem = editing ? (items as Array<McpInfo | CapabilityFileInfo | HookInfo>).find(item => item.name === editing) : undefined
  const currentEditor = { name, description, content, transport, event, detail, envJson, headersJson, includeText, excludeText, excluded, hookDefault, filterJson, every, at, secret, telegramToken }
  const currentSignature = capabilitySignature(currentEditor)
  const hasChanges = currentSignature !== originalSignature

  const editItem = (item: McpInfo | CapabilityFileInfo | HookInfo) => {
    setCreating(true); setEditing(item.name); setName(item.name); setFeedback(null)
    if (tab === 'mcps') {
      const mcp = item as McpInfo
      const nextDescription = mcp.description ?? ''
      const nextDetail = mcp.transport === 'http' ? (mcp.url ?? '') : (mcp.command ?? []).join(' ')
      const nextEnv = mcp.env ? JSON.stringify(mcp.env, null, 2) : ''
      const nextHeaders = mcp.headers ? JSON.stringify(mcp.headers, null, 2) : ''
      const nextInclude = (mcp.include ?? []).join('\n')
      const nextExclude = (mcp.exclude ?? []).join('\n')
      setDescription(nextDescription); setTransport(mcp.transport); setContent(''); setEvent('webhook'); setDetail(nextDetail)
      setEnvJson(nextEnv); setHeadersJson(nextHeaders); setIncludeText(nextInclude); setExcludeText(nextExclude); setExcluded(mcp.excluded_by_default)
      setHookDefault(false); setFilterJson(''); setEvery(''); setAt(''); setSecret(''); setTelegramToken('')
      setOriginalSignature(capabilitySignature({ ...blankEditor, name: item.name, description: nextDescription, transport: mcp.transport, detail: nextDetail, envJson: nextEnv, headersJson: nextHeaders, includeText: nextInclude, excludeText: nextExclude, excluded: mcp.excluded_by_default }))
    } else if (tab === 'hooks') {
      const hook = item as HookInfo
      const nextContent = hook.prompt ?? ''
      const nextDetail = hook.path ?? ''
      const nextFilter = hook.filter && Object.keys(hook.filter).length ? JSON.stringify(hook.filter, null, 2) : ''
      setDescription(''); setTransport('http'); setEvent(hook.event); setContent(nextContent); setDetail(nextDetail)
      setEnvJson(''); setHeadersJson(''); setIncludeText(''); setExcludeText(''); setExcluded(false)
      setHookDefault(Boolean(hook.default)); setFilterJson(nextFilter); setEvery(hook.every ?? ''); setAt(hook.at ?? ''); setSecret(hook.secret ?? ''); setTelegramToken(hook.telegram_token ?? '')
      setOriginalSignature(capabilitySignature({ ...blankEditor, name: item.name, content: nextContent, event: hook.event, detail: nextDetail, hookDefault: Boolean(hook.default), filterJson: nextFilter, every: hook.every ?? '', at: hook.at ?? '', secret: hook.secret ?? '', telegramToken: hook.telegram_token ?? '' }))
    } else {
      const file = item as CapabilityFileInfo
      const nextDescription = file.description ?? ''
      const nextContent = file.content ?? ''
      setDescription(nextDescription); setContent(nextContent); setTransport('http'); setEvent('webhook'); setDetail('')
      resetExtended()
      setOriginalSignature(capabilitySignature({ ...blankEditor, name: item.name, description: nextDescription, content: nextContent }))
    }
  }

  const submit = async () => {
    const cleanName = name.trim().toLowerCase().replace(/[^a-z0-9._-]+/g, '-')
    if (!cleanName) { setFeedback('Add a name before saving.'); return }
    setSaving(true); setFeedback(null)
    try {
      if (tab === 'mcps') {
        const command = parseCommandLine(detail)
        const env = parseJsonObject(envJson, 'Environment variables') ?? {}
        const headers = parseJsonObject(headersJson, 'Headers') ?? {}
        const include = includeText.split(/\r?\n/).map(value => value.trim()).filter(Boolean)
        const exclude = excludeText.split(/\r?\n/).map(value => value.trim()).filter(Boolean)
        if (transport === 'http' && !detail.trim()) throw new Error('Add the MCP server URL.')
        if (transport === 'stdio' && command.length === 0) throw new Error('Add at least one command token.')
        await saveMcp({ name: cleanName, description: description.trim(), transport,
          url: transport === 'http' ? detail.trim() : undefined,
          command: transport === 'stdio' ? command : undefined,
          env: transport === 'stdio' ? env : undefined,
          headers: transport === 'http' ? headers : undefined,
          include,
          exclude,
          excluded_by_default: excluded })
        await onRefresh()
      } else if (tab === 'hooks') {
        let filter: Record<string, unknown> | undefined
        if (filterJson.trim()) {
          try { filter = JSON.parse(filterJson) as Record<string, unknown> } catch { throw new Error('Filter must be valid JSON.') }
          if (!filter || typeof filter !== 'object' || Array.isArray(filter)) throw new Error('Filter must be a JSON object.')
        }
        if (!content.trim()) throw new Error('Add a prompt template.')
        if ((event === 'webhook' || event === 'file') && !detail.trim()) throw new Error('Add the hook path.')
        if (event === 'cron' && !every.trim() && !at.trim()) throw new Error('Add an interval, a time of day, or both.')
        const hook: Omit<HookInfo, 'name'> = { event, prompt: content, default: hookDefault, filter }
        if (event === 'webhook' || event === 'file') hook.path = detail.trim()
        if (event === 'webhook') hook.secret = secret.trim()
        if (event === 'cron') { hook.every = every.trim(); hook.at = at.trim() }
        if (event === 'telegram' && telegramToken.trim()) hook.telegram_token = telegramToken.trim()
        await saveHook(cleanName, hook)
      } else {
        let source = content
        if (tab === 'skills') source = `---\nname: ${cleanName}\ndescription: ${description.trim()}\n---\n\n${content.trim()}\n`
        if (tab === 'commands' && !source.startsWith('#!')) source = `#!/bin/sh\n${source}`
        await saveFileCapability(tab, cleanName, source)
      }
      await refresh(); close()
    } catch (error) { setFeedback(error instanceof Error ? error.message : 'Failed to save capability.') }
    finally { setSaving(false) }
  }
  const removeCurrent = async () => {
    if (!editing) return
    if (!confirmDelete) { setConfirmDelete(true); return }
    setSaving(true); setFeedback(null)
    try { await deleteCapability(tab, editing); await onRefresh(); await refresh(); close() }
    catch (error) { setFeedback(error instanceof Error ? error.message : 'Failed to delete capability.') }
    finally { setSaving(false) }
  }

  const singular = tabs.find(value => value.id === tab)?.label.slice(0, -1) ?? 'Capability'

  return <div className={cn('relative flex-1 h-full w-full min-w-0 overflow-hidden', creating && 'bg-black')}>
    <div className="h-full overflow-x-hidden overflow-y-auto [scrollbar-gutter:stable]"><ContentContainer asChild gutter="workspace" spacing="page" width="workspace"><motion.main
      key={creating ? `editor:${editing ?? 'new'}` : 'catalog'}
      initial={reduceMotion || !creating ? false : { opacity: 0, y: 6, filter: 'blur(2px)' }}
      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      transition={reduceMotion ? { duration: 0 } : { duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title={creating ? `${editing ? 'Edit' : 'Create'} ${singular}` : 'Capabilities'}
        description={creating ? 'Saved in this workspace. Organization publishing can be added without changing this format.' : 'Build the tools, knowledge, automation, and rules available to your agents.'}
        withBackdrop={!creating}
        action={creating
          ? <div className="flex items-center gap-2"><Button variant="primary" disabled={saving || !hasChanges} onClick={submit} className="gap-1.5"><Save size={13} />{saving ? 'Saving…' : editing ? 'Save changes' : `Save ${singular}`}</Button><IconButton label="Close capability editor" variant="primary" onClick={close}><X size={15} /></IconButton></div>
          : <Button variant="primary" onClick={beginNew} className="gap-1.5 pl-2"><Plus size={14} />{`New ${tabs.find(value => value.id === tab)?.label.slice(0, -1)}`}</Button>}
      />

      {!creating && <Tabs value={tab} onValueChange={value => switchTab(value as Tab)}>
        <TabsList aria-label="Capability type" variant="panel" size="default" className="mb-5">
          {tabs.map(item => <TabsTrigger key={item.id} value={item.id} className="border-[var(--color-surface-selected)] data-[state=active]:border-r-transparent">
            {item.icon}<span>{item.label}</span>
          </TabsTrigger>)}
        </TabsList>
      </Tabs>}

      {creating && <DocumentEditor className="mb-5 flex min-h-[calc(100dvh-10rem)] flex-col">
        <DocumentIdentity
          name={name}
          description={description}
          showDescription={tab === 'mcps' || tab === 'skills'}
          nameDisabled={Boolean(editing)}
          onNameChange={setName}
          onDescriptionChange={setDescription}
        />
        {editing && activeItem && <CapabilityStatus tab={tab} item={activeItem} />}

        {tab !== 'mcps' && <DocumentSection className="flex min-h-[16rem] flex-1 flex-col" title={tab === 'hooks' ? 'Prompt template' : tab === 'commands' ? 'Shell script' : tab === 'rules' ? 'Rule content' : 'Instructions'}>
          <DocumentBody
            value={content}
            onChange={event => setContent(event.target.value)}
            placeholder={tab === 'hooks' ? 'Describe what the agent should do when this hook runs.' : tab === 'commands' ? 'Write the command here.' : tab === 'rules' ? 'Write the rule here.' : 'Describe how the agent should use this skill.'}
            className={cn('h-auto max-h-none flex-1', tab === 'commands' && 'font-mono')}
          />
        </DocumentSection>}

        {(tab === 'mcps' || tab === 'hooks') && <DocumentAdvanced>
          <DocumentSettingsGroupTitle>{tab === 'mcps' ? 'Connection' : 'Trigger'}</DocumentSettingsGroupTitle>
          {tab === 'mcps' && <>
            <DocumentSettingsRow title="Transport" description="How Nebula connects to this MCP server.">
              <ContextSelect appearance="row" value={transport} onChange={setTransport} ariaLabel="MCP transport" options={[{ value: 'http', label: 'HTTP', icon: <Globe2 size={14} /> }, { value: 'stdio', label: 'Local process', icon: <Terminal size={14} /> }]} contentWidth="w-52" side="bottom" />
            </DocumentSettingsRow>
            <DocumentSettingsRow title={transport === 'http' ? 'Server URL' : 'Launch command'} description={transport === 'http' ? 'The MCP endpoint used for requests.' : 'The local process and arguments to start.'} className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]">
              <input value={detail} onChange={e => setDetail(e.target.value)} className={cn(inputClass, 'font-mono')} placeholder={transport === 'http' ? 'https://example.com/mcp' : 'python3 .nebula/servers/example.py'} />
            </DocumentSettingsRow>
            <DocumentSettingsRow title={transport === 'http' ? 'HTTP headers' : 'Environment variables'} description="Optional JSON object passed to the connection." className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]">
              <textarea value={transport === 'http' ? headersJson : envJson} onChange={e => transport === 'http' ? setHeadersJson(e.target.value) : setEnvJson(e.target.value)} className={cn(inputClass, 'min-h-20 resize-none font-mono leading-5')} placeholder={transport === 'http' ? '{\n  "Authorization": "Bearer $TOKEN"\n}' : '{\n  "API_TOKEN": "$API_TOKEN"\n}'} />
            </DocumentSettingsRow>
            <DocumentSettingsRow title="Included tools" description="Optional allowlist, one tool per line." className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]"><textarea value={includeText} onChange={e => setIncludeText(e.target.value)} className={cn(inputClass, 'min-h-20 resize-none font-mono leading-5')} placeholder="All tools" /></DocumentSettingsRow>
            <DocumentSettingsRow title="Excluded tools" description="Optional denylist, one tool per line." className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]"><textarea value={excludeText} onChange={e => setExcludeText(e.target.value)} className={cn(inputClass, 'min-h-20 resize-none font-mono leading-5')} placeholder="No tools" /></DocumentSettingsRow>
            <DocumentSettingsRow title="Default sessions" description="Choose whether new sessions load this MCP automatically."><Checkbox appearance="field" className="w-full sm:w-52" checked={excluded} onChange={e => setExcluded(e.target.checked)} label="Exclude by default" /></DocumentSettingsRow>
          </>}
          {tab === 'hooks' && <>
            <DocumentSettingsRow title="Event" description="The event source that starts this hook."><ContextSelect appearance="row" value={event} onChange={setEvent} ariaLabel="Hook event" options={[{ value: 'webhook', label: 'Webhook' }, { value: 'cron', label: 'Cron' }, { value: 'telegram', label: 'Telegram' }, { value: 'file', label: 'File' }]} side="bottom" /></DocumentSettingsRow>
            {(event === 'webhook' || event === 'file') && <DocumentSettingsRow title="Path" description={event === 'webhook' ? 'The incoming webhook route.' : 'The file path to watch.'} className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]"><input value={detail} onChange={e => setDetail(e.target.value)} className={inputClass} placeholder={event === 'webhook' ? '/webhook/github' : '/tmp/nebula-trigger'} /></DocumentSettingsRow>}
            {event === 'webhook' && <DocumentSettingsRow title="HMAC secret" description="Secret or environment reference used to verify requests." className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]"><input value={secret} onChange={e => setSecret(e.target.value)} className={inputClass} placeholder="$GITHUB_WEBHOOK_SECRET" /></DocumentSettingsRow>}
            {event === 'cron' && <><DocumentSettingsRow title="Interval" description="How often this hook runs."><input value={every} onChange={e => setEvery(e.target.value)} className={inputClass} placeholder="30m" /></DocumentSettingsRow><DocumentSettingsRow title="Time of day" description="Optional daily execution time."><input value={at} onChange={e => setAt(e.target.value)} className={inputClass} placeholder="09:00" /></DocumentSettingsRow></>}
            {event === 'telegram' && <DocumentSettingsRow title="Telegram token" description="Bot token or environment reference." className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]"><input value={telegramToken} onChange={e => setTelegramToken(e.target.value)} className={inputClass} placeholder="$TELEGRAM_BOT_TOKEN" /></DocumentSettingsRow>}
            <DocumentSettingsRow title="Default session" description="Also fire this hook in the default session."><Checkbox appearance="field" className="w-full sm:w-52" checked={hookDefault} onChange={e => setHookDefault(e.target.checked)} label="Enabled" /></DocumentSettingsRow>
            <DocumentSettingsRow title="Payload filter" description="Optional JSON conditions for incoming events." className="sm:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)]"><textarea value={filterJson} onChange={e => setFilterJson(e.target.value)} className={cn(inputClass, 'min-h-20 resize-none font-mono leading-5')} placeholder={'{\n  "ref": "refs/heads/main"\n}'} /></DocumentSettingsRow>
          </>}
        </DocumentAdvanced>}
        {(editing || feedback) && <div className="mt-5 flex items-center gap-3">{editing && <Button variant="danger" disabled={saving} onClick={removeCurrent} className="gap-1.5"><Trash2 size={13} />{confirmDelete ? 'Confirm delete' : 'Delete'}</Button>}<p className="text-[12px] text-[var(--color-status-danger)]">{feedback}</p></div>}
      </DocumentEditor>}

      {!creating && <div key={tab} className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {(items as Array<McpInfo | CapabilityFileInfo | HookInfo>).map(item => <CapabilityCard key={`${tab}:${item.name}`} tab={tab} item={item} onClick={() => editItem(item)} />)}
        {items.length === 0 && <div className="col-span-full flex min-h-[164px] items-center justify-center rounded-[var(--radius-surface)] bg-[var(--color-surface-glass-subtle)] p-10 text-center text-xs text-white/40 backdrop-blur-[var(--blur-glass)]">No {tab} are configured yet.</div>}
      </div>}
    </motion.main></ContentContainer></div>
  </div>
}

function CapabilityStatus({ tab, item }: { tab: Tab; item: McpInfo | CapabilityFileInfo | HookInfo }) {
  if (tab === 'mcps') {
    const mcp = item as McpInfo
    return <div className={statusClass}>
      <span><span className="text-white/65">Status</span> {mcp.loaded ? 'Connected' : (mcp.state ?? 'Configured')}</span>
      <span><span className="text-white/65">Tools</span> {mcp.tools ?? 0}</span>
      <span><span className="text-white/65">Generation</span> {mcp.generation ?? '—'}</span>
      <span><span className="text-white/65">Default</span> {mcp.excluded_by_default ? 'Excluded' : 'Enabled'}</span>
      {mcp.error && <span className="w-full text-[var(--color-status-danger)]">{mcp.error}</span>}
    </div>
  }
  if (tab === 'hooks') {
    const hook = item as HookInfo
    return <div className={statusClass}><span><span className="text-white/65">Event</span> {hook.event}</span><span><span className="text-white/65">Routing</span> {hook.default ? 'Agents + default session' : 'Assigned agents only'}</span><span>Runtime reload required after changes</span></div>
  }
  const file = item as CapabilityFileInfo
  return <div className={statusClass}><span><span className="text-white/65">Scope</span> {file.scope}</span>{file.source && <span className="min-w-0 truncate"><span className="text-white/65">Source</span> {file.source}</span>}</div>
}

function CapabilityCard({ tab, item, onClick }: { tab: Tab; item: McpInfo | CapabilityFileInfo | HookInfo; onClick: () => void }) {
  const description = tab === 'mcps' ? ((item as McpInfo).description || 'External tool connection.') : tab === 'hooks' ? ((item as HookInfo).prompt || 'Automated event trigger.') : ((item as CapabilityFileInfo).description || `${tabs.find(value => value.id === tab)?.detail}.`)
  const badge = tab === 'mcps' ? (item as McpInfo).transport : tab === 'hooks' ? (item as HookInfo).event : (item as CapabilityFileInfo).scope
  const icon = tabs.find(value => value.id === tab)?.icon
  const status = tab === 'mcps'
    ? ((item as McpInfo).loaded ? 'Connected' : ((item as McpInfo).state || 'Configured'))
    : tab === 'hooks'
      ? ((item as HookInfo).default ? 'Default session' : 'Agent routed')
      : ((item as CapabilityFileInfo).scope || 'Available')
  return <motion.article
    initial={false}
    style={surfaceShadow} role="button" tabIndex={0} onClick={onClick} className="ui-border-surface min-h-[164px] cursor-pointer rounded-[var(--radius-surface)] bg-[var(--color-surface-panel)] p-4 transition-colors hover:bg-[var(--color-surface-raised)] focus-visible:[outline:var(--focus-ring-width-strong)_solid_var(--focus-ring-color-strong)] focus-visible:outline-offset-2">
    <div className="flex items-start justify-between gap-3"><div className="flex min-w-0 items-center gap-2"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--radius-control)] bg-white/[0.07] text-white/55">{icon}</div><h2 className="truncate text-[14px] font-semibold text-white/85">{item.name}</h2></div><MetadataChip className="uppercase">{badge}</MetadataChip></div>
    <p className="mt-4 line-clamp-3 min-h-[54px] text-[12px] leading-relaxed text-white/48">{description}</p>
    <div className="mt-3 flex flex-wrap items-center gap-2 text-[10px] text-[var(--color-status-success)]"><span className="inline-flex items-center gap-1"><CheckCircle2 size={11} />{status}</span>{tab === 'mcps' && (item as McpInfo).tools !== undefined && <span className="text-white/35">{(item as McpInfo).tools} tools</span>}{tab === 'mcps' && (item as McpInfo).excluded_by_default && <span className="text-white/35">Excluded by default</span>}</div>
  </motion.article>
}
